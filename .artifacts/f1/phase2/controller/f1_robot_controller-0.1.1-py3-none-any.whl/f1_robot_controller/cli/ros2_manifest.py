"""Console entrypoint for F1 ROS 2 read-only manifest capture."""

from collections.abc import Sequence

from f1_robot_controller.ros2_manifest import main as _main


def main(argv: Sequence[str] | None = None) -> int:
    """Run the manifest capture/validation CLI."""

    return _main(argv)
