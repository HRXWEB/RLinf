"""Thread-safe readiness and fault-state aggregation."""

from collections.abc import Callable
from math import isfinite
from threading import RLock
from time import monotonic

from f1_robot_controller.errors import ControllerError
from f1_robot_controller.types import ControllerHealth


class HealthMonitor:
    """Track readiness while preserving faults for the active lifecycle."""

    def __init__(self, *, clock: Callable[[], float] = monotonic) -> None:
        """Create a monitor with an injectable monotonic clock.

        Args:
            clock: Function returning the current monotonic timestamp.
        """

        self._clock = clock
        self._lock = RLock()
        self._open = False
        self._ready = False
        self._faulted = False
        self._reason: str | None = None

    def open(self) -> None:
        """Begin a new lifecycle and explicitly clear any previous fault."""

        with self._lock:
            if self._open:
                return
            self._open = True
            self._ready = False
            self._faulted = False
            self._reason = None

    def close(self) -> None:
        """Mark the current lifecycle as not ready without concealing a fault."""

        with self._lock:
            self._open = False
            self._ready = False

    def set_ready(self) -> None:
        """Record readiness unless the current lifecycle remains faulted."""

        with self._lock:
            if not self._faulted:
                self._ready = True
                self._reason = None

    def set_fault(self, reason: str) -> None:
        """Record a persistent fault for the current lifecycle.

        Args:
            reason: Human-readable explanation of the fault.

        Raises:
            ControllerError: If ``reason`` is not a non-empty string.
        """

        if not isinstance(reason, str) or not reason:
            raise ControllerError("reason must be a non-empty string")
        with self._lock:
            self._ready = False
            self._faulted = True
            self._reason = reason

    def snapshot(self) -> ControllerHealth:
        """Return the current health state with a fresh monotonic timestamp.

        Raises:
            ControllerError: If the injected clock returns a non-finite value.
        """

        checked_at_monotonic_s = _checked_time(self._clock)
        with self._lock:
            return ControllerHealth(
                ready=self._ready,
                faulted=self._faulted,
                reason=self._reason,
                checked_at_monotonic_s=checked_at_monotonic_s,
            )


def _checked_time(clock: Callable[[], float]) -> float:
    """Return a valid clock reading or a typed controller failure."""

    try:
        checked_at_monotonic_s = float(clock())
    except (TypeError, ValueError, OverflowError) as error:
        raise ControllerError("health clock must return a finite timestamp") from error
    if not isfinite(checked_at_monotonic_s):
        raise ControllerError("health clock must return a finite timestamp")
    return checked_at_monotonic_s
