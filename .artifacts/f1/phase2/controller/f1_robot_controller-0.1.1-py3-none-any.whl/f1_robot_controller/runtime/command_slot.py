"""Capacity-one command handoff for background action executors."""

from math import isfinite
from threading import Condition
from time import monotonic

from f1_robot_controller.errors import (
    CommandRejectedError,
    ControllerError,
    ControllerNotReadyError,
)
from f1_robot_controller.types import (
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
)

Command = (
    DualArmCommand | DualArmResetCommand | DualArmTcpCommand | DualArmTcpResetCommand
)


class CommandSlot:
    """Hand commands from producers to one consumer without queueing backlog."""

    def __init__(self) -> None:
        """Create an open slot with no pending command."""

        self._condition = Condition()
        self._pending: Command | None = None
        self._closed = False

    def open(self) -> None:
        """Start a new empty command-slot lifecycle."""

        with self._condition:
            self._pending = None
            self._closed = False
            self._condition.notify_all()

    def replace(self, command: Command) -> Command | None:
        """Store a command, returning and replacing the previous pending command.

        Args:
            command: The command to make available to the consumer.

        Returns:
            The command displaced by this replacement, if any.

        Raises:
            CommandRejectedError: If ``command`` is not a supported command type.
            ControllerNotReadyError: If the slot is closed.
        """

        if not isinstance(
            command,
            (
                DualArmCommand,
                DualArmResetCommand,
                DualArmTcpCommand,
                DualArmTcpResetCommand,
            ),
        ):
            raise CommandRejectedError(
                "command must be DualArmCommand, DualArmResetCommand, "
                "DualArmTcpCommand, or DualArmTcpResetCommand"
            )

        with self._condition:
            if self._closed:
                raise ControllerNotReadyError("command slot is closed")
            replaced = self._pending
            self._pending = command
            self._condition.notify()
            return replaced

    def take(self, *, timeout_s: float) -> Command | None:
        """Return one pending command, or ``None`` after timeout or closure.

        Args:
            timeout_s: Maximum time to wait for a command.

        Returns:
            The pending command, or ``None`` when no command becomes available.

        Raises:
            ControllerError: If ``timeout_s`` is negative or not finite.
        """

        timeout_s = _validated_timeout(timeout_s)
        deadline_s = monotonic() + timeout_s
        with self._condition:
            while self._pending is None and not self._closed:
                remaining_s = deadline_s - monotonic()
                if remaining_s <= 0.0:
                    return None
                self._condition.wait(timeout=remaining_s)
            if self._pending is None:
                return None
            command = self._pending
            self._pending = None
            return command

    def clear(self) -> Command | None:
        """Discard and return the pending command, if one exists."""

        with self._condition:
            cleared = self._pending
            self._pending = None
            self._condition.notify_all()
            return cleared

    def close(self) -> None:
        """Close the slot, discard pending work, and wake all waiting consumers."""

        with self._condition:
            self._pending = None
            self._closed = True
            self._condition.notify_all()


def _validated_timeout(timeout_s: float) -> float:
    """Normalize a timeout while preserving controller-specific failures."""

    try:
        timeout = float(timeout_s)
    except (TypeError, ValueError, OverflowError) as error:
        raise ControllerError("timeout_s must be finite and non-negative") from error
    if not isfinite(timeout) or timeout < 0.0:
        raise ControllerError("timeout_s must be finite and non-negative")
    return timeout
