"""Helpers for local monotonic receipt timestamps."""

from collections.abc import Callable
from math import inf, isfinite, nextafter
from threading import Lock
from time import monotonic

from f1_robot_controller.errors import ControllerError


class MonotonicStampAllocator:
    """Allocate strictly increasing stamps from one possibly stalled raw clock."""

    def __init__(self, clock: Callable[[], float] = monotonic) -> None:
        """Create an allocator around a callable raw monotonic clock.

        Args:
            clock: Callable providing finite raw monotonic timestamps.
        """

        self._clock = clock
        self._lock = Lock()
        self._last_stamp_s = -inf

    def next(self) -> float:
        """Return a stamp later than the raw sample and prior allocation.

        Returns:
            The next finite, strictly increasing local timestamp.

        Raises:
            ControllerError: If the raw clock does not return a finite timestamp.
        """

        with self._lock:
            try:
                raw_sample_s = float(self._clock())
            except (TypeError, ValueError, OverflowError) as error:
                raise ControllerError("clock must return a finite timestamp") from error
            if not isfinite(raw_sample_s):
                raise ControllerError("clock must return a finite timestamp")
            stamp_s = nextafter(max(raw_sample_s, self._last_stamp_s), inf)
            self._last_stamp_s = stamp_s
            return stamp_s


def is_strictly_newer(received_at_monotonic_s: float, newer_than_s: float) -> bool:
    """Return whether a receipt timestamp is strictly after a threshold."""

    return received_at_monotonic_s > newer_than_s
