"""Latest-only cache for assembling coherent robot observations."""

from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from math import isfinite
from numbers import Real
from threading import RLock

import numpy as np

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.errors import ObservationUnavailableError
from f1_robot_controller.types import RobotObservation, SensorTimestamps
from f1_robot_controller.validation import (
    OPTIONAL_TCP_SENSOR_KEYS,
    REQUIRED_SENSOR_KEYS,
    validate_observation,
)

_SENSOR_ATTRIBUTES = {
    "left_joint_position": "left_joint_position_rad",
    "left_gripper_position": "left_gripper_position",
    "right_joint_position": "right_joint_position_rad",
    "right_gripper_position": "right_gripper_position",
    "head_color": "head_color_rgb",
    "left_wrist_color": "left_wrist_color_rgb",
    "right_wrist_color": "right_wrist_color_rgb",
}
_JOINT_SENSOR_NAMES = frozenset(("left_joint_position", "right_joint_position"))
_GRIPPER_SENSOR_NAMES = frozenset(("left_gripper_position", "right_gripper_position"))
_IMAGE_SENSOR_NAMES = frozenset(("head_color", "left_wrist_color", "right_wrist_color"))
_TCP_POSE_SENSOR_NAMES = frozenset(OPTIONAL_TCP_SENSOR_KEYS)
_KNOWN_SENSOR_KEYS = frozenset(REQUIRED_SENSOR_KEYS) | _TCP_POSE_SENSOR_NAMES
_OPTIONAL_SENSOR_ATTRIBUTES = {
    "left_tcp_pose": "left_tcp_pose_m_deg",
    "right_tcp_pose": "right_tcp_pose_m_deg",
}


@dataclass(frozen=True)
class _SensorSample:
    """One sensor payload and its source and receipt timestamps."""

    value: np.ndarray | float
    source_timestamp_s: float
    received_at_monotonic_s: float


_SensorUpdate = tuple[np.ndarray | float, float, float]


class ObservationCache:
    """Maintain the most recently received sample for every required sensor."""

    def __init__(
        self,
        config: ControllerConfig | None = None,
        *,
        image_shapes: Mapping[str, tuple[int, int, int]] | None = None,
    ) -> None:
        """Create an empty cache using the supplied observation configuration."""

        self._config = ControllerConfig() if config is None else config
        default_image_shapes = {
            sensor_name: (
                self._config.fake.image_height,
                self._config.fake.image_width,
                3,
            )
            for sensor_name in _IMAGE_SENSOR_NAMES
        }
        self._image_shapes: Mapping[str, tuple[int, int, int]] = (
            default_image_shapes if image_shapes is None else dict(image_shapes)
        )
        self._lock = RLock()
        self._samples: dict[str, _SensorSample] = {}

    def update(
        self,
        sensor_name: str,
        value: np.ndarray | float,
        *,
        source_timestamp_s: float,
        received_at_monotonic_s: float,
    ) -> None:
        """Replace a sensor's cached sample with the newly received value."""

        if sensor_name not in _KNOWN_SENSOR_KEYS:
            raise ObservationUnavailableError(f"unknown sensor: {sensor_name}")

        sample = self._make_sample(
            sensor_name,
            value,
            source_timestamp_s=source_timestamp_s,
            received_at_monotonic_s=received_at_monotonic_s,
        )
        with self._lock:
            self._reject_older_receipt(sensor_name, sample)
            self._samples[sensor_name] = sample

    def update_batch(
        self,
        samples: Mapping[str, _SensorUpdate],
        *,
        invalidate: Iterable[str] = (),
    ) -> None:
        """Atomically replace a batch of latest sensor samples.

        Args:
            samples: Mapping from canonical sensor name to a tuple containing
                value, source timestamp, and local receipt timestamp.
            invalidate: Sensor names whose previously cached samples should be
                removed in the same atomic commit.

        Raises:
            ObservationUnavailableError: If a sensor name or update tuple is
                invalid. The cache is unchanged when validation fails.
        """

        prepared: dict[str, _SensorSample] = {}
        invalidated: set[str] = set()
        with self._lock:
            for sensor_name in invalidate:
                if sensor_name not in _KNOWN_SENSOR_KEYS:
                    raise ObservationUnavailableError(f"unknown sensor: {sensor_name}")
                invalidated.add(sensor_name)
            for sensor_name, update in samples.items():
                if sensor_name not in _KNOWN_SENSOR_KEYS:
                    raise ObservationUnavailableError(f"unknown sensor: {sensor_name}")
                try:
                    value, source_timestamp_s, received_at_monotonic_s = update
                except (TypeError, ValueError) as error:
                    raise ObservationUnavailableError(
                        f"invalid sensor update: {sensor_name}"
                    ) from error
                prepared[sensor_name] = self._make_sample(
                    sensor_name,
                    value,
                    source_timestamp_s=source_timestamp_s,
                    received_at_monotonic_s=received_at_monotonic_s,
                )
            for sensor_name, sample in prepared.items():
                if sensor_name not in invalidated:
                    self._reject_older_receipt(sensor_name, sample)
            for sensor_name in invalidated:
                self._samples.pop(sensor_name, None)
            self._samples.update(prepared)

    def _reject_older_receipt(self, sensor_name: str, sample: _SensorSample) -> None:
        """Reject a sample that would move one sensor's local receipt backward."""

        existing = self._samples.get(sensor_name)
        if (
            existing is not None
            and sample.received_at_monotonic_s < existing.received_at_monotonic_s
        ):
            raise ObservationUnavailableError(
                f"older receipt timestamp for sensor: {sensor_name}"
            )

    def _make_sample(
        self,
        sensor_name: str,
        value: np.ndarray | float,
        *,
        source_timestamp_s: float,
        received_at_monotonic_s: float,
    ) -> _SensorSample:
        """Validate and normalize one producer value into an immutable entry."""

        stored_value = self._normalize_value(sensor_name, value)
        return _SensorSample(
            value=stored_value,
            source_timestamp_s=self._finite_timestamp(
                source_timestamp_s,
                field=f"{sensor_name} source timestamp",
            ),
            received_at_monotonic_s=self._finite_timestamp(
                received_at_monotonic_s,
                field=f"{sensor_name} received timestamp",
            ),
        )

    def _normalize_value(
        self, sensor_name: str, value: np.ndarray | float
    ) -> np.ndarray | float:
        """Return one canonical copied payload for its sensor kind."""

        if sensor_name in _JOINT_SENSOR_NAMES:
            try:
                array = np.asarray(value)
            except (TypeError, ValueError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a real numeric dimension-7 vector"
                ) from error
            if array.shape != (7,) or not (
                np.issubdtype(array.dtype, np.floating)
                or np.issubdtype(array.dtype, np.integer)
            ):
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a real numeric dimension-7 vector"
                )
            try:
                normalized = np.array(array, dtype=np.float64, copy=True)
            except (TypeError, ValueError, OverflowError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must contain finite real numeric joints"
                ) from error
            if not np.all(np.isfinite(normalized)):
                raise ObservationUnavailableError(
                    f"{sensor_name} must contain finite real numeric joints"
                )
            normalized.setflags(write=False)
            return normalized

        if sensor_name in _GRIPPER_SENSOR_NAMES:
            if isinstance(value, bool) or not isinstance(value, Real):
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a finite real number in [0, 100]"
                )
            try:
                normalized = float(value)
            except (TypeError, ValueError, OverflowError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a finite real number in [0, 100]"
                ) from error
            if not isfinite(normalized) or not 0.0 <= normalized <= 100.0:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a finite real number in [0, 100]"
                )
            return normalized

        if sensor_name in _TCP_POSE_SENSOR_NAMES:
            try:
                array = np.asarray(value)
            except (TypeError, ValueError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a real numeric dimension-6 vector"
                ) from error
            if array.shape != (6,) or not (
                np.issubdtype(array.dtype, np.floating)
                or np.issubdtype(array.dtype, np.integer)
            ):
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a real numeric dimension-6 vector"
                )
            try:
                normalized = np.array(array, dtype=np.float64, copy=True)
            except (TypeError, ValueError, OverflowError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must contain finite real numeric TCP values"
                ) from error
            if not np.all(np.isfinite(normalized)):
                raise ObservationUnavailableError(
                    f"{sensor_name} must contain finite real numeric TCP values"
                )
            normalized.setflags(write=False)
            return normalized

        if sensor_name in _IMAGE_SENSOR_NAMES:
            try:
                image = np.asarray(value)
            except (TypeError, ValueError) as error:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a uint8 RGB image"
                ) from error
            expected_shape = self._image_shapes.get(sensor_name)
            if expected_shape is None:
                raise ObservationUnavailableError(
                    f"no image shape configured for sensor: {sensor_name}"
                )
            if image.shape != expected_shape or image.dtype != np.uint8:
                raise ObservationUnavailableError(
                    f"{sensor_name} must be a uint8 RGB image with shape "
                    f"{expected_shape}"
                )
            normalized = np.array(image, dtype=np.uint8, copy=True)
            normalized.setflags(write=False)
            return normalized

        raise ObservationUnavailableError(f"unknown sensor: {sensor_name}")

    @staticmethod
    def _finite_timestamp(value: object, *, field: str) -> float:
        """Return a strict finite real timestamp with a typed cache failure."""

        if isinstance(value, bool) or not isinstance(value, Real):
            raise ObservationUnavailableError(f"{field} must be a finite real number")
        try:
            normalized = float(value)
        except (TypeError, ValueError, OverflowError) as error:
            raise ObservationUnavailableError(
                f"{field} must be a finite real number"
            ) from error
        if not isfinite(normalized):
            raise ObservationUnavailableError(f"{field} must be a finite real number")
        return normalized

    def snapshot(
        self,
        *,
        now_monotonic_s: float,
        max_age_s: float,
        max_skew_s: float,
        newer_than_s: float | None = None,
    ) -> RobotObservation:
        """Build and validate a copy of the latest complete observation."""

        with self._lock:
            samples = self._complete_samples_locked()

        return self._build_observation(
            samples,
            now_monotonic_s=now_monotonic_s,
            max_age_s=max_age_s,
            max_skew_s=max_skew_s,
            newer_than_s=newer_than_s,
        )

    def snapshot_with_clock(
        self,
        *,
        clock: Callable[[], float],
        max_age_s: float,
        max_skew_s: float,
        newer_than_s: float | None = None,
    ) -> RobotObservation:
        """Sample ``clock`` and capture the cache under one cache lock."""

        with self._lock:
            now_monotonic_s = clock()
            samples = self._complete_samples_locked()

        return self._build_observation(
            samples,
            now_monotonic_s=now_monotonic_s,
            max_age_s=max_age_s,
            max_skew_s=max_skew_s,
            newer_than_s=newer_than_s,
        )

    def _complete_samples_locked(self) -> dict[str, _SensorSample]:
        """Capture every required sample while the caller holds the cache lock."""

        missing = [
            sensor for sensor in REQUIRED_SENSOR_KEYS if sensor not in self._samples
        ]
        if missing:
            raise ObservationUnavailableError(
                f"missing sensor samples: {', '.join(missing)}"
            )
        complete = {sensor: self._samples[sensor] for sensor in REQUIRED_SENSOR_KEYS}
        complete.update(
            {
                sensor: self._samples[sensor]
                for sensor in OPTIONAL_TCP_SENSOR_KEYS
                if sensor in self._samples
            }
        )
        return complete

    def _build_observation(
        self,
        samples: Mapping[str, _SensorSample],
        *,
        now_monotonic_s: float,
        max_age_s: float,
        max_skew_s: float,
        newer_than_s: float | None,
    ) -> RobotObservation:
        """Copy and validate one already captured complete sample set."""

        values = {
            _SENSOR_ATTRIBUTES[sensor]: (
                self._copy_read_only_array(sample.value)
                if isinstance(sample.value, np.ndarray)
                else float(sample.value)
            )
            for sensor, sample in samples.items()
            if sensor in _SENSOR_ATTRIBUTES
        }
        values.update(
            {
                _OPTIONAL_SENSOR_ATTRIBUTES[sensor]: self._copy_read_only_array(
                    sample.value
                )
                for sensor, sample in samples.items()
                if sensor in _OPTIONAL_SENSOR_ATTRIBUTES
                and isinstance(sample.value, np.ndarray)
            }
        )
        observation = RobotObservation(
            **values,
            timestamps=SensorTimestamps(
                source_timestamp_s={
                    sensor: sample.source_timestamp_s
                    for sensor, sample in samples.items()
                },
                received_at_monotonic_s={
                    sensor: sample.received_at_monotonic_s
                    for sensor, sample in samples.items()
                },
            ),
        )
        validate_observation(
            observation,
            self._config,
            now_monotonic_s=now_monotonic_s,
            max_age_s=max_age_s,
            max_skew_s=max_skew_s,
            newer_than_s=newer_than_s,
            image_shapes=self._image_shapes,
        )
        return observation

    @staticmethod
    def _copy_read_only_array(value: np.ndarray) -> np.ndarray:
        """Return an independent read-only copy of one canonical array."""

        copied = np.array(value, copy=True)
        copied.setflags(write=False)
        return copied
