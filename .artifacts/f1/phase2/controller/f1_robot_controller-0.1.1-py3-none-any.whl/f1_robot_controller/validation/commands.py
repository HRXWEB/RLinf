"""Validation for command inputs accepted by the controller."""

from collections.abc import Sequence
from math import isfinite
from numbers import Integral, Real

import numpy as np

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.errors import CommandRejectedError
from f1_robot_controller.types import (
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
)


def _reject(message: str) -> None:
    raise CommandRejectedError(message)


def _finite_value(value: object, *, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        _reject(f"{field} must be a finite real number")
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError):
        _reject(f"{field} must be a finite real number")
    if not isfinite(converted):
        _reject(f"{field} must be a finite real number")
    return converted


def _validate_command_id(command_id: object) -> None:
    """Reject identifiers that cannot name one unambiguous command lifecycle."""

    if (
        isinstance(command_id, bool)
        or not isinstance(command_id, Integral)
        or command_id < 0
    ):
        _reject("command_id must be a non-negative integer")


def _validate_joint_targets(
    values: np.ndarray,
    *,
    side: str,
    lower_limits: Sequence[float],
    upper_limits: Sequence[float],
) -> None:
    try:
        values = np.asarray(values)
    except (TypeError, ValueError):
        _reject(f"{side} joint target must be a numeric dimension-7 vector")
    if values.shape != (7,):
        _reject(f"{side} joint target must have dimension 7, got {values.shape}")

    for index, value in enumerate(values):
        value = _finite_value(value, field=f"{side} joint {index}")
        try:
            lower_limit = float(lower_limits[index])
            upper_limit = float(upper_limits[index])
            outside_limit = value < lower_limit or value > upper_limit
        except (TypeError, ValueError, OverflowError):
            _reject(f"{side} joint {index} has invalid hard limits")
        if outside_limit:
            _reject(
                f"{side} joint {index} outside hard limit "
                f"[{lower_limit}, {upper_limit}]"
            )


def _validate_gripper(value: float, *, side: str) -> None:
    value = _finite_value(value, field=f"{side} gripper")
    if not 0.0 <= value <= 100.0:
        _reject(f"{side} gripper must be in [0, 100], got {value}")


def _validate_raw_gripper(value: float, *, side: str) -> None:
    value = _finite_value(value, field=f"{side} gripper")
    if not 0.0 <= value <= 100.0:
        _reject(f"{side} gripper must be in [0, 100], got {value}")


def _validate_tcp_targets(
    values: np.ndarray,
    *,
    side: str,
    lower_limits: Sequence[float],
    upper_limits: Sequence[float],
) -> None:
    try:
        values = np.asarray(values)
    except (TypeError, ValueError):
        _reject(f"{side} TCP target must be a numeric dimension-6 vector")
    if values.shape != (6,):
        _reject(f"{side} TCP target must have dimension 6, got {values.shape}")

    for index, value in enumerate(values):
        value = _finite_value(value, field=f"{side} TCP target {index}")
        try:
            lower_limit = float(lower_limits[index])
            upper_limit = float(upper_limits[index])
            outside_limit = value < lower_limit or value > upper_limit
        except (TypeError, ValueError, OverflowError):
            _reject(f"{side} TCP target {index} has invalid hard limits")
        if outside_limit:
            _reject(
                f"{side} TCP target {index} outside hard limit "
                f"[{lower_limit}, {upper_limit}]"
            )


def _validate_common(
    *,
    command_id: object,
    left_joint_target_rad: np.ndarray,
    left_gripper_target: float,
    right_joint_target_rad: np.ndarray,
    right_gripper_target: float,
    duration_s: float,
    created_at_monotonic_s: float,
    config: ControllerConfig,
) -> None:
    _validate_command_id(command_id)
    duration_s = _finite_value(duration_s, field="duration_s")
    if duration_s <= 0.0:
        _reject(f"duration must be positive and finite, got {duration_s}")
    _finite_value(created_at_monotonic_s, field="created_at_monotonic_s")

    _validate_joint_targets(
        left_joint_target_rad,
        side="left",
        lower_limits=config.joint_limit_low_rad[:7],
        upper_limits=config.joint_limit_high_rad[:7],
    )
    _validate_gripper(left_gripper_target, side="left")
    _validate_joint_targets(
        right_joint_target_rad,
        side="right",
        lower_limits=config.joint_limit_low_rad[7:],
        upper_limits=config.joint_limit_high_rad[7:],
    )
    _validate_gripper(right_gripper_target, side="right")


def validate_command(command: DualArmCommand, config: ControllerConfig) -> None:
    """Validate a command without modifying it.

    Args:
        command: Command to validate.
        config: Controller hard limits.

    Raises:
        CommandRejectedError: If a target violates the command contract.
    """

    _validate_common(
        command_id=command.command_id,
        left_joint_target_rad=command.left_joint_target_rad,
        left_gripper_target=command.left_gripper_target,
        right_joint_target_rad=command.right_joint_target_rad,
        right_gripper_target=command.right_gripper_target,
        duration_s=command.duration_s,
        created_at_monotonic_s=command.created_at_monotonic_s,
        config=config,
    )


def validate_reset_command(
    command: DualArmResetCommand, config: ControllerConfig
) -> None:
    """Validate a reset command without modifying it.

    Args:
        command: Reset command to validate.
        config: Controller hard limits.

    Raises:
        CommandRejectedError: If a target or reset timing violates the contract.
    """

    _validate_common(
        command_id=command.command_id,
        left_joint_target_rad=command.left_joint_target_rad,
        left_gripper_target=command.left_gripper_target,
        right_joint_target_rad=command.right_joint_target_rad,
        right_gripper_target=command.right_gripper_target,
        duration_s=command.duration_s,
        created_at_monotonic_s=command.created_at_monotonic_s,
        config=config,
    )
    tolerance_rad = _finite_value(command.tolerance_rad, field="tolerance_rad")
    if tolerance_rad <= 0.0:
        _reject("reset tolerance must be positive and finite")
    timeout_s = _finite_value(command.timeout_s, field="timeout_s")
    if timeout_s <= 0.0:
        _reject("reset timeout must be positive and finite")


def _validate_tcp_common(
    *,
    command_id: object,
    left_tcp_target_m_deg: np.ndarray,
    left_gripper_target: float,
    right_tcp_target_m_deg: np.ndarray,
    right_gripper_target: float,
    duration_s: float,
    created_at_monotonic_s: float,
    config: ControllerConfig,
) -> None:
    _validate_command_id(command_id)
    duration_s = _finite_value(duration_s, field="duration_s")
    if duration_s <= 0.0:
        _reject(f"duration must be positive and finite, got {duration_s}")
    _finite_value(created_at_monotonic_s, field="created_at_monotonic_s")
    _validate_tcp_targets(
        left_tcp_target_m_deg,
        side="left",
        lower_limits=config.ros2.tcp_limit_low_m_deg[:6],
        upper_limits=config.ros2.tcp_limit_high_m_deg[:6],
    )
    _validate_raw_gripper(left_gripper_target, side="left")
    _validate_tcp_targets(
        right_tcp_target_m_deg,
        side="right",
        lower_limits=config.ros2.tcp_limit_low_m_deg[6:],
        upper_limits=config.ros2.tcp_limit_high_m_deg[6:],
    )
    _validate_raw_gripper(right_gripper_target, side="right")


def validate_tcp_command(command: DualArmTcpCommand, config: ControllerConfig) -> None:
    """Validate one TCP-space policy command without modifying it."""

    _validate_tcp_common(
        command_id=command.command_id,
        left_tcp_target_m_deg=command.left_tcp_target_m_deg,
        left_gripper_target=command.left_gripper_target,
        right_tcp_target_m_deg=command.right_tcp_target_m_deg,
        right_gripper_target=command.right_gripper_target,
        duration_s=command.duration_s,
        created_at_monotonic_s=command.created_at_monotonic_s,
        config=config,
    )


def validate_tcp_reset_command(
    command: DualArmTcpResetCommand, config: ControllerConfig
) -> None:
    """Validate one TCP-space reset command without modifying it."""

    _validate_tcp_common(
        command_id=command.command_id,
        left_tcp_target_m_deg=command.left_tcp_target_m_deg,
        left_gripper_target=command.left_gripper_target,
        right_tcp_target_m_deg=command.right_tcp_target_m_deg,
        right_gripper_target=command.right_gripper_target,
        duration_s=command.duration_s,
        created_at_monotonic_s=command.created_at_monotonic_s,
        config=config,
    )
    _validate_tcp_targets(
        command.tcp_tolerance_m_deg,
        side="reset tolerance",
        lower_limits=(0.0,) * 6,
        upper_limits=(1_000_000.0,) * 6,
    )
    gripper_tolerance = _finite_value(
        command.gripper_tolerance, field="gripper_tolerance"
    )
    if gripper_tolerance <= 0.0:
        _reject("gripper_tolerance must be positive and finite")
    timeout_s = _finite_value(command.timeout_s, field="timeout_s")
    if timeout_s <= 0.0:
        _reject("reset timeout must be positive and finite")
