"""Validation for coherent, fresh robot observations."""

from collections.abc import Mapping
from math import isfinite
from numbers import Real

import numpy as np

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.errors import ObservationUnavailableError
from f1_robot_controller.types import RobotObservation

REQUIRED_SENSOR_KEYS = (
    "left_joint_position",
    "left_gripper_position",
    "right_joint_position",
    "right_gripper_position",
    "head_color",
    "left_wrist_color",
    "right_wrist_color",
)
OPTIONAL_TCP_SENSOR_KEYS = (
    "left_tcp_pose",
    "right_tcp_pose",
)

_JOINT_SENSORS = {
    "left_joint_position": "left_joint_position_rad",
    "right_joint_position": "right_joint_position_rad",
}
_GRIPPER_SENSORS = {
    "left_gripper_position": "left_gripper_position",
    "right_gripper_position": "right_gripper_position",
}
_IMAGE_SENSORS = {
    "head_color": "head_color_rgb",
    "left_wrist_color": "left_wrist_color_rgb",
    "right_wrist_color": "right_wrist_color_rgb",
}
_TCP_POSE_SENSORS = {
    "left_tcp_pose": "left_tcp_pose_m_deg",
    "right_tcp_pose": "right_tcp_pose_m_deg",
}


def _reject(message: str) -> None:
    raise ObservationUnavailableError(message)


def _finite_value(value: object, *, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        _reject(f"{field} must be a finite real number")
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError):
        _reject(f"{field} must be a finite real number")
    if not isfinite(converted):
        _reject(f"{field} must be a finite real number")
    return converted


def _observed_sensor_keys(observation: RobotObservation) -> tuple[str, ...]:
    sensors = list(REQUIRED_SENSOR_KEYS)
    for sensor, attribute in _TCP_POSE_SENSORS.items():
        if getattr(observation, attribute) is not None:
            sensors.append(sensor)
    return tuple(sensors)


def _missing_sensor_names(
    values: Mapping[str, float],
    sensor_keys: tuple[str, ...],
) -> list[str]:
    return [sensor for sensor in sensor_keys if sensor not in values]


def _validate_timestamps(
    observation: RobotObservation,
    *,
    now_monotonic_s: float,
    max_age_s: float,
    max_skew_s: float,
    newer_than_s: float | None,
) -> None:
    sensor_keys = _observed_sensor_keys(observation)
    source = observation.timestamps.source_timestamp_s
    received = observation.timestamps.received_at_monotonic_s
    missing_source = _missing_sensor_names(source, sensor_keys)
    missing_received = _missing_sensor_names(received, sensor_keys)
    if missing_source or missing_received:
        missing = list(dict.fromkeys(missing_source + missing_received))
        _reject(f"missing sensor timestamps: {', '.join(missing)}")

    source_values = {
        sensor: _finite_value(source[sensor], field=f"{sensor} source timestamp")
        for sensor in sensor_keys
    }
    received_values = {
        sensor: _finite_value(received[sensor], field=f"{sensor} received timestamp")
        for sensor in sensor_keys
    }

    future = [
        sensor for sensor in sensor_keys if received_values[sensor] > now_monotonic_s
    ]
    if future:
        _reject(f"future sensor receipt timestamps: {', '.join(future)}")

    stale = [
        sensor
        for sensor in sensor_keys
        if now_monotonic_s - received_values[sensor] > max_age_s
    ]
    if stale:
        _reject(f"stale sensors: {', '.join(stale)}")

    if newer_than_s is not None:
        old = [
            sensor for sensor in sensor_keys if received_values[sensor] <= newer_than_s
        ]
        if old:
            _reject(f"sensors not newer than {newer_than_s}: {', '.join(old)}")

    if max(source_values.values()) - min(source_values.values()) > max_skew_s:
        _reject(
            "source timestamp skew exceeds limit for sensors: " + ", ".join(sensor_keys)
        )


def _validate_joint_sensors(observation: RobotObservation) -> None:
    for sensor, attribute in _JOINT_SENSORS.items():
        try:
            values = np.asarray(getattr(observation, attribute))
        except (TypeError, ValueError):
            _reject(f"invalid {sensor} joint dimensions")
        if values.shape != (7,):
            _reject(f"{sensor} must have dimension 7, got {values.shape}")
        if not (
            np.issubdtype(values.dtype, np.floating)
            or np.issubdtype(values.dtype, np.integer)
        ):
            _reject(f"{sensor} must contain real numeric joints")
        for index, value in enumerate(values):
            _finite_value(value, field=f"{sensor} joint {index}")

    for sensor, attribute in _GRIPPER_SENSORS.items():
        value = _finite_value(getattr(observation, attribute), field=sensor)
        if not 0.0 <= value <= 100.0:
            _reject(f"invalid {sensor}: expected a finite value in [0, 100]")


def _validate_images(
    observation: RobotObservation,
    config: ControllerConfig,
    image_shapes: Mapping[str, tuple[int, int, int]] | None,
) -> None:
    default_shape = (config.fake.image_height, config.fake.image_width, 3)
    for sensor, attribute in _IMAGE_SENSORS.items():
        expected = default_shape if image_shapes is None else image_shapes[sensor]
        try:
            image = np.asarray(getattr(observation, attribute))
        except (TypeError, ValueError):
            _reject(f"{sensor} image must be an array")
        if image.shape != expected:
            _reject(f"{sensor} image shape must be {expected}, got {image.shape}")
        if image.dtype != np.uint8:
            _reject(f"{sensor} image must have dtype uint8, got {image.dtype}")


def _validate_tcp_pose_sensors(observation: RobotObservation) -> None:
    for sensor, attribute in _TCP_POSE_SENSORS.items():
        value = getattr(observation, attribute)
        if value is None:
            continue
        try:
            values = np.asarray(value)
        except (TypeError, ValueError):
            _reject(f"{sensor} must be a canonical TCP pose")
        if values.shape != (6,):
            _reject(f"{sensor} must have dimension 6, got {values.shape}")
        if not (
            np.issubdtype(values.dtype, np.floating)
            or np.issubdtype(values.dtype, np.integer)
        ):
            _reject(f"{sensor} must contain real numeric TCP pose values")
        for index, value in enumerate(values):
            _finite_value(value, field=f"{sensor} value {index}")


def validate_observation(
    observation: RobotObservation,
    config: ControllerConfig,
    now_monotonic_s: float,
    max_age_s: float | None = None,
    max_skew_s: float | None = None,
    newer_than_s: float | None = None,
    image_shapes: Mapping[str, tuple[int, int, int]] | None = None,
) -> None:
    """Validate observation dimensions, image payloads, and freshness.

    Args:
        observation: Observation to validate.
        config: Controller image dimensions.
        now_monotonic_s: Current local monotonic timestamp.
        max_age_s: Maximum allowed receipt age; defaults to ``config``.
        max_skew_s: Maximum allowed source timestamp skew; defaults to ``config``.
        newer_than_s: Optional receipt timestamp lower bound.

    Raises:
        ObservationUnavailableError: If any sensor data is invalid or stale.
    """

    max_age_s = config.max_observation_age_s if max_age_s is None else max_age_s
    max_skew_s = config.max_observation_skew_s if max_skew_s is None else max_skew_s
    now_monotonic_s = _finite_value(now_monotonic_s, field="now_monotonic_s")
    max_age_s = _finite_value(max_age_s, field="max_age_s")
    max_skew_s = _finite_value(max_skew_s, field="max_skew_s")
    if max_age_s < 0.0:
        _reject("max_age_s must be finite and non-negative")
    if max_skew_s < 0.0:
        _reject("max_skew_s must be finite and non-negative")
    if newer_than_s is not None:
        newer_than_s = _finite_value(newer_than_s, field="newer_than_s")

    _validate_joint_sensors(observation)
    _validate_tcp_pose_sensors(observation)
    _validate_images(observation, config, image_shapes)
    _validate_timestamps(
        observation,
        now_monotonic_s=now_monotonic_s,
        max_age_s=max_age_s,
        max_skew_s=max_skew_s,
        newer_than_s=newer_than_s,
    )
