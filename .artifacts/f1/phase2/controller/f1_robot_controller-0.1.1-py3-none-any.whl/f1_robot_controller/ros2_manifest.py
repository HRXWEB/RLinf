# Copyright 2026 The RLinf Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Capture and validate the F1 Gate-1 read-only ROS 2 interface manifest."""

import argparse
import hashlib
import json
import math
import os
import stat
import time
import uuid
from collections.abc import Callable, Sequence
from contextlib import suppress
from datetime import UTC, datetime
from pathlib import Path
from typing import NamedTuple

SCHEMA_VERSION = "f1-ros2-readonly-manifest-v2"
MINIMUM_CAPTURE_DURATION_S = 60.0
DEFAULT_DISCOVERY_STABILITY_INTERVAL_S = 1.0
DEFAULT_FRESHNESS_TOLERANCE_S = 5.0
MAXIMUM_FRESHNESS_TOLERANCE_S = 5.0
MAX_GRAPH_CHANGE_DIAGNOSTIC_BYTES = 4000
RAW_IMAGE_MESSAGE_TYPE = "sensor_msgs/msg/Image"
COMPRESSED_IMAGE_MESSAGE_TYPE = "sensor_msgs/msg/CompressedImage"
IMAGE_MESSAGE_TYPE = RAW_IMAGE_MESSAGE_TYPE
JOINT_STATE_MESSAGE_TYPE = "sensor_msgs/msg/JointState"
LEFT_JOINT_NAMES = tuple(f"arm_l_j{index}" for index in range(1, 8))
RIGHT_JOINT_NAMES = tuple(f"arm_r_j{index}" for index in range(1, 8))
REQUIRED_LOGICAL_SOURCES = frozenset(
    {
        "head_color",
        "left_wrist_color",
        "right_wrist_color",
        "left_joint_position",
        "right_joint_position",
        "left_gripper_position",
        "right_gripper_position",
    }
)
_IMAGE_SOURCES = frozenset({"head_color", "left_wrist_color", "right_wrist_color"})
_GRIPPER_SOURCES = frozenset({"left_gripper_position", "right_gripper_position"})
_PHYSICAL_SOURCES = frozenset({*_IMAGE_SOURCES, "joint_states", *_GRIPPER_SOURCES})
_QOS_FIELDS = frozenset({"depth", "durability", "history", "reliability"})


class TargetSpec(NamedTuple):
    """One expected physical sensor endpoint."""

    topic: str
    message_type: str
    logical_sources: tuple[str, ...]
    durability: str
    image_transport: str | None = None


DEFAULT_TARGETS = {
    "head_color": TargetSpec(
        "/camera/head/color/image_raw",
        IMAGE_MESSAGE_TYPE,
        ("head_color",),
        "volatile",
        "raw",
    ),
    "left_wrist_color": TargetSpec(
        "/camera/left_wrist/color/image_raw",
        IMAGE_MESSAGE_TYPE,
        ("left_wrist_color",),
        "transient_local",
        "raw",
    ),
    "right_wrist_color": TargetSpec(
        "/camera/right_wrist/color/image_raw",
        IMAGE_MESSAGE_TYPE,
        ("right_wrist_color",),
        "transient_local",
        "raw",
    ),
    "joint_states": TargetSpec(
        "/hal/joint_states",
        JOINT_STATE_MESSAGE_TYPE,
        ("left_joint_position", "right_joint_position"),
        "volatile",
    ),
    "left_gripper_position": TargetSpec(
        "/motion_ctl/gripper/left/state",
        JOINT_STATE_MESSAGE_TYPE,
        ("left_gripper_position",),
        "volatile",
    ),
    "right_gripper_position": TargetSpec(
        "/motion_ctl/gripper/right/state",
        JOINT_STATE_MESSAGE_TYPE,
        ("right_gripper_position",),
        "volatile",
    ),
}


def _require_exact_fields(
    payload: dict[str, object], expected: frozenset[str], label: str
) -> None:
    """Require a closed JSON object schema."""

    actual = frozenset(payload)
    extras = actual - expected
    if extras:
        raise ValueError(f"{label} contains unrecognized field {sorted(extras)[0]}")
    missing = expected - actual
    if missing:
        raise ValueError(f"{label} is missing field {sorted(missing)[0]}")


def _finite_number(value: object, label: str, *, minimum: float | None = None) -> float:
    """Return one finite JSON number, rejecting booleans."""

    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a finite number")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{label} must be finite")
    if minimum is not None and number < minimum:
        raise ValueError(f"{label} must be >= {minimum}")
    return number


def _integer(value: object, label: str, *, minimum: int = 0) -> int:
    """Return one bounded integer without accepting booleans."""

    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")
    return value


def _validated_freshness_tolerance(value: object, duration_s: float) -> float:
    """Return a positive, bounded capture-window freshness tolerance."""

    tolerance_s = _finite_number(value, "freshness_tolerance_s", minimum=0.0)
    if tolerance_s <= 0.0 or tolerance_s > MAXIMUM_FRESHNESS_TOLERANCE_S:
        raise ValueError("freshness_tolerance_s must be in (0, 5]")
    if duration_s < 2 * tolerance_s:
        raise ValueError("duration_s must be at least twice freshness_tolerance_s")
    return tolerance_s


def _validated_discovery_settings(
    timeout_s: object, stability_interval_s: object
) -> tuple[float, float]:
    """Return finite discovery settings that permit a stable second snapshot."""

    timeout = _finite_number(timeout_s, "discovery_timeout_s", minimum=0.0)
    interval = _finite_number(
        stability_interval_s,
        "discovery_stability_interval_s",
        minimum=0.0,
    )
    if timeout <= 0.0:
        raise ValueError("discovery_timeout_s must be finite and positive")
    if interval <= 0.0:
        raise ValueError("discovery_stability_interval_s must be finite and positive")
    if timeout <= interval:
        raise ValueError(
            "discovery_timeout_s must be greater than discovery_stability_interval_s"
        )
    return timeout, interval


def percentiles(values: Sequence[float]) -> dict[str, float]:
    """Return linearly interpolated P50/P95/P99 values.

    Args:
        values: Non-empty finite sample sequence.

    Returns:
        A JSON-ready object containing P50, P95, and P99.

    Raises:
        ValueError: If the input is empty or contains a non-finite number.
    """

    if not values:
        raise ValueError("percentile samples must not be empty")
    ordered = sorted(_finite_number(value, "percentile sample") for value in values)

    def interpolate(quantile: float) -> float:
        index = (len(ordered) - 1) * quantile
        lower = math.floor(index)
        upper = math.ceil(index)
        if lower == upper:
            return ordered[lower]
        fraction = index - lower
        return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction

    return {
        "p50": interpolate(0.50),
        "p95": interpolate(0.95),
        "p99": interpolate(0.99),
    }


def _validate_qos(qos: object, label: str) -> None:
    """Require discovered publisher QoS evidence to be complete and usable."""

    if not isinstance(qos, dict):
        raise ValueError(f"{label} QoS must be an object")
    _require_exact_fields(qos, _QOS_FIELDS, f"{label} QoS")
    _integer(qos["depth"], f"{label} QoS depth", minimum=1)
    allowed = {
        "durability": {"volatile", "transient_local"},
        "history": {"keep_last"},
        "reliability": {"reliable", "best_effort"},
    }
    for field, values in allowed.items():
        if qos[field] not in values:
            raise ValueError(f"{label} QoS {field} is unsupported")


def _validate_publishers_have_consistent_qos(
    publishers: list[dict[str, object]], physical_source: str
) -> None:
    """Fail closed when one source has publishers with incompatible QoS."""

    baseline = publishers[0]["qos"]
    for publisher in publishers[1:]:
        qos = publisher["qos"]
        if qos != baseline:
            changed_fields = sorted(
                field for field in _QOS_FIELDS if qos[field] != baseline[field]
            )
            raise ValueError(
                f"{physical_source} publisher QoS changed fields "
                f"{','.join(changed_fields)} across endpoints"
            )


def _string_list(value: object, label: str, *, unique: bool = False) -> list[str]:
    """Validate and return one JSON string list."""

    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item for item in value
    ):
        raise ValueError(f"{label} must be a list of non-empty strings")
    if unique and len(set(value)) != len(value):
        raise ValueError(f"{label} must contain unique values")
    return value


def _number_list(value: object, label: str) -> list[float]:
    """Validate and return one finite JSON number list."""

    if not isinstance(value, list):
        raise ValueError(f"{label} must be a list")
    return [_finite_number(item, f"{label} item") for item in value]


class ManifestAccumulator:
    """Collect live message metadata and timing without depending on ROS."""

    def __init__(self, targets: dict[str, TargetSpec]) -> None:
        """Initialize an empty capture for exactly six physical sources."""

        if frozenset(targets) != _PHYSICAL_SOURCES:
            raise ValueError("targets must define exactly the six physical sources")
        topics = [target.topic for target in targets.values()]
        if any(not topic.startswith("/") for topic in topics):
            raise ValueError("target topics must be absolute ROS names")
        if len(set(topics)) != len(topics):
            raise ValueError("target topics must be unique")
        self._targets = dict(targets)
        self._physical: dict[str, dict[str, object]] = {}
        self._logical: dict[str, dict[str, object]] = {
            source: {
                "latest_message": None,
                "receive_times": [],
                "source_timestamps": [],
            }
            for source in REQUIRED_LOGICAL_SOURCES
        }
        self._skew_samples: list[float] = []
        self._skew_sample_counts = dict.fromkeys(REQUIRED_LOGICAL_SOURCES, 0)

    def record_discovery(
        self,
        *,
        physical_source: str,
        graph_types: list[str],
        publishers: list[dict[str, object]],
    ) -> None:
        """Record and verify graph types and publisher endpoint discovery."""

        target = self._target(physical_source)
        if graph_types != [target.message_type]:
            raise ValueError(
                f"{physical_source} message type conflicts with {target.message_type}"
            )
        if not publishers:
            raise ValueError(f"{physical_source} has no publisher endpoints")
        normalized_publishers: list[dict[str, object]] = []
        expected_fields = frozenset(
            {"endpoint_gid", "node_name", "node_namespace", "qos", "topic_type"}
        )
        for index, publisher in enumerate(publishers):
            if not isinstance(publisher, dict):
                raise ValueError(
                    f"{physical_source} publisher {index} must be an object"
                )
            _require_exact_fields(
                publisher, expected_fields, f"{physical_source} publisher {index}"
            )
            for field in ("endpoint_gid", "node_name", "node_namespace", "topic_type"):
                if not isinstance(publisher[field], str) or not publisher[field]:
                    raise ValueError(
                        f"{physical_source} publisher {index} {field} must be non-empty"
                    )
            if publisher["topic_type"] != target.message_type:
                raise ValueError(f"{physical_source} publisher message type conflicts")
            _validate_qos(publisher["qos"], f"{physical_source} publisher {index}")
            normalized_publishers.append(copy_json_object(publisher))
        _validate_publishers_have_consistent_qos(normalized_publishers, physical_source)
        self._physical[physical_source] = {
            "graph_types": list(graph_types),
            "latest_message": None,
            "publishers": normalized_publishers,
            "sample_count": 0,
        }

    def record_image(
        self,
        physical_source: str,
        *,
        received_at_s: float,
        source_timestamp_s: float,
        frame_id: str,
        encoding: str,
        height: int,
        width: int,
        step: int,
        data_length: int,
    ) -> None:
        """Record one complete image message metadata sample."""

        if physical_source not in _IMAGE_SOURCES:
            raise ValueError(f"{physical_source} is not an image source")
        if not frame_id or not encoding:
            raise ValueError(
                f"{physical_source} image frame_id and encoding are required"
            )
        for value, label in (
            (height, "height"),
            (width, "width"),
            (step, "step"),
            (data_length, "data_length"),
        ):
            _integer(value, f"{physical_source} image {label}", minimum=1)
        if data_length != height * step:
            raise ValueError(f"{physical_source} image data length is malformed")
        message = {
            "data_length": data_length,
            "encoding": encoding,
            "frame_id": frame_id,
            "height": height,
            "step": step,
            "width": width,
        }
        self._record_physical(physical_source, message)
        self._record_logical(
            physical_source,
            received_at_s=received_at_s,
            source_timestamp_s=source_timestamp_s,
            latest_message=message,
        )
        self._sample_skew()

    def record_compressed_image(
        self,
        physical_source: str,
        *,
        received_at_s: float,
        source_timestamp_s: float,
        frame_id: str,
        format: str,
        data_length: int,
    ) -> None:
        """Record one compressed image message metadata sample."""

        if physical_source not in _IMAGE_SOURCES:
            raise ValueError(f"{physical_source} is not an image source")
        if not isinstance(frame_id, str):
            raise ValueError(f"{physical_source} compressed image frame_id is required")
        if not isinstance(format, str) or not format:
            raise ValueError(f"{physical_source} compressed image format is required")
        _integer(
            data_length,
            f"{physical_source} compressed image data_length",
            minimum=1,
        )
        message = {
            "data_length": data_length,
            "format": format,
            "frame_id": frame_id,
        }
        self._record_physical(physical_source, message)
        self._record_logical(
            physical_source,
            received_at_s=received_at_s,
            source_timestamp_s=source_timestamp_s,
            latest_message=message,
        )
        self._sample_skew()

    def record_joint_state(
        self,
        *,
        received_at_s: float,
        source_timestamp_s: float,
        frame_id: str,
        names: Sequence[str],
        positions: Sequence[float],
        velocities: Sequence[float],
        efforts: Sequence[float],
    ) -> None:
        """Atomically map one shared JointState into both arm sources."""

        message = self._joint_message(
            "joint_states", frame_id, names, positions, velocities, efforts
        )
        name_to_index = {name: index for index, name in enumerate(message["names"])}
        missing = (set(LEFT_JOINT_NAMES) | set(RIGHT_JOINT_NAMES)) - set(name_to_index)
        if missing:
            raise ValueError(
                f"joint_states is missing required joint {sorted(missing)[0]}"
            )
        self._record_physical("joint_states", message)
        for logical_source, selected_names in (
            ("left_joint_position", LEFT_JOINT_NAMES),
            ("right_joint_position", RIGHT_JOINT_NAMES),
        ):
            selected_positions = [
                message["positions"][name_to_index[name]] for name in selected_names
            ]
            self._record_logical(
                logical_source,
                received_at_s=received_at_s,
                source_timestamp_s=source_timestamp_s,
                latest_message={
                    "selected_names": list(selected_names),
                    "selected_positions": selected_positions,
                },
            )
        self._sample_skew()

    def record_gripper_state(
        self,
        physical_source: str,
        *,
        received_at_s: float,
        source_timestamp_s: float,
        frame_id: str,
        names: Sequence[str],
        positions: Sequence[float],
        velocities: Sequence[float],
        efforts: Sequence[float],
    ) -> None:
        """Record one gripper JointState including its raw fields and value."""

        if physical_source not in _GRIPPER_SOURCES:
            raise ValueError(f"{physical_source} is not a gripper source")
        message = self._joint_message(
            physical_source, frame_id, names, positions, velocities, efforts
        )
        if message["names"].count(physical_source) != 1:
            raise ValueError(
                f"{physical_source} must contain exactly one matching position field"
            )
        index = message["names"].index(physical_source)
        self._record_physical(physical_source, message)
        self._record_logical(
            physical_source,
            received_at_s=received_at_s,
            source_timestamp_s=source_timestamp_s,
            latest_message={
                "field_name": physical_source,
                "raw_position": message["positions"][index],
            },
        )
        self._sample_skew()

    def build_manifest(
        self,
        *,
        started_monotonic_s: float,
        ended_monotonic_s: float,
        captured_at: str,
        capture_node: dict[str, object],
        discovery: dict[str, object],
        observed_nodes: list[dict[str, str]],
        freshness_tolerance_s: float = DEFAULT_FRESHNESS_TOLERANCE_S,
    ) -> dict[str, object]:
        """Build and validate one complete manifest from collected evidence."""

        duration_s = _finite_number(ended_monotonic_s, "ended_monotonic_s") - (
            _finite_number(started_monotonic_s, "started_monotonic_s")
        )
        tolerance_s = _validated_freshness_tolerance(freshness_tolerance_s, duration_s)
        physical_topics: dict[str, object] = {}
        for physical_source, target in self._targets.items():
            if physical_source not in self._physical:
                raise ValueError(f"{physical_source} discovery is missing")
            state = self._physical[physical_source]
            physical_topics[physical_source] = {
                "graph_types": state["graph_types"],
                "latest_message": state["latest_message"],
                "logical_sources": list(target.logical_sources),
                "message_type": target.message_type,
                "publishers": state["publishers"],
                "sample_count": state["sample_count"],
                "topic": target.topic,
            }
            if target.image_transport is not None:
                physical_topics[physical_source]["image_transport"] = (
                    target.image_transport
                )
        logical_sources: dict[str, object] = {}
        for source in sorted(REQUIRED_LOGICAL_SOURCES):
            state = self._logical[source]
            receive_times = state["receive_times"]
            if len(receive_times) < 2:
                raise ValueError(f"{source} sample_count is insufficient")
            intervals = [
                later - earlier
                for earlier, later in zip(
                    receive_times,
                    receive_times[1:],
                    strict=False,
                )
            ]
            physical_source = (
                "joint_states" if source.endswith("joint_position") else source
            )
            target = self._targets[physical_source]
            first_offset_s = receive_times[0] - started_monotonic_s
            last_offset_s = receive_times[-1] - started_monotonic_s
            logical_sources[source] = {
                "conversion": (
                    {
                        "canonical_unit": "radian",
                        "scale": math.pi / 180.0,
                        "source_unit": "degree",
                    }
                    if source.endswith("joint_position")
                    else None
                ),
                "latest_message": state["latest_message"],
                "first_received_at_offset_s": first_offset_s,
                "last_received_at_offset_s": last_offset_s,
                "measured_frequency_hz": (len(receive_times) - 1)
                / (receive_times[-1] - receive_times[0]),
                "message_type": target.message_type,
                "physical_source": physical_source,
                "observed_span_s": last_offset_s - first_offset_s,
                "receive_interval_s": percentiles(intervals),
                "sample_count": len(receive_times),
                "source_timestamp": {
                    "available": len(state["source_timestamps"]) == len(receive_times),
                    "latest_s": state["source_timestamps"][-1],
                    "sample_count": len(state["source_timestamps"]),
                },
                "topic": target.topic,
            }
        payload = {
            "capture_node": copy_json_object(capture_node),
            "captured_at": captured_at,
            "command_endpoints": 0,
            "controller_config": controller_config_from_manifest_topics(
                physical_topics,
                control_period_s=0.1,
                max_observation_age_s=0.25,
                max_observation_skew_s=0.05,
            ),
            "cross_source_skew_s": {
                "basis": "ros_source_timestamp",
                "method": "one_sample_after_each_logical_source_advanced",
                **percentiles(self._skew_samples),
                "sample_count": len(self._skew_samples),
            },
            "discovery": copy_json_object(discovery),
            "duration_s": duration_s,
            "freshness_tolerance_s": tolerance_s,
            "logical_source_count": len(logical_sources),
            "logical_sources": logical_sources,
            "observed_nodes": copy_json_array(observed_nodes),
            "physical_topic_count": len(physical_topics),
            "physical_topics": physical_topics,
            "schema_version": SCHEMA_VERSION,
        }
        validate_manifest(payload)
        return payload

    def _target(self, physical_source: str) -> TargetSpec:
        try:
            return self._targets[physical_source]
        except KeyError as error:
            raise ValueError(f"unknown physical source {physical_source}") from error

    def _record_physical(
        self, physical_source: str, latest_message: dict[str, object]
    ) -> None:
        if physical_source not in self._physical:
            raise ValueError(f"{physical_source} must be discovered before sampling")
        state = self._physical[physical_source]
        previous = state["latest_message"]
        if (
            previous is not None
            and physical_source in _IMAGE_SOURCES
            and not self._image_metadata_matches(
                physical_source,
                previous,
                latest_message,
            )
        ):
            raise ValueError(f"{physical_source} image metadata changed during capture")
        state["latest_message"] = copy_json_object(latest_message)
        state["sample_count"] += 1

    def _image_metadata_matches(
        self,
        physical_source: str,
        previous: object,
        latest_message: dict[str, object],
    ) -> bool:
        target = self._target(physical_source)
        if target.image_transport != "compressed":
            return previous == latest_message
        if not isinstance(previous, dict):
            return False
        stable_previous = {key: previous.get(key) for key in ("format", "frame_id")}
        stable_latest = {key: latest_message.get(key) for key in ("format", "frame_id")}
        return stable_previous == stable_latest

    def _record_logical(
        self,
        logical_source: str,
        *,
        received_at_s: float,
        source_timestamp_s: float,
        latest_message: dict[str, object],
    ) -> None:
        received = _finite_number(
            received_at_s, f"{logical_source} receive timestamp", minimum=0.0
        )
        source = _finite_number(
            source_timestamp_s, f"{logical_source} source timestamp", minimum=0.0
        )
        if source <= 0.0:
            raise ValueError(f"{logical_source} source timestamp must be available")
        state = self._logical[logical_source]
        receive_times = state["receive_times"]
        if receive_times and received <= receive_times[-1]:
            raise ValueError(f"{logical_source} receive timestamps must increase")
        state["receive_times"].append(received)
        state["source_timestamps"].append(source)
        state["latest_message"] = copy_json_object(latest_message)

    def _sample_skew(self) -> None:
        if not all(
            len(self._logical[source]["source_timestamps"])
            > self._skew_sample_counts[source]
            for source in REQUIRED_LOGICAL_SOURCES
        ):
            return
        timestamps = [
            self._logical[source]["source_timestamps"][-1]
            for source in REQUIRED_LOGICAL_SOURCES
        ]
        self._skew_samples.append(max(timestamps) - min(timestamps))
        self._skew_sample_counts = {
            source: len(self._logical[source]["source_timestamps"])
            for source in REQUIRED_LOGICAL_SOURCES
        }

    @staticmethod
    def _joint_message(
        source: str,
        frame_id: str,
        names: Sequence[str],
        positions: Sequence[float],
        velocities: Sequence[float],
        efforts: Sequence[float],
    ) -> dict[str, object]:
        if not isinstance(frame_id, str):
            raise ValueError(f"{source} frame_id must be a string")
        names_list = list(names)
        if any(not isinstance(name, str) or not name for name in names_list):
            raise ValueError(f"{source} names must be non-empty strings")
        if len(set(names_list)) != len(names_list):
            raise ValueError(f"{source} names must be unique")
        position_list = [
            _finite_number(value, f"{source} position") for value in positions
        ]
        velocity_list = [
            _finite_number(value, f"{source} velocity") for value in velocities
        ]
        effort_list = [_finite_number(value, f"{source} effort") for value in efforts]
        if len(position_list) != len(names_list):
            raise ValueError(f"{source} name and position array lengths conflict")
        if len(velocity_list) not in (0, len(names_list)):
            raise ValueError(f"{source} velocity array length is malformed")
        if len(effort_list) not in (0, len(names_list)):
            raise ValueError(f"{source} effort array length is malformed")
        return {
            "array_lengths": {
                "effort": len(effort_list),
                "name": len(names_list),
                "position": len(position_list),
                "velocity": len(velocity_list),
            },
            "efforts": effort_list,
            "frame_id": frame_id,
            "names": names_list,
            "positions": position_list,
            "velocities": velocity_list,
        }


def copy_json_object(value: dict[str, object]) -> dict[str, object]:
    """Return a detached JSON-compatible object."""

    return json.loads(json.dumps(value, allow_nan=False))


def copy_json_array(value: list[dict[str, str]]) -> list[dict[str, str]]:
    """Return a detached JSON-compatible array."""

    return json.loads(json.dumps(value, allow_nan=False))


def controller_config_from_manifest_topics(
    physical_topics: dict[str, object],
    *,
    control_period_s: float,
    max_observation_age_s: float,
    max_observation_skew_s: float,
) -> dict[str, object]:
    """Project manifest topic evidence into a read-only controller config JSON."""

    sensor_topics = {
        ("joint_state" if source == "joint_states" else source): topic["topic"]
        for source, topic in physical_topics.items()
    }
    qos_by_source = {
        ("joint_state" if source == "joint_states" else source): topic["publishers"][0][
            "qos"
        ]
        for source, topic in physical_topics.items()
    }
    image_transports = {
        source: physical_topics[source]["image_transport"] for source in _IMAGE_SOURCES
    }
    return {
        "control_period_s": control_period_s,
        "max_observation_age_s": max_observation_age_s,
        "max_observation_skew_s": max_observation_skew_s,
        "ros2": {
            "image_shapes": {
                "head_color": [720, 1280, 3],
                "left_wrist_color": [480, 848, 3],
                "right_wrist_color": [480, 848, 3],
            },
            "image_transports": image_transports,
            "joint_position_scale_to_rad": math.pi / 180.0,
            "left_gripper_raw_closed": 100.0,
            "left_gripper_raw_open": 0.0,
            "left_joint_names": list(LEFT_JOINT_NAMES),
            "node_name": "f1_robot_controller_readonly",
            "qos_by_source": qos_by_source,
            "read_only": True,
            "right_gripper_raw_closed": 100.0,
            "right_gripper_raw_open": 0.0,
            "right_joint_names": list(RIGHT_JOINT_NAMES),
            "sensor_topics": sensor_topics,
        },
    }


def _validate_stats(value: object, label: str) -> None:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be an object")
    _require_exact_fields(value, frozenset({"p50", "p95", "p99"}), label)
    p50 = _finite_number(value["p50"], f"{label} p50", minimum=0.0)
    p95 = _finite_number(value["p95"], f"{label} p95", minimum=0.0)
    p99 = _finite_number(value["p99"], f"{label} p99", minimum=0.0)
    if not p50 <= p95 <= p99:
        raise ValueError(f"{label} percentiles must be ordered")


def _validate_controller_config_projection(value: object) -> None:
    """Validate the manifest's closed read-only ControllerConfig projection."""

    if not isinstance(value, dict):
        raise ValueError("controller_config must be an object")
    _require_exact_fields(
        value,
        frozenset(
            {
                "control_period_s",
                "max_observation_age_s",
                "max_observation_skew_s",
                "ros2",
            }
        ),
        "controller_config",
    )
    _finite_number(
        value["control_period_s"],
        "controller_config control_period_s",
        minimum=0.0,
    )
    _finite_number(
        value["max_observation_age_s"],
        "controller_config max_observation_age_s",
        minimum=0.0,
    )
    _finite_number(
        value["max_observation_skew_s"],
        "controller_config max_observation_skew_s",
        minimum=0.0,
    )
    ros2 = value["ros2"]
    if not isinstance(ros2, dict):
        raise ValueError("controller_config ros2 must be an object")
    _require_exact_fields(
        ros2,
        frozenset(
            {
                "image_shapes",
                "image_transports",
                "joint_position_scale_to_rad",
                "left_gripper_raw_closed",
                "left_gripper_raw_open",
                "left_joint_names",
                "node_name",
                "qos_by_source",
                "read_only",
                "right_gripper_raw_closed",
                "right_gripper_raw_open",
                "right_joint_names",
                "sensor_topics",
            }
        ),
        "controller_config ros2",
    )
    if ros2["read_only"] is not True:
        raise ValueError("controller_config ros2 read_only must be true")
    if not isinstance(ros2["node_name"], str) or not ros2["node_name"]:
        raise ValueError("controller_config ros2 node_name must be non-empty")
    _finite_number(
        ros2["joint_position_scale_to_rad"],
        "controller_config ros2 joint_position_scale_to_rad",
    )
    for field in (
        "left_gripper_raw_closed",
        "left_gripper_raw_open",
        "right_gripper_raw_closed",
        "right_gripper_raw_open",
    ):
        _finite_number(ros2[field], f"controller_config ros2 {field}")
    for field in ("left_joint_names", "right_joint_names"):
        names = _string_list(
            ros2[field],
            f"controller_config ros2 {field}",
            unique=True,
        )
        if len(names) != 7:
            raise ValueError(f"controller_config ros2 {field} must contain seven names")
    sensor_keys = frozenset(
        {
            "head_color",
            "left_wrist_color",
            "right_wrist_color",
            "joint_state",
            "left_gripper_position",
            "right_gripper_position",
        }
    )
    sensor_topics = ros2["sensor_topics"]
    if not isinstance(sensor_topics, dict) or frozenset(sensor_topics) != sensor_keys:
        raise ValueError("controller_config ros2 sensor_topics must define six sources")
    if any(
        not isinstance(topic, str) or not topic.startswith("/")
        for topic in sensor_topics.values()
    ):
        raise ValueError("controller_config ros2 sensor_topics must be absolute")
    qos_by_source = ros2["qos_by_source"]
    if not isinstance(qos_by_source, dict) or frozenset(qos_by_source) != sensor_keys:
        raise ValueError("controller_config ros2 qos_by_source must define six sources")
    for source, qos in qos_by_source.items():
        _validate_qos(qos, f"controller_config ros2 {source}")
    image_transports = ros2["image_transports"]
    if (
        not isinstance(image_transports, dict)
        or frozenset(image_transports) != _IMAGE_SOURCES
    ):
        raise ValueError(
            "controller_config ros2 image_transports must define three image sources"
        )
    for source, transport in image_transports.items():
        if transport not in {"raw", "compressed"}:
            raise ValueError(f"controller_config ros2 {source} image_transport")
    image_shapes = ros2["image_shapes"]
    if not isinstance(image_shapes, dict) or frozenset(image_shapes) != _IMAGE_SOURCES:
        raise ValueError("controller_config ros2 image_shapes must define three images")
    for source, shape in image_shapes.items():
        if (
            not isinstance(shape, list)
            or len(shape) != 3
            or shape[2] != 3
            or any(
                isinstance(item, bool) or not isinstance(item, int) or item <= 0
                for item in shape
            )
        ):
            raise ValueError(
                f"controller_config ros2 {source} image_shape must be HxWx3"
            )


def validate_manifest(payload: object) -> None:
    """Validate one closed, complete Gate-1 manifest schema.

    Args:
        payload: Parsed JSON value to validate.

    Raises:
        ValueError: If any safety, provenance, sample, or schema field is invalid.
    """

    if not isinstance(payload, dict):
        raise ValueError("manifest must contain a JSON object")
    _require_exact_fields(
        payload,
        frozenset(
            {
                "capture_node",
                "captured_at",
                "command_endpoints",
                "controller_config",
                "cross_source_skew_s",
                "discovery",
                "duration_s",
                "freshness_tolerance_s",
                "logical_source_count",
                "logical_sources",
                "observed_nodes",
                "physical_topic_count",
                "physical_topics",
                "schema_version",
            }
        ),
        "manifest",
    )
    if payload["schema_version"] != SCHEMA_VERSION:
        raise ValueError("manifest schema_version is unsupported")
    if not isinstance(payload["captured_at"], str) or not payload["captured_at"]:
        raise ValueError("captured_at must be a non-empty string")
    duration = _finite_number(payload["duration_s"], "duration_s", minimum=0.0)
    if duration < MINIMUM_CAPTURE_DURATION_S:
        raise ValueError("duration_s must be at least 60 seconds")
    tolerance_s = _validated_freshness_tolerance(
        payload["freshness_tolerance_s"], duration
    )
    if payload["command_endpoints"] != 0 or isinstance(
        payload["command_endpoints"], bool
    ):
        raise ValueError("command_endpoints must be integer zero")
    _validate_controller_config_projection(payload["controller_config"])
    if payload["physical_topic_count"] != 6:
        raise ValueError("physical_topic_count must be integer 6")
    if payload["logical_source_count"] != 7:
        raise ValueError("logical_source_count must be integer 7")

    discovery = payload["discovery"]
    if not isinstance(discovery, dict):
        raise ValueError("discovery must be an object")
    _require_exact_fields(
        discovery,
        frozenset(
            {
                "consecutive_identical_snapshots",
                "stability_interval_s",
                "stabilized_after_s",
                "timeout_s",
            }
        ),
        "discovery",
    )
    timeout_s, stability_interval_s = _validated_discovery_settings(
        discovery["timeout_s"], discovery["stability_interval_s"]
    )
    stable_count = _integer(
        discovery["consecutive_identical_snapshots"],
        "discovery consecutive_identical_snapshots",
        minimum=2,
    )
    if stable_count < 2:
        raise ValueError("discovery requires at least two identical snapshots")
    stabilized_after_s = _finite_number(
        discovery["stabilized_after_s"],
        "discovery stabilized_after_s",
        minimum=0.0,
    )
    if stabilized_after_s < stability_interval_s or stabilized_after_s > timeout_s:
        raise ValueError("discovery stabilization timing conflicts with settings")

    capture_node = payload["capture_node"]
    if not isinstance(capture_node, dict):
        raise ValueError("capture_node must be an object")
    _require_exact_fields(
        capture_node,
        frozenset(
            {
                "name",
                "namespace",
                "publisher_count",
                "service_client_count",
                "subscription_count",
            }
        ),
        "capture_node",
    )
    if capture_node["publisher_count"] != 0 or isinstance(
        capture_node["publisher_count"], bool
    ):
        raise ValueError("capture_node publisher_count must be integer zero")
    if capture_node["service_client_count"] != 0 or isinstance(
        capture_node["service_client_count"], bool
    ):
        raise ValueError("capture_node service_client_count must be integer zero")
    if capture_node["subscription_count"] != 6:
        raise ValueError("capture_node subscription_count must be integer 6")
    for field in ("name", "namespace"):
        if not isinstance(capture_node[field], str) or not capture_node[field]:
            raise ValueError(f"capture_node {field} must be non-empty")

    observed_nodes = payload["observed_nodes"]
    if not isinstance(observed_nodes, list) or not observed_nodes:
        raise ValueError("observed_nodes must be a non-empty list")
    for node in observed_nodes:
        if not isinstance(node, dict):
            raise ValueError("observed node must be an object")
        _require_exact_fields(node, frozenset({"name", "namespace"}), "observed node")
        if any(not isinstance(node[field], str) or not node[field] for field in node):
            raise ValueError("observed node fields must be non-empty strings")

    physical_topics = payload["physical_topics"]
    if not isinstance(physical_topics, dict) or frozenset(physical_topics) != (
        _PHYSICAL_SOURCES
    ):
        raise ValueError("manifest must contain exactly the six physical topics")
    for physical_source, target in DEFAULT_TARGETS.items():
        topic = physical_topics[physical_source]
        _validate_physical_topic(physical_source, topic, target)
    topics = [topic["topic"] for topic in physical_topics.values()]
    if len(set(topics)) != 6:
        raise ValueError("physical topic names must be unique")

    logical_sources = payload["logical_sources"]
    if not isinstance(logical_sources, dict) or frozenset(logical_sources) != (
        REQUIRED_LOGICAL_SOURCES
    ):
        raise ValueError("manifest must contain exactly the seven logical sources")
    for source, logical in logical_sources.items():
        _validate_logical_source(
            source, logical, physical_topics, duration, tolerance_s
        )

    skew = payload["cross_source_skew_s"]
    if not isinstance(skew, dict):
        raise ValueError("cross_source_skew_s must be an object")
    _require_exact_fields(
        skew,
        frozenset({"basis", "method", "p50", "p95", "p99", "sample_count"}),
        "cross_source_skew_s",
    )
    if skew["basis"] != "ros_source_timestamp":
        raise ValueError("cross_source_skew_s basis must be ros_source_timestamp")
    if skew["method"] != "one_sample_after_each_logical_source_advanced":
        raise ValueError("cross_source_skew_s method is unsupported")
    if _integer(skew["sample_count"], "cross-source sample_count", minimum=1) < 1:
        raise ValueError("cross-source sample_count is insufficient")
    _validate_stats(
        {key: skew[key] for key in ("p50", "p95", "p99")},
        "cross_source_skew_s",
    )


def _validate_physical_topic(
    physical_source: str, value: object, target: TargetSpec
) -> None:
    if not isinstance(value, dict):
        raise ValueError(f"{physical_source} physical topic must be an object")
    _require_exact_fields(
        value,
        frozenset(
            {
                "graph_types",
                "latest_message",
                "logical_sources",
                "message_type",
                "publishers",
                "sample_count",
                "topic",
                *({"image_transport"} if physical_source in _IMAGE_SOURCES else set()),
            }
        ),
        f"{physical_source} physical topic",
    )
    expected_message_type = target.message_type
    if physical_source in _IMAGE_SOURCES:
        if value["image_transport"] not in {"raw", "compressed"}:
            raise ValueError(f"{physical_source} image_transport is unsupported")
        expected_message_type = (
            COMPRESSED_IMAGE_MESSAGE_TYPE
            if value["image_transport"] == "compressed"
            else RAW_IMAGE_MESSAGE_TYPE
        )
    if value["message_type"] != expected_message_type or value["graph_types"] != [
        expected_message_type
    ]:
        raise ValueError(f"{physical_source} message type conflicts")
    if not isinstance(value["topic"], str) or not value["topic"].startswith("/"):
        raise ValueError(f"{physical_source} topic must be an absolute ROS name")
    if value["logical_sources"] != list(target.logical_sources):
        raise ValueError(f"{physical_source} logical source mapping conflicts")
    _integer(value["sample_count"], f"{physical_source} sample_count", minimum=2)
    publishers = value["publishers"]
    if not isinstance(publishers, list) or not publishers:
        raise ValueError(f"{physical_source} publisher discovery is missing")
    for index, publisher in enumerate(publishers):
        if not isinstance(publisher, dict):
            raise ValueError(f"{physical_source} publisher {index} must be an object")
        _require_exact_fields(
            publisher,
            frozenset(
                {"endpoint_gid", "node_name", "node_namespace", "qos", "topic_type"}
            ),
            f"{physical_source} publisher {index}",
        )
        if publisher["topic_type"] != expected_message_type:
            raise ValueError(f"{physical_source} publisher message type conflicts")
        for field in ("endpoint_gid", "node_name", "node_namespace"):
            if not isinstance(publisher[field], str) or not publisher[field]:
                raise ValueError(
                    f"{physical_source} publisher {field} must be non-empty"
                )
        _validate_qos(publisher["qos"], f"{physical_source} publisher {index}")
    _validate_publishers_have_consistent_qos(publishers, physical_source)
    endpoint_gids = [publisher["endpoint_gid"] for publisher in publishers]
    if len(set(endpoint_gids)) != len(endpoint_gids):
        raise ValueError(f"{physical_source} publisher endpoint GIDs must be unique")
    if physical_source in _IMAGE_SOURCES:
        if value["image_transport"] == "compressed":
            _validate_compressed_image_message(value["latest_message"], physical_source)
        else:
            _validate_image_message(value["latest_message"], physical_source)
    else:
        _validate_joint_message(value["latest_message"], physical_source)


def _validate_image_message(value: object, source: str) -> None:
    """Validate one captured sensor_msgs/Image metadata object."""

    if not isinstance(value, dict):
        raise ValueError(f"{source} latest image message must be an object")
    _require_exact_fields(
        value,
        frozenset({"data_length", "encoding", "frame_id", "height", "step", "width"}),
        f"{source} image message",
    )
    for field in ("encoding", "frame_id"):
        if not isinstance(value[field], str) or not value[field]:
            raise ValueError(f"{source} image {field} must be non-empty")
    for field in ("data_length", "height", "step", "width"):
        _integer(value[field], f"{source} image {field}", minimum=1)
    if value["data_length"] != value["height"] * value["step"]:
        raise ValueError(f"{source} image data length is malformed")


def _validate_compressed_image_message(value: object, source: str) -> None:
    """Validate one captured sensor_msgs/CompressedImage metadata object."""

    if not isinstance(value, dict):
        raise ValueError(f"{source} latest compressed image message must be an object")
    _require_exact_fields(
        value,
        frozenset({"data_length", "format", "frame_id"}),
        f"{source} compressed image message",
    )
    if not isinstance(value["format"], str) or not value["format"]:
        raise ValueError(f"{source} compressed image format must be non-empty")
    if not isinstance(value["frame_id"], str):
        raise ValueError(f"{source} compressed image frame_id must be a string")
    _integer(value["data_length"], f"{source} compressed image data_length", minimum=1)


def _validate_joint_message(value: object, source: str) -> None:
    """Validate one captured sensor_msgs/JointState field snapshot."""

    if not isinstance(value, dict):
        raise ValueError(f"{source} latest joint message must be an object")
    _require_exact_fields(
        value,
        frozenset(
            {
                "array_lengths",
                "efforts",
                "frame_id",
                "names",
                "positions",
                "velocities",
            }
        ),
        f"{source} joint message",
    )
    if not isinstance(value["frame_id"], str):
        raise ValueError(f"{source} joint frame_id must be a string")
    names = _string_list(value["names"], f"{source} names", unique=True)
    positions = _number_list(value["positions"], f"{source} positions")
    velocities = _number_list(value["velocities"], f"{source} velocities")
    efforts = _number_list(value["efforts"], f"{source} efforts")
    if len(positions) != len(names):
        raise ValueError(f"{source} name and position array lengths conflict")
    if len(velocities) not in (0, len(names)):
        raise ValueError(f"{source} velocity array length is malformed")
    if len(efforts) not in (0, len(names)):
        raise ValueError(f"{source} effort array length is malformed")
    lengths = value["array_lengths"]
    if not isinstance(lengths, dict):
        raise ValueError(f"{source} array_lengths must be an object")
    _require_exact_fields(
        lengths,
        frozenset({"effort", "name", "position", "velocity"}),
        f"{source} array_lengths",
    )
    expected_lengths = {
        "effort": len(efforts),
        "name": len(names),
        "position": len(positions),
        "velocity": len(velocities),
    }
    if lengths != expected_lengths:
        raise ValueError(f"{source} array lengths do not match captured fields")


def _validate_logical_source(
    source: str,
    value: object,
    physical_topics: dict[str, object],
    duration_s: float,
    freshness_tolerance_s: float,
) -> None:
    if not isinstance(value, dict):
        raise ValueError(f"{source} logical source must be an object")
    _require_exact_fields(
        value,
        frozenset(
            {
                "conversion",
                "first_received_at_offset_s",
                "latest_message",
                "last_received_at_offset_s",
                "measured_frequency_hz",
                "message_type",
                "observed_span_s",
                "physical_source",
                "receive_interval_s",
                "sample_count",
                "source_timestamp",
                "topic",
            }
        ),
        f"{source} logical source",
    )
    count = _integer(value["sample_count"], f"{source} sample_count", minimum=2)
    if count < 2:
        raise ValueError(f"{source} sample_count is insufficient")
    first_offset_s = _finite_number(
        value["first_received_at_offset_s"],
        f"{source} first_received_at_offset_s",
        minimum=0.0,
    )
    last_offset_s = _finite_number(
        value["last_received_at_offset_s"],
        f"{source} last_received_at_offset_s",
        minimum=0.0,
    )
    observed_span_s = _finite_number(
        value["observed_span_s"], f"{source} observed_span_s", minimum=0.0
    )
    if last_offset_s < first_offset_s or last_offset_s > duration_s:
        raise ValueError(f"{source} capture window offsets conflict")
    if not math.isclose(observed_span_s, last_offset_s - first_offset_s, abs_tol=1e-9):
        raise ValueError(f"{source} observed_span_s conflicts with receive offsets")
    if (
        first_offset_s > freshness_tolerance_s
        or duration_s - last_offset_s > freshness_tolerance_s
        or observed_span_s < duration_s - 2 * freshness_tolerance_s
    ):
        raise ValueError(f"{source} capture window coverage is insufficient")
    physical_source = value["physical_source"]
    expected_physical_source = (
        "joint_states" if source.endswith("joint_position") else source
    )
    if physical_source != expected_physical_source:
        raise ValueError(f"{source} physical source mapping conflicts")
    if physical_source not in physical_topics:
        raise ValueError(f"{source} physical source is missing")
    physical = physical_topics[physical_source]
    if value["topic"] != physical["topic"]:
        raise ValueError(f"{source} topic conflicts with its physical source")
    if value["message_type"] != physical["message_type"]:
        raise ValueError(f"{source} message type conflicts with its physical source")
    _validate_stats(value["receive_interval_s"], f"{source} receive_interval_s")
    frequency = _finite_number(
        value["measured_frequency_hz"],
        f"{source} measured_frequency_hz",
        minimum=0.0,
    )
    if frequency <= 0.0:
        raise ValueError(f"{source} measured_frequency_hz must be positive")
    timestamp = value["source_timestamp"]
    if not isinstance(timestamp, dict):
        raise ValueError(f"{source} source timestamp must be an object")
    _require_exact_fields(
        timestamp,
        frozenset({"available", "latest_s", "sample_count"}),
        f"{source} timestamp",
    )
    if timestamp["available"] is not True:
        raise ValueError(f"{source} source timestamp must be available")
    if timestamp["sample_count"] != count:
        raise ValueError(f"{source} source timestamp sample_count conflicts")
    if (
        _finite_number(
            timestamp["latest_s"], f"{source} latest source timestamp", minimum=0.0
        )
        <= 0.0
    ):
        raise ValueError(f"{source} latest source timestamp must be positive")
    physical_message = physical["latest_message"]
    latest_message = value["latest_message"]
    conversion = value["conversion"]
    if source.endswith("joint_position"):
        expected = {
            "canonical_unit": "radian",
            "scale": math.pi / 180.0,
            "source_unit": "degree",
        }
        if conversion != expected:
            raise ValueError(f"{source} joint conversion conflicts")
        if not isinstance(latest_message, dict):
            raise ValueError(f"{source} latest_message must be an object")
        _require_exact_fields(
            latest_message,
            frozenset({"selected_names", "selected_positions"}),
            f"{source} selected joint message",
        )
        selected_names = (
            LEFT_JOINT_NAMES if source.startswith("left_") else RIGHT_JOINT_NAMES
        )
        if latest_message["selected_names"] != list(selected_names):
            raise ValueError(f"{source} selected names conflict")
        selected_positions = _number_list(
            latest_message["selected_positions"], f"{source} selected positions"
        )
        name_to_position = dict(
            zip(
                physical_message["names"],
                physical_message["positions"],
                strict=False,
            )
        )
        if any(name not in name_to_position for name in selected_names):
            raise ValueError(f"{source} required joint name is missing")
        if selected_positions != [name_to_position[name] for name in selected_names]:
            raise ValueError(f"{source} selected positions conflict")
    elif conversion is not None:
        raise ValueError(f"{source} must not invent a conversion")
    elif source in _IMAGE_SOURCES:
        if latest_message != physical_message:
            raise ValueError(f"{source} image message conflicts with physical source")
    else:
        if not isinstance(latest_message, dict):
            raise ValueError(f"{source} latest_message must be an object")
        _require_exact_fields(
            latest_message,
            frozenset({"field_name", "raw_position"}),
            f"{source} gripper message",
        )
        if latest_message["field_name"] != source:
            raise ValueError(f"{source} gripper field name conflicts")
        raw_position = _finite_number(
            latest_message["raw_position"], f"{source} raw position"
        )
        name_to_position = dict(
            zip(
                physical_message["names"],
                physical_message["positions"],
                strict=False,
            )
        )
        if source not in name_to_position or raw_position != name_to_position[source]:
            raise ValueError(f"{source} gripper raw position conflicts")
    if physical["sample_count"] != count:
        raise ValueError(f"{source} sample_count conflicts with physical source")


def _file_identity(file_stat: os.stat_result) -> tuple[int, int, int, int, int]:
    return (
        file_stat.st_dev,
        file_stat.st_ino,
        file_stat.st_size,
        file_stat.st_mtime_ns,
        file_stat.st_ctime_ns,
    )


def _directory_identity(file_stat: os.stat_result) -> tuple[int, int]:
    """Return stable identity fields for an opened directory."""

    return file_stat.st_dev, file_stat.st_ino


def _open_parent_directory(path: Path, label: str) -> tuple[int, Path, str]:
    """Open and pin one non-symlink parent directory for relative operations."""

    absolute = path.absolute()
    parent_path = absolute.parent
    entry_name = absolute.name
    if not entry_name or entry_name in {".", ".."}:
        raise ValueError(f"{label} must name a file within one parent directory")
    try:
        before = os.lstat(parent_path)
    except OSError as error:
        raise ValueError(
            f"{label} parent directory is missing or unreadable"
        ) from error
    if stat.S_ISLNK(before.st_mode) or not stat.S_ISDIR(before.st_mode):
        raise ValueError(f"{label} parent must be an existing non-symlink directory")
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    try:
        directory_fd = os.open(parent_path, flags)
    except OSError as error:
        raise ValueError(f"{label} parent directory could not be pinned") from error
    try:
        opened = os.fstat(directory_fd)
        after = os.lstat(parent_path)
        if (
            not stat.S_ISDIR(opened.st_mode)
            or stat.S_ISLNK(after.st_mode)
            or _directory_identity(opened) != _directory_identity(before)
            or _directory_identity(after) != _directory_identity(before)
        ):
            raise ValueError(f"{label} parent directory changed while being opened")
    except Exception:
        os.close(directory_fd)
        raise
    return directory_fd, parent_path, entry_name


def _verify_parent_directory(directory_fd: int, parent_path: Path, label: str) -> None:
    """Require the pinned directory to remain at the caller-visible path."""

    opened = os.fstat(directory_fd)
    try:
        current = os.lstat(parent_path)
    except OSError as error:
        raise ValueError(
            f"{label} parent directory changed during operation"
        ) from error
    if (
        stat.S_ISLNK(current.st_mode)
        or not stat.S_ISDIR(current.st_mode)
        or _directory_identity(current) != _directory_identity(opened)
    ):
        raise ValueError(f"{label} parent directory changed during operation")


def _entry_stat(directory_fd: int, entry_name: str) -> os.stat_result | None:
    """Return a no-follow entry stat relative to a pinned directory."""

    try:
        return os.stat(entry_name, dir_fd=directory_fd, follow_symlinks=False)
    except FileNotFoundError:
        return None


def _read_regular_snapshot(path: Path, label: str) -> bytes:
    directory_fd, parent_path, entry_name = _open_parent_directory(path, label)
    try:
        before = _entry_stat(directory_fd, entry_name)
        if before is None:
            raise ValueError(f"{label} is missing or unreadable")
        if stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode):
            raise ValueError(f"{label} must be a regular non-symlink file")
        try:
            descriptor = os.open(
                entry_name,
                os.O_RDONLY | os.O_NOFOLLOW,
                dir_fd=directory_fd,
            )
        except OSError as error:
            raise ValueError(f"{label} is unreadable") from error
        try:
            opened = os.fstat(descriptor)
            if _file_identity(opened) != _file_identity(before):
                raise ValueError(f"{label} was replaced while being read")
            chunks: list[bytes] = []
            while chunk := os.read(descriptor, 1024 * 1024):
                chunks.append(chunk)
            after_open = os.fstat(descriptor)
            after_entry = _entry_stat(directory_fd, entry_name)
        finally:
            os.close(descriptor)
        _verify_parent_directory(directory_fd, parent_path, label)
        if (
            after_entry is None
            or _file_identity(after_open) != _file_identity(before)
            or _file_identity(after_entry) != _file_identity(before)
        ):
            raise ValueError(f"{label} changed while being read")
    finally:
        os.close(directory_fd)
    snapshot = b"".join(chunks)
    if not snapshot:
        raise ValueError(f"{label} must not be empty")
    return snapshot


def load_and_validate_manifest(path: Path) -> dict[str, object]:
    """Load a stable regular JSON file and validate the complete manifest."""

    snapshot = _read_regular_snapshot(path, "manifest")
    try:
        payload = json.loads(snapshot.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("manifest must be valid UTF-8 JSON") from error
    validate_manifest(payload)
    return payload


def validate_ros2_readonly_manifest(payload: object) -> None:
    """Validate one closed F1 ROS 2 read-only manifest payload."""

    validate_manifest(payload)


def load_and_validate_ros2_readonly_manifest(path: str | Path) -> dict[str, object]:
    """Load and validate one F1 ROS 2 read-only manifest payload."""

    return load_and_validate_manifest(Path(path))


def controller_config_kwargs_from_manifest(
    payload: dict[str, object],
) -> dict[str, object]:
    """Return a detached ControllerConfig JSON projection from a valid manifest."""

    validate_ros2_readonly_manifest(payload)
    controller_config = payload["controller_config"]
    if not isinstance(controller_config, dict):
        raise ValueError("controller_config must be an object")
    return copy_json_object(controller_config)


def write_manifest_atomic(path: Path, payload: dict[str, object]) -> None:
    """Validate and atomically write a manifest to a safe regular-file path."""

    validate_manifest(payload)
    snapshot = (
        json.dumps(payload, allow_nan=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    directory_fd, parent_path, entry_name = _open_parent_directory(path, "manifest")
    temporary_name: str | None = None
    try:
        before = _entry_stat(directory_fd, entry_name)
        if before is not None and (
            stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode)
        ):
            raise ValueError("manifest output must be a regular non-symlink file")
        descriptor: int | None = None
        for _ in range(128):
            candidate = f".{entry_name}.{uuid.uuid4().hex}.tmp"
            try:
                descriptor = os.open(
                    candidate,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                    0o600,
                    dir_fd=directory_fd,
                )
            except FileExistsError:
                continue
            temporary_name = candidate
            break
        if descriptor is None or temporary_name is None:
            raise ValueError("could not create a unique manifest temporary file")
        try:
            written = 0
            while written < len(snapshot):
                count = os.write(descriptor, snapshot[written:])
                if count <= 0:
                    raise OSError("manifest temporary write made no progress")
                written += count
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

        _verify_parent_directory(directory_fd, parent_path, "manifest")
        current = _entry_stat(directory_fd, entry_name)
        if before is not None:
            if current is None or _file_identity(current) != _file_identity(before):
                raise ValueError("manifest output changed before atomic replacement")
        elif current is not None:
            raise ValueError("manifest output appeared before atomic replacement")
        os.replace(
            temporary_name,
            entry_name,
            src_dir_fd=directory_fd,
            dst_dir_fd=directory_fd,
        )
        temporary_name = None
        os.fsync(directory_fd)
    finally:
        try:
            if temporary_name is not None:
                with suppress(FileNotFoundError):
                    os.unlink(temporary_name, dir_fd=directory_fd)
        finally:
            os.close(directory_fd)


def load_topic_overrides(path: Path) -> dict[str, TargetSpec]:
    """Load a closed six-topic override with explicit image transports."""

    snapshot = _read_regular_snapshot(path, "topic override")
    try:
        payload = json.loads(snapshot.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ValueError("topic override must be valid UTF-8 JSON") from error
    if not isinstance(payload, dict) or frozenset(payload) != _PHYSICAL_SOURCES:
        raise ValueError("topic override must define exactly the six physical sources")
    targets: dict[str, TargetSpec] = {}
    topics: list[str] = []
    for source, target in DEFAULT_TARGETS.items():
        value = payload[source]
        if isinstance(value, str):
            topic = value
            image_transport = target.image_transport
        elif isinstance(value, dict):
            _require_exact_fields(
                value,
                frozenset({"image_transport", "topic"})
                if source in _IMAGE_SOURCES
                else frozenset({"topic"}),
                f"topic override {source}",
            )
            topic = value["topic"]
            if source not in _IMAGE_SOURCES:
                image_transport = target.image_transport
            else:
                image_transport = value["image_transport"]
                if image_transport not in {"raw", "compressed"}:
                    raise ValueError(f"topic override {source} image_transport")
        else:
            raise ValueError("topic override values must be strings or objects")
        if not isinstance(topic, str) or not topic.startswith("/"):
            raise ValueError("topic override values must be absolute ROS names")
        message_type = (
            COMPRESSED_IMAGE_MESSAGE_TYPE
            if image_transport == "compressed"
            else RAW_IMAGE_MESSAGE_TYPE
            if source in _IMAGE_SOURCES
            else target.message_type
        )
        targets[source] = target._replace(
            image_transport=image_transport,
            message_type=message_type,
            topic=topic,
        )
        topics.append(topic)
    if len(set(topics)) != len(topics):
        raise ValueError("topic override values must be unique")
    return targets


def capture_manifest(
    *,
    duration_s: float,
    targets: dict[str, TargetSpec],
    discovery_timeout_s: float,
    discovery_stability_interval_s: float,
    freshness_tolerance_s: float,
) -> dict[str, object]:
    """Capture a live ROS manifest with all ROS dependencies imported lazily."""

    try:
        import rclpy
        from rclpy.context import Context
        from rclpy.executors import SingleThreadedExecutor
        from sensor_msgs.msg import CompressedImage, Image, JointState
    except ImportError as error:
        raise RuntimeError(
            "live capture requires rclpy and sensor_msgs from ROS 2 Jazzy"
        ) from error
    return _capture_with_ros(
        duration_s=duration_s,
        targets=targets,
        discovery_timeout_s=discovery_timeout_s,
        discovery_stability_interval_s=discovery_stability_interval_s,
        freshness_tolerance_s=freshness_tolerance_s,
        rclpy_module=rclpy,
        context_type=Context,
        executor_factory=SingleThreadedExecutor,
        compressed_image_type=CompressedImage,
        image_type=Image,
        joint_state_type=JointState,
        monotonic=time.monotonic,
        captured_at=lambda: (
            datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        ),
    )


def capture_ros2_readonly_manifest(
    *,
    duration_s: float,
    discovery_timeout_s: float = 10.0,
    discovery_stability_interval_s: float = DEFAULT_DISCOVERY_STABILITY_INTERVAL_S,
    freshness_tolerance_s: float = DEFAULT_FRESHNESS_TOLERANCE_S,
    targets: dict[str, TargetSpec] | None = None,
) -> dict[str, object]:
    """Capture a live F1 ROS 2 read-only manifest."""

    return capture_manifest(
        duration_s=duration_s,
        targets=DEFAULT_TARGETS if targets is None else targets,
        discovery_timeout_s=discovery_timeout_s,
        discovery_stability_interval_s=discovery_stability_interval_s,
        freshness_tolerance_s=freshness_tolerance_s,
    )


def _policy_name(value: object, label: str) -> str:
    """Normalize one rclpy QoS policy enum to its manifest spelling."""

    name = getattr(value, "name", None)
    if not isinstance(name, str) or not name:
        raise ValueError(f"publisher QoS {label} policy has no stable name")
    return name.lower()


def _is_unknown_node_identity(value: str) -> bool:
    """Return whether an RMW graph identity is an unresolved sentinel."""

    return value.startswith("_NODE_") and value.endswith("_UNKNOWN_")


def _endpoint_snapshot(endpoint: object) -> dict[str, object]:
    """Convert one rclpy TopicEndpointInfo to stable JSON evidence."""

    qos = getattr(endpoint, "qos_profile", None)
    if qos is None:
        raise ValueError("publisher endpoint has no QoS profile")
    try:
        endpoint_gid = bytes(endpoint.endpoint_gid).hex()
    except (TypeError, ValueError) as error:
        raise ValueError("publisher endpoint GID is malformed") from error
    if not endpoint_gid:
        raise ValueError("publisher endpoint GID must not be empty")
    node_name = getattr(endpoint, "node_name", None)
    node_namespace = getattr(endpoint, "node_namespace", None)
    topic_type = getattr(endpoint, "topic_type", None)
    for label, value in (
        ("node_name", node_name),
        ("node_namespace", node_namespace),
        ("topic_type", topic_type),
    ):
        if not isinstance(value, str) or not value:
            raise ValueError(f"publisher endpoint {label} must be non-empty")
        if label in {"node_name", "node_namespace"} and _is_unknown_node_identity(
            value
        ):
            raise ValueError(f"publisher endpoint {label} uses an RMW unknown sentinel")
    depth = getattr(qos, "depth", None)
    _integer(depth, "publisher QoS depth", minimum=1)
    return {
        "endpoint_gid": endpoint_gid,
        "node_name": node_name,
        "node_namespace": node_namespace,
        "qos": {
            "depth": depth,
            "durability": _policy_name(getattr(qos, "durability", None), "durability"),
            "history": _policy_name(getattr(qos, "history", None), "history"),
            "reliability": _policy_name(
                getattr(qos, "reliability", None), "reliability"
            ),
        },
        "topic_type": topic_type,
    }


def _discover_snapshot(
    node: object, targets: dict[str, TargetSpec]
) -> tuple[dict[str, dict[str, object]], dict[str, object]]:
    """Discover all publisher endpoints and validate graph type/QoS claims."""

    graph_entries = node.get_topic_names_and_types()
    graph_types: dict[str, list[str]] = {}
    for topic, types in graph_entries:
        if topic in graph_types:
            raise ValueError(f"ROS graph reports duplicate topic entry {topic}")
        graph_types[topic] = sorted(types)
    snapshot: dict[str, dict[str, object]] = {}
    subscription_qos: dict[str, object] = {}
    verifier = ManifestAccumulator(targets)
    for physical_source, target in targets.items():
        endpoints = list(node.get_publishers_info_by_topic(target.topic))
        publishers = sorted(
            (_endpoint_snapshot(endpoint) for endpoint in endpoints),
            key=lambda item: (
                item["node_namespace"],
                item["node_name"],
                item["endpoint_gid"],
            ),
        )
        types = graph_types.get(target.topic, [])
        verifier.record_discovery(
            physical_source=physical_source,
            graph_types=types,
            publishers=publishers,
        )
        snapshot[physical_source] = {
            "graph_types": types,
            "publishers": publishers,
        }
        subscription_qos[physical_source] = endpoints[0].qos_profile
    return snapshot, subscription_qos


def _canonical_json(value: object) -> str:
    """Return deterministic compact JSON for diagnostics and hashing."""

    return json.dumps(value, allow_nan=False, sort_keys=True, separators=(",", ":"))


def _diagnostic_values(values: list[object]) -> dict[str, object]:
    """Return a deterministically ordered collection for one changed field."""

    ordered = sorted(values, key=_canonical_json)
    return {"count": len(ordered), "values": ordered}


def _publisher_diagnostic_fields(evidence: dict[str, object]) -> dict[str, object]:
    """Project a target snapshot into bounded-diagnostic comparison fields."""

    publishers = evidence["publishers"]
    return {
        "graph_types": _diagnostic_values(list(evidence["graph_types"])),
        "publisher_count": len(publishers),
        "publisher_endpoint_gids": _diagnostic_values(
            [publisher["endpoint_gid"] for publisher in publishers]
        ),
        "publisher_node_identities": _diagnostic_values(
            [
                {
                    "node_name": publisher["node_name"],
                    "node_namespace": publisher["node_namespace"],
                }
                for publisher in publishers
            ]
        ),
        "publisher_qos_profiles": _diagnostic_values(
            [publisher["qos"] for publisher in publishers]
        ),
        "publisher_topic_types": _diagnostic_values(
            [publisher["topic_type"] for publisher in publishers]
        ),
    }


def _bounded_diagnostic_topic(topic: str) -> str:
    """Keep fallback diagnostics bounded even for a very long topic override."""

    if len(topic.encode("utf-8")) <= 256:
        return topic
    digest = hashlib.sha256(topic.encode("utf-8")).hexdigest()
    return f"{topic[:128]}...sha256:{digest}"


def _graph_change_diagnostic(
    initial_graph: dict[str, dict[str, object]],
    final_graph: dict[str, dict[str, object]],
    targets: dict[str, TargetSpec],
) -> str:
    """Return a deterministic target-only graph diff capped below 4 KiB."""

    changes: list[dict[str, object]] = []
    for physical_source in sorted(targets):
        initial_fields = _publisher_diagnostic_fields(initial_graph[physical_source])
        final_fields = _publisher_diagnostic_fields(final_graph[physical_source])
        changed_fields = {
            field: {
                "final": final_fields[field],
                "initial": initial_fields[field],
            }
            for field in sorted(initial_fields)
            if initial_fields[field] != final_fields[field]
        }
        if (
            not changed_fields
            and initial_graph[physical_source] != final_graph[physical_source]
        ):
            changed_fields["publisher_endpoint_records"] = {
                "final": _diagnostic_values(
                    list(final_graph[physical_source]["publishers"])
                ),
                "initial": _diagnostic_values(
                    list(initial_graph[physical_source]["publishers"])
                ),
            }
        if changed_fields:
            changes.append(
                {
                    "fields": changed_fields,
                    "physical_source": physical_source,
                    "topic": targets[physical_source].topic,
                }
            )
    rich = _canonical_json({"changes": changes})
    if len(rich.encode("utf-8")) <= MAX_GRAPH_CHANGE_DIAGNOSTIC_BYTES:
        return rich
    compact_changes = [
        {
            "changed_fields": sorted(change["fields"]),
            "physical_source": change["physical_source"],
            "topic": _bounded_diagnostic_topic(change["topic"]),
        }
        for change in changes
    ]
    fallback = _canonical_json(
        {
            "changes": compact_changes,
            "detail_sha256": hashlib.sha256(rich.encode("utf-8")).hexdigest(),
            "truncated": True,
        }
    )
    if len(fallback.encode("utf-8")) > MAX_GRAPH_CHANGE_DIAGNOSTIC_BYTES:
        raise ValueError("graph change diagnostic exceeded its fixed safety bound")
    return fallback


def _wait_for_stable_discovery(
    *,
    node: object,
    targets: dict[str, TargetSpec],
    executor: object,
    monotonic: Callable[[], float],
    timeout_s: float,
    stability_interval_s: float,
) -> tuple[
    dict[str, dict[str, object]],
    dict[str, object],
    dict[str, object],
]:
    """Wait for repeated, complete, identical ROS graph snapshots."""

    timeout_s, stability_interval_s = _validated_discovery_settings(
        timeout_s, stability_interval_s
    )
    started_s = monotonic()
    deadline_s = started_s + timeout_s
    candidate_graph: dict[str, dict[str, object]] | None = None
    candidate_started_s = 0.0
    consecutive_count = 0
    discovery_error: ValueError | None = None
    while monotonic() < deadline_s:
        try:
            graph, subscription_qos = _discover_snapshot(node, targets)
        except ValueError as error:
            candidate_graph = None
            consecutive_count = 0
            discovery_error = error
        else:
            observed_s = monotonic()
            if graph == candidate_graph:
                consecutive_count += 1
                if (
                    consecutive_count >= 2
                    and observed_s - candidate_started_s >= stability_interval_s
                ):
                    return (
                        graph,
                        subscription_qos,
                        {
                            "consecutive_identical_snapshots": consecutive_count,
                            "stability_interval_s": stability_interval_s,
                            "stabilized_after_s": observed_s - started_s,
                            "timeout_s": timeout_s,
                        },
                    )
            else:
                candidate_graph = graph
                candidate_started_s = observed_s
                consecutive_count = 1
            discovery_error = ValueError(
                "complete graph did not remain unchanged for the stability interval"
            )
        remaining_s = deadline_s - monotonic()
        if remaining_s > 0.0:
            executor.spin_once(timeout_sec=min(0.1, remaining_s))
    detail = str(discovery_error) if discovery_error else "no graph data"
    raise ValueError(f"ROS sensor discovery timed out: {detail}")


def _source_timestamp(message: object, source: str) -> float:
    """Return one valid nonzero ROS header timestamp in seconds."""

    header = getattr(message, "header", None)
    stamp = getattr(header, "stamp", None)
    sec = getattr(stamp, "sec", None)
    nanosec = getattr(stamp, "nanosec", None)
    if (
        isinstance(sec, bool)
        or not isinstance(sec, int)
        or isinstance(nanosec, bool)
        or not isinstance(nanosec, int)
        or sec < 0
        or nanosec < 0
        or nanosec >= 1_000_000_000
    ):
        raise ValueError(f"{source} source timestamp is malformed")
    timestamp = sec + nanosec / 1_000_000_000
    if timestamp <= 0.0:
        raise ValueError(f"{source} source timestamp must be available")
    return timestamp


def _message_callback(
    accumulator: ManifestAccumulator,
    physical_source: str,
    monotonic: Callable[[], float],
) -> Callable[[object], None]:
    """Build one sensor-only callback that records the live message fields."""

    def callback(message: object) -> None:
        received_at_s = monotonic()
        source_timestamp_s = _source_timestamp(message, physical_source)
        header = message.header
        if physical_source in _IMAGE_SOURCES:
            target = accumulator._target(physical_source)
            if target.image_transport == "compressed":
                accumulator.record_compressed_image(
                    physical_source,
                    received_at_s=received_at_s,
                    source_timestamp_s=source_timestamp_s,
                    frame_id=header.frame_id,
                    format=message.format,
                    data_length=len(message.data),
                )
            else:
                accumulator.record_image(
                    physical_source,
                    received_at_s=received_at_s,
                    source_timestamp_s=source_timestamp_s,
                    frame_id=header.frame_id,
                    encoding=message.encoding,
                    height=message.height,
                    width=message.width,
                    step=message.step,
                    data_length=len(message.data),
                )
        elif physical_source == "joint_states":
            accumulator.record_joint_state(
                received_at_s=received_at_s,
                source_timestamp_s=source_timestamp_s,
                frame_id=header.frame_id,
                names=message.name,
                positions=message.position,
                velocities=message.velocity,
                efforts=message.effort,
            )
        else:
            accumulator.record_gripper_state(
                physical_source,
                received_at_s=received_at_s,
                source_timestamp_s=source_timestamp_s,
                frame_id=header.frame_id,
                names=message.name,
                positions=message.position,
                velocities=message.velocity,
                efforts=message.effort,
            )

    return callback


def _strip_implicit_publishers(node: object) -> None:
    """Remove rclpy's implicit publishers before any capture subscription exists."""

    for publisher in list(node.publishers):
        if node.destroy_publisher(publisher) is not True:
            raise ValueError("could not remove an implicit capture-node publisher")
    if list(node.publishers):
        raise ValueError("capture node retains a publisher")


def _capture_node_evidence(node: object) -> dict[str, object]:
    """Materialize generator properties and require a subscription-only node."""

    publishers = list(node.publishers)
    clients = list(node.clients)
    subscriptions = list(node.subscriptions)
    if publishers:
        raise ValueError("capture node publisher_count must be zero")
    if clients:
        raise ValueError("capture node service_client_count must be zero")
    if len(subscriptions) != 6:
        raise ValueError("capture node subscription_count must be six")
    return {
        "name": node.get_name(),
        "namespace": node.get_namespace(),
        "publisher_count": len(publishers),
        "service_client_count": len(clients),
        "subscription_count": len(subscriptions),
    }


def _observed_nodes(node: object) -> list[dict[str, str]]:
    """Return a stable list of graph node names and namespaces."""

    return [
        {"name": name, "namespace": namespace}
        for name, namespace in sorted(set(node.get_node_names_and_namespaces()))
    ]


def _capture_with_ros(
    *,
    duration_s: float,
    targets: dict[str, TargetSpec],
    discovery_timeout_s: float,
    discovery_stability_interval_s: float = DEFAULT_DISCOVERY_STABILITY_INTERVAL_S,
    rclpy_module: object,
    context_type: Callable[[], object],
    executor_factory: Callable[..., object],
    image_type: object,
    joint_state_type: object,
    compressed_image_type: object | None = None,
    monotonic: Callable[[], float],
    captured_at: Callable[[], str],
    freshness_tolerance_s: float = DEFAULT_FRESHNESS_TOLERANCE_S,
) -> dict[str, object]:
    """Run a bounded subscription-only capture against an injected ROS runtime."""

    if duration_s < MINIMUM_CAPTURE_DURATION_S or not math.isfinite(duration_s):
        raise ValueError("duration_s must be finite and at least 60 seconds")
    _validated_discovery_settings(discovery_timeout_s, discovery_stability_interval_s)
    context = context_type()
    node = None
    executor = None
    added_to_executor = False
    initialized = False
    try:
        rclpy_module.init(args=None, context=context)
        initialized = True
        node = rclpy_module.create_node(
            "f1_ros2_manifest_capture",
            context=context,
            enable_rosout=False,
            start_parameter_services=False,
            use_global_arguments=False,
        )
        _strip_implicit_publishers(node)
        if list(node.clients):
            raise ValueError("capture node has an unexpected service client")
        executor = executor_factory(context=context)
        executor.add_node(node)
        added_to_executor = True

        initial_graph, subscription_qos, discovery = _wait_for_stable_discovery(
            node=node,
            targets=targets,
            executor=executor,
            monotonic=monotonic,
            timeout_s=discovery_timeout_s,
            stability_interval_s=discovery_stability_interval_s,
        )

        accumulator = ManifestAccumulator(targets)
        for physical_source, evidence in initial_graph.items():
            accumulator.record_discovery(
                physical_source=physical_source,
                graph_types=evidence["graph_types"],
                publishers=evidence["publishers"],
            )

        callback_errors: list[Exception] = []

        def safe_callback(
            callback: Callable[[object], None],
        ) -> Callable[[object], None]:
            def invoke(message: object) -> None:
                try:
                    callback(message)
                except (
                    Exception
                ) as error:  # ROS callbacks must fail the capture closed.
                    callback_errors.append(error)

            return invoke

        for physical_source, target in targets.items():
            message_type = (
                (
                    compressed_image_type
                    if target.message_type == COMPRESSED_IMAGE_MESSAGE_TYPE
                    else image_type
                )
                if physical_source in _IMAGE_SOURCES
                else joint_state_type
            )
            node.create_subscription(
                message_type,
                target.topic,
                safe_callback(
                    _message_callback(accumulator, physical_source, monotonic)
                ),
                subscription_qos[physical_source],
            )
        capture_node = _capture_node_evidence(node)
        started_monotonic_s = monotonic()
        deadline = started_monotonic_s + duration_s
        while monotonic() < deadline:
            remaining = deadline - monotonic()
            executor.spin_once(timeout_sec=min(0.1, remaining))
            if callback_errors:
                raise ValueError(f"sensor callback failed: {callback_errors[0]}")
        ended_monotonic_s = monotonic()
        try:
            final_graph, _ = _discover_snapshot(node, targets)
        except ValueError as error:
            raise ValueError(f"ROS graph changed during capture: {error}") from error
        if final_graph != initial_graph:
            diagnostic = _graph_change_diagnostic(initial_graph, final_graph, targets)
            raise ValueError(f"ROS graph changed during capture: {diagnostic}")
        final_capture_node = _capture_node_evidence(node)
        if final_capture_node != capture_node:
            raise ValueError("capture node endpoint counts changed during capture")
        return accumulator.build_manifest(
            started_monotonic_s=started_monotonic_s,
            ended_monotonic_s=ended_monotonic_s,
            captured_at=captured_at(),
            capture_node=final_capture_node,
            discovery=discovery,
            observed_nodes=_observed_nodes(node),
            freshness_tolerance_s=freshness_tolerance_s,
        )
    finally:
        try:
            if executor is not None and node is not None and added_to_executor:
                executor.remove_node(node)
            if node is not None:
                node.destroy_node()
        finally:
            try:
                if executor is not None:
                    shutdown_complete = executor.shutdown(timeout_sec=1.0)
                    if shutdown_complete is False:
                        raise RuntimeError("capture executor did not shut down")
            finally:
                if initialized:
                    context.shutdown()


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--output", type=Path)
    mode.add_argument("--validate-only", type=Path)
    parser.add_argument("--duration-s", type=float, default=MINIMUM_CAPTURE_DURATION_S)
    parser.add_argument("--discovery-timeout-s", type=float, default=10.0)
    parser.add_argument(
        "--discovery-stability-interval-s",
        type=float,
        default=DEFAULT_DISCOVERY_STABILITY_INTERVAL_S,
    )
    parser.add_argument(
        "--freshness-tolerance-s",
        type=float,
        default=DEFAULT_FRESHNESS_TOLERANCE_S,
    )
    parser.add_argument("--topic-map", type=Path)
    parser.add_argument("--validate", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Capture a live manifest or validate an existing manifest offline."""

    parser = _parser()
    args = parser.parse_args(argv)
    if args.validate_only is not None:
        if args.validate or args.topic_map is not None:
            parser.error("--validate-only cannot be combined with capture options")
        try:
            load_and_validate_manifest(args.validate_only)
        except (OSError, ValueError) as error:
            parser.error(str(error))
        return 0
    if (
        not math.isfinite(args.duration_s)
        or args.duration_s < MINIMUM_CAPTURE_DURATION_S
    ):
        parser.error("--duration-s must be finite and at least 60 seconds")
    try:
        _validated_discovery_settings(
            args.discovery_timeout_s, args.discovery_stability_interval_s
        )
    except ValueError as error:
        parser.error(str(error))
    try:
        _validated_freshness_tolerance(args.freshness_tolerance_s, args.duration_s)
    except ValueError as error:
        parser.error(str(error))
    try:
        targets = (
            load_topic_overrides(args.topic_map)
            if args.topic_map is not None
            else DEFAULT_TARGETS
        )
        payload = capture_manifest(
            duration_s=args.duration_s,
            targets=targets,
            discovery_timeout_s=args.discovery_timeout_s,
            discovery_stability_interval_s=args.discovery_stability_interval_s,
            freshness_tolerance_s=args.freshness_tolerance_s,
        )
        write_manifest_atomic(args.output, payload)
        if args.validate:
            load_and_validate_manifest(args.output)
    except (OSError, RuntimeError, ValueError) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
