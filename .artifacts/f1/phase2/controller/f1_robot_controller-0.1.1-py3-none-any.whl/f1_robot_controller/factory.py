"""Lazy public controller backend selection."""

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.controller import F1RobotController


def create_controller(*, is_dummy: bool, config: ControllerConfig) -> F1RobotController:
    """Create the requested controller without eagerly importing backends."""

    if is_dummy:
        from f1_robot_controller.backends.fake.controller import FakeRobotController

        return FakeRobotController(config)
    from f1_robot_controller.backends.ros2.controller import Ros2RobotController

    return Ros2RobotController(config)
