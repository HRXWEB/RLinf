"""Read-only ROS graph identity capture using rclpy graph APIs."""

import hashlib
import json
import math
import os
import stat
import time
import uuid
from collections.abc import Callable, Mapping
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

from f1_robot_controller.ros2_manifest import (
    _entry_stat,
    _open_parent_directory,
    _verify_parent_directory,
)


@dataclass(frozen=True)
class Ros2ReadonlyGraphIdentity:
    """Deterministic identity for the external/vendor ROS graph."""

    graph: Mapping[str, object]
    graph_sha256: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "graph", MappingProxyType(dict(self.graph)))


def _canonical_json(value: object) -> str:
    return json.dumps(value, allow_nan=False, separators=(",", ":"), sort_keys=True)


def _unknown_identity(name: str, namespace: str) -> bool:
    return any(
        value.startswith("_NODE_") and value.endswith("_UNKNOWN_")
        for value in (name, namespace)
    )


def _filtered_snapshot(
    node: object,
    *,
    excluded: tuple[tuple[str, str], ...],
) -> dict[str, object]:
    excluded_set = set(excluded)
    nodes = []
    for name, namespace in node.get_node_names_and_namespaces():
        if _unknown_identity(name, namespace):
            raise ValueError("ROS graph contains unresolved node identity")
        if (namespace, name) not in excluded_set:
            nodes.append({"name": name, "namespace": namespace})
    topics = [
        {"name": name, "types": sorted(types)}
        for name, types in node.get_topic_names_and_types()
    ]
    return {
        "nodes": sorted(nodes, key=lambda item: (item["namespace"], item["name"])),
        "topics": sorted(topics, key=lambda item: item["name"]),
    }


def _stable_vendor_graph(
    node: object,
    *,
    excluded: tuple[tuple[str, str], ...],
    timeout_s: float,
    stability_interval_s: float,
    monotonic: Callable[[], float] = time.monotonic,
) -> dict[str, object]:
    if (
        not math.isfinite(timeout_s)
        or timeout_s < 0.0
        or not math.isfinite(stability_interval_s)
        or stability_interval_s < 0.0
        or timeout_s < stability_interval_s
    ):
        raise ValueError("graph identity timeout settings are invalid")
    deadline = monotonic() + timeout_s
    previous: dict[str, object] | None = None
    while monotonic() <= deadline:
        current = _filtered_snapshot(node, excluded=excluded)
        if current == previous:
            return current
        previous = current
        if stability_interval_s > 0.0:
            time.sleep(min(stability_interval_s, max(0.0, deadline - monotonic())))
    raise ValueError("ROS graph identity did not stabilize")


def _write_identity_atomic(path: Path, payload: dict[str, object]) -> None:
    snapshot = (
        json.dumps(payload, allow_nan=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    directory_fd, parent_path, entry_name = _open_parent_directory(
        path,
        "graph identity",
    )
    temporary_name: str | None = None
    try:
        before = _entry_stat(directory_fd, entry_name)
        if before is not None and (
            stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode)
        ):
            raise ValueError("graph identity output must be a regular non-symlink file")
        for _ in range(128):
            candidate = f".{entry_name}.{uuid.uuid4().hex}.tmp"
            try:
                descriptor = os.open(
                    candidate,
                    os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                    0o600,
                    dir_fd=directory_fd,
                )
            except FileExistsError:
                continue
            temporary_name = candidate
            break
        else:
            raise ValueError("could not create graph identity temporary file")
        try:
            os.write(descriptor, snapshot)
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        _verify_parent_directory(directory_fd, parent_path, "graph identity")
        os.replace(
            temporary_name,
            entry_name,
            src_dir_fd=directory_fd,
            dst_dir_fd=directory_fd,
        )
        temporary_name = None
        os.fsync(directory_fd)
    finally:
        if temporary_name is not None:
            with suppress(FileNotFoundError):
                os.unlink(temporary_name, dir_fd=directory_fd)
        os.close(directory_fd)


def capture_ros2_readonly_graph_identity(
    *,
    output: str | Path | None = None,
    node_name: str = "f1_ros2_readonly_graph_identity",
    timeout_s: float = 5.0,
    stability_interval_s: float = 1.0,
    excluded_nodes: tuple[tuple[str, str], ...] = (),
    rclpy_module: object | None = None,
    context_type: Callable[[], object] | None = None,
) -> Ros2ReadonlyGraphIdentity:
    """Capture a deterministic identity for the external/vendor ROS graph."""

    if rclpy_module is None or context_type is None:
        try:
            import rclpy
            from rclpy.context import Context
        except ImportError as error:
            raise RuntimeError("graph identity capture requires ROS 2 rclpy") from error
        rclpy_module = rclpy
        context_type = Context
    context = context_type()
    node = None
    try:
        rclpy_module.init(args=None, context=context)
        node = rclpy_module.create_node(
            node_name,
            context=context,
            enable_rosout=False,
            start_parameter_services=False,
            use_global_arguments=False,
        )
        namespace = getattr(node, "get_namespace", lambda: "/")()
        exclusions = ((namespace, node_name), *excluded_nodes)
        vendor_graph = _stable_vendor_graph(
            node,
            excluded=exclusions,
            timeout_s=timeout_s,
            stability_interval_s=stability_interval_s,
        )
        graph = {
            **vendor_graph,
            "excluded_nodes": [
                {"name": name, "namespace": namespace} for namespace, name in exclusions
            ],
        }
        graph_sha256 = hashlib.sha256(
            _canonical_json(vendor_graph).encode("utf-8")
        ).hexdigest()
        identity = Ros2ReadonlyGraphIdentity(graph=graph, graph_sha256=graph_sha256)
        payload = {"graph": graph, "graph_sha256": graph_sha256}
        if output is not None:
            _write_identity_atomic(Path(output), payload)
        return identity
    finally:
        if node is not None:
            node.destroy_node()
        if context.ok():
            context.shutdown()
