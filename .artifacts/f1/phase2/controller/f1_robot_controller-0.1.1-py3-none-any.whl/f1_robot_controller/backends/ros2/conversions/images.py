"""Image conversion without importing ROS or cv_bridge modules."""

import numpy as np

from f1_robot_controller.config import Ros2ImageTransport
from f1_robot_controller.errors import ObservationUnavailableError

from .joints import source_timestamp_seconds


def image_message_to_rgb(
    message: object, *, bridge: object, transport: Ros2ImageTransport
) -> tuple[np.ndarray, float]:
    """Convert raw/compressed image data to copied uint8 RGB without resizing."""

    try:
        if transport is Ros2ImageTransport.RAW:
            encoding = str(message.encoding).lower()
            image = bridge.imgmsg_to_cv2(message, desired_encoding="passthrough")
            array = np.asarray(image)
            if encoding == "bgr8":
                array = array[..., ::-1]
            elif encoding != "rgb8":
                raise ObservationUnavailableError(
                    f"unsupported color image encoding: {encoding}"
                )
        elif transport is Ros2ImageTransport.COMPRESSED:
            image = bridge.compressed_imgmsg_to_cv2(
                message,
                desired_encoding="rgb8",
            )
            array = np.asarray(image)
        else:
            raise ObservationUnavailableError("unsupported image transport")
    except (AttributeError, TypeError, ValueError) as error:
        raise ObservationUnavailableError("image conversion failed") from error
    if array.ndim != 3 or array.shape[2] != 3 or array.dtype != np.uint8:
        raise ObservationUnavailableError("color image must be uint8 HxWx3")
    return np.array(array, dtype=np.uint8, copy=True), source_timestamp_seconds(message)
