"""Pure ROS message-to-controller value conversions."""
