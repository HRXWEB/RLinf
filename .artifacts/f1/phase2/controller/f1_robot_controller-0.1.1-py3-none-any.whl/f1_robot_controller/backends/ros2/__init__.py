"""Lazy ROS 2 read-only backend package."""
