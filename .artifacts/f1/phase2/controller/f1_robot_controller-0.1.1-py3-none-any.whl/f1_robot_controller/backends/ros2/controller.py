"""Strictly read-only ROS 2 implementation of the controller contract."""

from math import isfinite
from threading import Event, RLock, Thread

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.controller import F1RobotController
from f1_robot_controller.errors import (
    CommandRejectedError,
    ControllerLifecycleError,
    ControllerNotReadyError,
)
from f1_robot_controller.executors.direct import DirectActionExecutor
from f1_robot_controller.runtime.health_monitor import HealthMonitor
from f1_robot_controller.runtime.observation_cache import ObservationCache
from f1_robot_controller.runtime.timestamps import MonotonicStampAllocator
from f1_robot_controller.types import (
    CommandReceipt,
    CommandStatus,
    ControllerHealth,
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
    RobotObservation,
)
from f1_robot_controller.validation import REQUIRED_SENSOR_KEYS

from .node import (
    ReadOnlyRos2Runtime,
    create_read_only_runtime,
    create_read_write_runtime,
)

_CLOSE_TIMEOUT_S = 1.0


class Ros2RobotController(F1RobotController):
    """Own a six-subscription ROS 2 graph with no motion endpoint."""

    def __init__(self, config: ControllerConfig) -> None:
        self._config = config
        self._clock = MonotonicStampAllocator().next
        self._cache = ObservationCache(config, image_shapes=config.ros2.image_shapes)
        self._health = HealthMonitor(clock=self._clock)
        self._lock = RLock()
        self._ready = Event()
        self._stop = Event()
        self._seen_sources: set[str] = set()
        self._required_sources = set(REQUIRED_SENSOR_KEYS)
        if config.ros2.motion_enabled:
            self._required_sources.update(
                {"left_tcp", "right_tcp", "left_gripper", "right_gripper"}
            )
        self._runtime: ReadOnlyRos2Runtime | None = None
        self._executor: DirectActionExecutor | None = None
        self._thread: Thread | None = None
        self._opened = False
        self._closed = False

    def open(self) -> None:
        """Create only controller-owned subscriptions and start bounded spinning."""

        missing_fields = self._config.ros2.missing_manifest_fields()
        if missing_fields:
            raise ControllerNotReadyError(
                "ROS 2 manifest configuration is incomplete; missing: "
                + ", ".join(missing_fields)
            )
        with self._lock:
            if self._closed:
                raise ControllerNotReadyError("controller is closed")
            if self._opened:
                return
            self._health.open()
            self._ready.clear()
            self._stop.clear()
            self._seen_sources.clear()
            try:
                if self._config.ros2.motion_enabled:
                    runtime = create_read_write_runtime(
                        config=self._config.ros2,
                        controller_config=self._config,
                        cache=self._cache,
                        receipt_clock=self._clock,
                        on_source=self._record_source,
                        on_fault=self._record_fault,
                    )
                    if runtime.command_publishers is None:
                        raise ControllerNotReadyError(
                            "ROS 2 command publishers were not created"
                        )
                    executor = DirectActionExecutor(
                        (
                            lambda command: self._publish_command_or_fault(
                                runtime.command_publishers,
                                command,
                            )
                        ),
                        clock=self._clock,
                    )
                    executor.start()
                    self._executor = executor
                else:
                    runtime = create_read_only_runtime(
                        config=self._config.ros2,
                        cache=self._cache,
                        receipt_clock=self._clock,
                        on_source=self._record_source,
                        on_fault=self._record_fault,
                    )
            except BaseException:
                self._health.close()
                self._ready.clear()
                self._stop.set()
                self._seen_sources.clear()
                raise
            thread = Thread(
                target=self._spin,
                args=(runtime,),
                name="f1-ros2-readonly-executor",
                daemon=True,
            )
            self._runtime = runtime
            self._thread = thread
            self._opened = True
            thread.start()

    def wait_ready(self, timeout_s: float) -> None:
        """Wait until all seven logical sensor sources have arrived."""

        timeout = self._checked_timeout(timeout_s)
        self._require_open()
        if not self._ready.wait(timeout=timeout):
            raise ControllerNotReadyError("controller did not become ready in time")
        health = self._health.snapshot()
        if not health.ready:
            raise ControllerNotReadyError(health.reason or "controller is not ready")

    def read_observation(
        self,
        *,
        max_age_s: float,
        max_skew_s: float,
        newer_than: float | None = None,
    ) -> RobotObservation:
        """Return one raw-size coherent read-only sensor snapshot."""

        self._require_open()
        return self._cache.snapshot_with_clock(
            clock=self._clock,
            max_age_s=max_age_s,
            max_skew_s=max_skew_s,
            newer_than_s=newer_than,
        )

    def submit_command(
        self, command: DualArmCommand | DualArmTcpCommand
    ) -> CommandReceipt:
        """Submit TCP policy commands when motion publishing is enabled."""

        if not self._config.ros2.motion_enabled:
            raise CommandRejectedError(
                "ROS 2 backend is read-only; "
                f"command_id {command.command_id} was not sent"
            )
        self._require_open()
        executor = self._executor
        if executor is None or not isinstance(command, DualArmTcpCommand):
            raise CommandRejectedError(
                "ROS 2 backend accepts only TCP commands when motion is enabled; "
                f"command_id {command.command_id} was not sent"
            )
        return executor.submit(command)

    def submit_reset_command(
        self, command: DualArmResetCommand | DualArmTcpResetCommand
    ) -> CommandReceipt:
        """Submit TCP reset commands when motion publishing is enabled."""

        if not self._config.ros2.motion_enabled:
            raise CommandRejectedError(
                "ROS 2 backend is read-only; "
                f"reset command_id {command.command_id} was not sent"
            )
        self._require_open()
        executor = self._executor
        if executor is None or not isinstance(command, DualArmTcpResetCommand):
            raise CommandRejectedError(
                "ROS 2 backend accepts only TCP reset commands when motion is enabled; "
                f"reset command_id {command.command_id} was not sent"
            )
        return executor.submit(command)

    def get_command_status(self, command_id: int) -> CommandStatus:
        """Reject status lookup because this backend never accepts commands."""

        executor = self._executor
        if executor is None:
            raise CommandRejectedError(
                f"ROS 2 backend is read-only; command_id {command_id} has no status"
            )
        return executor.get_status(command_id)

    def health(self) -> ControllerHealth:
        """Return current subscription readiness or callback fault state."""

        self._require_open()
        return self._health.snapshot()

    def stop_experiment_motion(self, reason: str) -> None:
        """Stop this read-only lifecycle without touching external ROS nodes."""

        if not isinstance(reason, str) or not reason:
            raise ControllerLifecycleError("reason must be a non-empty string")
        self._require_open()
        self._stop_open_lifecycle()

    def close(self) -> None:
        """Close only this controller's executor, subscriptions, node, and context."""

        with self._lock:
            if self._closed:
                return
            opened = self._opened
            self._closed = True
        if opened:
            self._stop_open_lifecycle()

    def _spin(self, runtime: ReadOnlyRos2Runtime) -> None:
        try:
            while not self._stop.is_set():
                runtime.spin_once(timeout_s=0.05)
        except Exception as error:
            self._record_fault(f"ROS 2 executor: {error}")

    def _record_source(self, source: str) -> None:
        with self._lock:
            self._seen_sources.add(source)
            if self._required_sources.issubset(self._seen_sources):
                self._health.set_ready()
                self._ready.set()

    def _record_fault(self, reason: str) -> None:
        self._health.set_fault(reason)
        self._ready.clear()

    def _publish_command_or_fault(self, command_publishers, command) -> None:
        try:
            command_publishers.publish(
                command,
                max_state_age_s=self._config.max_observation_age_s,
            )
        except Exception as error:
            self._record_fault(f"ROS 2 command publish failed: {error}")
            raise

    def _stop_open_lifecycle(self) -> None:
        with self._lock:
            runtime = self._runtime
            thread = self._thread
            executor = self._executor
            self._opened = False
            self._runtime = None
            self._thread = None
            self._executor = None
            self._ready.clear()
            self._stop.set()
        if thread is not None:
            thread.join(timeout=_CLOSE_TIMEOUT_S)
            if thread.is_alive():
                self._health.set_fault("ROS 2 executor did not close within timeout")
                raise ControllerLifecycleError(
                    "ROS 2 executor did not close within timeout"
                )
        if executor is not None:
            executor.stop("ROS 2 controller lifecycle stopped")
            executor.close()
        if runtime is not None:
            runtime.close()
        self._health.close()

    def _require_open(self) -> None:
        with self._lock:
            if not self._opened or self._closed:
                raise ControllerNotReadyError("controller is not open")

    @staticmethod
    def _checked_timeout(timeout_s: float) -> float:
        if isinstance(timeout_s, str):
            raise ControllerNotReadyError("timeout_s must be finite and non-negative")
        try:
            timeout = float(timeout_s)
        except (TypeError, ValueError, OverflowError) as error:
            raise ControllerNotReadyError(
                "timeout_s must be finite and non-negative"
            ) from error
        if not isfinite(timeout) or timeout < 0.0:
            raise ControllerNotReadyError("timeout_s must be finite and non-negative")
        return timeout
