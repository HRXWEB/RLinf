"""JointState conversion without importing ROS modules."""

from math import isfinite
from numbers import Integral, Real

import numpy as np

from f1_robot_controller.errors import ObservationUnavailableError


def source_timestamp_seconds(message: object) -> float:
    """Return a finite seconds value from a ROS ``header.stamp`` object."""

    try:
        stamp = message.header.stamp
        sec = stamp.sec
        nanosec = stamp.nanosec
    except AttributeError as error:
        raise ObservationUnavailableError(
            "ROS message header stamp must contain integer sec and nanosec"
        ) from error
    if isinstance(sec, bool) or not isinstance(sec, Integral):
        raise ObservationUnavailableError("ROS message stamp sec must be an integer")
    if isinstance(nanosec, bool) or not isinstance(nanosec, Integral):
        raise ObservationUnavailableError(
            "ROS message stamp nanosec must be an integer"
        )
    normalized_nanosec = int(nanosec)
    if not 0 <= normalized_nanosec < 1_000_000_000:
        raise ObservationUnavailableError(
            "ROS message stamp nanosec must be in [0, 1000000000)"
        )
    return float(int(sec)) + normalized_nanosec * 1e-9


def joint_positions_from_joint_state(
    message: object,
    *,
    joint_names: tuple[str, ...],
    position_scale_to_rad: float,
) -> tuple[np.ndarray, float]:
    """Map named JointState positions into configured order and radians."""

    try:
        names = tuple(message.name)
        positions = tuple(message.position)
    except (AttributeError, TypeError) as error:
        raise ObservationUnavailableError(
            "joint state must contain name and position arrays"
        ) from error
    if len(names) != len(positions) or len(set(names)) != len(names):
        raise ObservationUnavailableError(
            "joint state names must be unique and align with positions"
        )
    position_by_name = dict(zip(names, positions, strict=True))
    if missing := [name for name in joint_names if name not in position_by_name]:
        raise ObservationUnavailableError(
            f"joint state is missing configured joints: {', '.join(missing)}"
        )
    selected: list[float] = []
    for name in joint_names:
        value = position_by_name[name]
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ObservationUnavailableError(f"joint {name} position is not finite")
        normalized = float(value) * position_scale_to_rad
        if not isfinite(normalized):
            raise ObservationUnavailableError(f"joint {name} position is not finite")
        selected.append(normalized)
    return np.asarray(selected, dtype=np.float64), source_timestamp_seconds(message)
