"""ROS 2 TCP/gripper command publisher adapter with delayed ROS imports."""

from collections.abc import Callable, Mapping
from math import isfinite
from threading import RLock
from time import monotonic
from typing import Any

from f1_robot_controller.backends.ros2.conversions.joints import (
    source_timestamp_seconds,
)
from f1_robot_controller.config import ControllerConfig, Ros2PublishMode, Ros2QosConfig
from f1_robot_controller.errors import CommandRejectedError
from f1_robot_controller.types import DualArmTcpCommand, DualArmTcpResetCommand
from f1_robot_controller.validation.commands import (
    validate_tcp_command,
    validate_tcp_reset_command,
)

ROS2_TCP_NAMES = ("x", "y", "z", "rx", "ry", "rz")
_COMMAND_SOURCES = ("left_tcp", "right_tcp", "left_gripper", "right_gripper")
_PUBLISH_ORDER = ("left_tcp", "right_tcp", "left_gripper", "right_gripper")


def command_qos_profile(config: Ros2QosConfig, qos_module: Any) -> Any:
    """Build the hq-robot1-compatible motion command QoS profile."""

    return qos_module.QoSProfile(
        reliability=(
            qos_module.ReliabilityPolicy.RELIABLE
            if config.reliability == "reliable"
            else qos_module.ReliabilityPolicy.BEST_EFFORT
        ),
        durability=qos_module.DurabilityPolicy.VOLATILE,
        history=qos_module.HistoryPolicy.KEEP_LAST,
        depth=config.depth,
    )


class Ros2CommandPublishers:
    """Validate, construct, then publish one latest TCP command to four topics."""

    def __init__(
        self,
        *,
        publishers: Mapping[str, Any],
        config: ControllerConfig,
        joint_state_type: type,
        gripper_command_type: type,
        clock: Callable[[], float] = monotonic,
        synthetic_only: bool = False,
    ) -> None:
        if set(publishers) != set(_COMMAND_SOURCES):
            raise ValueError("publishers must define four command sources")
        self._publishers = dict(publishers)
        self._config = config
        self._joint_state_type = joint_state_type
        self._gripper_command_type = gripper_command_type
        self._clock = clock
        self._synthetic_only = synthetic_only
        self._state_received_at: dict[str, float] = {}
        self._closed = False
        self._lock = RLock()

    def update_state(
        self,
        source: str,
        message: object,
        *,
        received_at_monotonic_s: float | None = None,
    ) -> None:
        """Record one observed command-state source as fresh and finite."""

        if source not in _COMMAND_SOURCES:
            raise CommandRejectedError(f"unknown command state source: {source}")
        if source.endswith("tcp"):
            self._validate_tcp_state(source, message)
        else:
            self._validate_gripper_state(source, message)
        timestamp_s = (
            self._clock()
            if received_at_monotonic_s is None
            else float(received_at_monotonic_s)
        )
        if not isfinite(timestamp_s):
            raise CommandRejectedError(f"{source} state timestamp must be finite")
        with self._lock:
            self._state_received_at[source] = timestamp_s

    def publish(
        self,
        command: DualArmTcpCommand | DualArmTcpResetCommand,
        *,
        max_state_age_s: float,
    ) -> None:
        """Publish a fully validated logical command, or publish nothing."""

        with self._lock:
            if self._closed:
                raise CommandRejectedError("ROS 2 command publishers are closed")
            self._require_publish_capability()
            if isinstance(command, DualArmTcpResetCommand):
                validate_tcp_reset_command(command, self._config)
            else:
                validate_tcp_command(command, self._config)
            self._require_fresh_states(max_state_age_s=max_state_age_s)
            messages = self._build_messages(command)
            for source in _PUBLISH_ORDER:
                self._publishers[source].publish(messages[source])

    def _require_publish_capability(self) -> None:
        if self._synthetic_only:
            return
        mode = self._config.ros2.publish_mode
        if mode is Ros2PublishMode.SEQUENTIAL:
            return
        if mode is Ros2PublishMode.VENDOR_ATOMIC:
            if self._config.ros2.has_vendor_atomic_command_capability():
                return
            raise CommandRejectedError(
                "real ROS 2 vendor_atomic commands require vendor atomic-latch evidence"
            )
        raise CommandRejectedError(
            "real ROS 2 command publishing requires non-disabled publish_mode"
        )

    def close(self) -> None:
        """Reject all future publications."""

        with self._lock:
            self._closed = True

    def _require_fresh_states(self, *, max_state_age_s: float) -> None:
        try:
            max_age = float(max_state_age_s)
        except (TypeError, ValueError, OverflowError) as error:
            raise CommandRejectedError("max_state_age_s must be finite") from error
        if not isfinite(max_age) or max_age < 0.0:
            raise CommandRejectedError("max_state_age_s must be finite")
        now_s = self._clock()
        if not isfinite(now_s):
            raise CommandRejectedError("clock must be finite")
        for source in _COMMAND_SOURCES:
            received_at_s = self._state_received_at.get(source)
            if received_at_s is None:
                raise CommandRejectedError(f"{source} state is unavailable")
            if now_s - received_at_s > max_age:
                raise CommandRejectedError(f"{source} state is stale")

    def _build_messages(
        self, command: DualArmTcpCommand | DualArmTcpResetCommand
    ) -> dict[str, object]:
        left_tcp = self._joint_state_type()
        left_tcp.name = list(ROS2_TCP_NAMES)
        left_tcp.position = self._vendor_tcp_position(command.left_tcp_target_m_deg)

        right_tcp = self._joint_state_type()
        right_tcp.name = list(ROS2_TCP_NAMES)
        right_tcp.position = self._vendor_tcp_position(command.right_tcp_target_m_deg)

        left_gripper = self._gripper_command_type()
        left_gripper.position = float(command.left_gripper_target)
        left_gripper.max_effort = 0.0

        right_gripper = self._gripper_command_type()
        right_gripper.position = float(command.right_gripper_target)
        right_gripper.max_effort = 0.0

        return {
            "left_tcp": left_tcp,
            "right_tcp": right_tcp,
            "left_gripper": left_gripper,
            "right_gripper": right_gripper,
        }

    @staticmethod
    def _vendor_tcp_position(values: object) -> list[float]:
        tcp = [float(value) for value in values]
        return [tcp[0] * 1000.0, tcp[1] * 1000.0, tcp[2] * 1000.0, *tcp[3:]]

    @staticmethod
    def _validate_tcp_state(source: str, message: object) -> None:
        Ros2CommandPublishers._validate_state_header(source, message)
        names = list(getattr(message, "name", []))
        positions = list(getattr(message, "position", []))
        if names != list(ROS2_TCP_NAMES):
            raise CommandRejectedError(f"{source} state names must be {ROS2_TCP_NAMES}")
        if len(positions) != 6:
            raise CommandRejectedError(f"{source} state position must have size 6")
        for index, value in enumerate(positions):
            try:
                position = float(value)
            except (TypeError, ValueError, OverflowError) as error:
                raise CommandRejectedError(
                    f"{source} state position {index} must be finite"
                ) from error
            if not isfinite(position):
                raise CommandRejectedError(
                    f"{source} state position {index} must be finite"
                )

    @staticmethod
    def _validate_gripper_state(source: str, message: object) -> None:
        Ros2CommandPublishers._validate_state_header(source, message)
        positions = list(getattr(message, "position", []))
        if len(positions) != 1:
            raise CommandRejectedError(f"{source} state position must have size 1")
        for value in positions:
            try:
                position = float(value)
            except (TypeError, ValueError, OverflowError) as error:
                raise CommandRejectedError(f"{source} state must be finite") from error
            if not isfinite(position):
                raise CommandRejectedError(f"{source} state must be finite")

    @staticmethod
    def _validate_state_header(source: str, message: object) -> None:
        try:
            frame_id = message.header.frame_id
        except AttributeError as error:
            raise CommandRejectedError(
                f"{source} state header frame_id must be a string"
            ) from error
        if not isinstance(frame_id, str):
            raise CommandRejectedError(
                f"{source} state header frame_id must be a string"
            )
        try:
            source_timestamp_seconds(message)
        except Exception as error:
            raise CommandRejectedError(
                f"{source} state timestamp must be finite"
            ) from error
