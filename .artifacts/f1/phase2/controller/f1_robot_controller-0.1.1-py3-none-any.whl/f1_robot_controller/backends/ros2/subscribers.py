"""Lightweight read-only subscriber callbacks."""

from collections.abc import Callable
from time import monotonic

from f1_robot_controller.config import Ros2ControllerConfig
from f1_robot_controller.runtime.observation_cache import ObservationCache

from .conversions.grippers import gripper_position_from_joint_state
from .conversions.images import image_message_to_rgb
from .conversions.joints import joint_positions_from_joint_state
from .conversions.tcp import tcp_pose_from_joint_state


class ReadOnlySubscriberCallbacks:
    """Convert six physical subscriptions into seven latest-only sources."""

    def __init__(
        self,
        cache: ObservationCache,
        *,
        config: Ros2ControllerConfig,
        bridge: object,
        receipt_clock: Callable[[], float] = monotonic,
        on_source: Callable[[str], None] = lambda _source: None,
        on_fault: Callable[[str], None] = lambda _reason: None,
    ) -> None:
        self._cache = cache
        self._config = config
        self._bridge = bridge
        self._receipt_clock = receipt_clock
        self._on_source = on_source
        self._on_fault = on_fault

    def joint_state(self, message: object) -> None:
        """Atomically update both logical arm sources from one physical topic."""

        try:
            joint_scale = self._config.joint_position_scale_to_rad
            if joint_scale is None:
                raise ValueError("joint position scale to radians is not configured")
            received_at_s = self._receipt_clock()
            left, left_source_s = joint_positions_from_joint_state(
                message,
                joint_names=self._config.left_joint_names,
                position_scale_to_rad=joint_scale,
            )
            right, right_source_s = joint_positions_from_joint_state(
                message,
                joint_names=self._config.right_joint_names,
                position_scale_to_rad=joint_scale,
            )
            self._cache.update_batch(
                {
                    "left_joint_position": (left, left_source_s, received_at_s),
                    "right_joint_position": (right, right_source_s, received_at_s),
                }
            )
        except Exception as error:  # ROS callbacks must surface faults, not escape.
            self._on_fault(f"joint_state: {error}")
            return
        self._on_source("left_joint_position")
        self._on_source("right_joint_position")

    def left_gripper_state(self, message: object) -> None:
        """Update the normalized left-gripper source."""

        self._gripper(
            "left_gripper_position",
            message,
            raw_open=self._config.left_gripper_raw_open,
            raw_closed=self._config.left_gripper_raw_closed,
        )

    def right_gripper_state(self, message: object) -> None:
        """Update the normalized right-gripper source."""

        self._gripper(
            "right_gripper_position",
            message,
            raw_open=self._config.right_gripper_raw_open,
            raw_closed=self._config.right_gripper_raw_closed,
        )

    def left_tcp_state(self, message: object) -> None:
        """Update the canonical left TCP pose source from vendor state."""

        self._tcp_pose("left_tcp_pose", message)

    def right_tcp_state(self, message: object) -> None:
        """Update the canonical right TCP pose source from vendor state."""

        self._tcp_pose("right_tcp_pose", message)

    def head_color(self, message: object) -> None:
        """Update the raw-size head RGB source."""

        self._image("head_color", message)

    def left_wrist_color(self, message: object) -> None:
        """Update the raw-size left-wrist RGB source."""

        self._image("left_wrist_color", message)

    def right_wrist_color(self, message: object) -> None:
        """Update the raw-size right-wrist RGB source."""

        self._image("right_wrist_color", message)

    def _gripper(
        self,
        sensor_name: str,
        message: object,
        *,
        raw_open: float,
        raw_closed: float,
    ) -> None:
        try:
            received_at_s = self._receipt_clock()
            value, source_s = gripper_position_from_joint_state(
                message,
                raw_open=raw_open,
                raw_closed=raw_closed,
            )
            self._cache.update(
                sensor_name,
                value,
                source_timestamp_s=source_s,
                received_at_monotonic_s=received_at_s,
            )
        except Exception as error:  # ROS callbacks must surface faults, not escape.
            self._on_fault(f"{sensor_name}: {error}")
            return
        self._on_source(sensor_name)

    def _image(self, sensor_name: str, message: object) -> None:
        try:
            received_at_s = self._receipt_clock()
            value, source_s = image_message_to_rgb(
                message,
                bridge=self._bridge,
                transport=self._config.image_transports[sensor_name],
            )
            self._cache.update(
                sensor_name,
                value,
                source_timestamp_s=source_s,
                received_at_monotonic_s=received_at_s,
            )
        except Exception as error:  # ROS callbacks must surface faults, not escape.
            self._on_fault(f"{sensor_name}: {error}")
            return
        self._on_source(sensor_name)

    def _tcp_pose(self, sensor_name: str, message: object) -> None:
        try:
            received_at_s = self._receipt_clock()
            value, source_s = tcp_pose_from_joint_state(message)
            self._cache.update(
                sensor_name,
                value,
                source_timestamp_s=source_s,
                received_at_monotonic_s=received_at_s,
            )
        except Exception as error:  # ROS callbacks must surface faults, not escape.
            self._on_fault(f"{sensor_name}: {error}")
            return
        self._on_source(sensor_name)
