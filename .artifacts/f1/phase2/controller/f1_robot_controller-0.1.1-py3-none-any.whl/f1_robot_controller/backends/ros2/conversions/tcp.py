"""TCP JointState conversion without importing ROS modules."""

from math import isfinite
from numbers import Real

import numpy as np

from f1_robot_controller.errors import ObservationUnavailableError

from .joints import source_timestamp_seconds

ROS2_TCP_NAMES = ("x", "y", "z", "rx", "ry", "rz")


def tcp_pose_from_joint_state(message: object) -> tuple[np.ndarray, float]:
    """Convert vendor TCP ``JointState`` mm/degree positions to m/degree."""

    try:
        names = tuple(message.name)
        positions = tuple(message.position)
    except (AttributeError, TypeError) as error:
        raise ObservationUnavailableError(
            "TCP state must contain name and position arrays"
        ) from error
    if names != ROS2_TCP_NAMES:
        raise ObservationUnavailableError(
            "TCP state names must be exactly x,y,z,rx,ry,rz"
        )
    if len(positions) != 6:
        raise ObservationUnavailableError("TCP state position must have size 6")

    canonical: list[float] = []
    for index, value in enumerate(positions):
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ObservationUnavailableError(
                f"TCP state position {index} must be finite"
            )
        normalized = float(value) * 0.001 if index < 3 else float(value)
        if not isfinite(normalized):
            raise ObservationUnavailableError(
                f"TCP state position {index} must be finite"
            )
        canonical.append(normalized)
    return np.asarray(canonical, dtype=np.float64), source_timestamp_seconds(message)
