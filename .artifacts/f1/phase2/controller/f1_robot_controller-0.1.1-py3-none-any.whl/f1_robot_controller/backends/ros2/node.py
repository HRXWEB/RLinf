"""Lazy construction of the controller-owned ROS 2 subscription graph."""

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from f1_robot_controller.config import (
    Ros2ControllerConfig,
    Ros2ImageTransport,
    Ros2QosConfig,
)
from f1_robot_controller.errors import BackendUnavailableError
from f1_robot_controller.runtime.observation_cache import ObservationCache

from .publishers import Ros2CommandPublishers, command_qos_profile
from .subscribers import ReadOnlySubscriberCallbacks


@dataclass
class ReadOnlyRos2Runtime:
    """Controller-owned ROS objects, containing subscriptions but no writers."""

    context: Any
    executor: Any
    node: Any
    subscriptions: tuple[Any, ...]
    command_publishers: Ros2CommandPublishers | None = None

    def spin_once(self, *, timeout_s: float) -> None:
        """Dispatch at most one bounded executor iteration."""

        self.executor.spin_once(timeout_sec=timeout_s)

    def close(self) -> None:
        """Destroy only this controller's node, executor, and context."""

        self.executor.remove_node(self.node)
        self.node.destroy_node()
        self.executor.shutdown(timeout_sec=0.5)
        if self.context.ok():
            self.context.shutdown()


def strip_implicit_writers(node: Any) -> None:
    """Remove rclpy-internal publishers/clients from the read-only node."""

    for publisher in tuple(node.publishers):
        if not node.destroy_publisher(publisher):
            raise BackendUnavailableError(
                "read-only ROS 2 node could not remove an implicit publisher"
            )
    for client in tuple(node.clients):
        if not node.destroy_client(client):
            raise BackendUnavailableError(
                "read-only ROS 2 node could not remove an implicit service client"
            )
    if tuple(node.publishers) or tuple(node.clients):
        raise BackendUnavailableError(
            "read-only ROS 2 node must contain zero publishers and service clients"
        )


def _qos_profile(config: Ros2QosConfig, qos_module: Any) -> Any:
    """Build a ROS QoSProfile from the backend-neutral frozen config."""

    return qos_module.QoSProfile(
        reliability=(
            qos_module.ReliabilityPolicy.RELIABLE
            if config.reliability == "reliable"
            else qos_module.ReliabilityPolicy.BEST_EFFORT
        ),
        durability=(
            qos_module.DurabilityPolicy.TRANSIENT_LOCAL
            if config.durability == "transient_local"
            else qos_module.DurabilityPolicy.VOLATILE
        ),
        history=qos_module.HistoryPolicy.KEEP_LAST,
        depth=config.depth,
    )


def _default_sensor_qos_profile(qos_module: Any) -> Any:
    """Build the compatible read-only sensor subscription QoS profile."""

    return qos_module.QoSProfile(
        reliability=qos_module.ReliabilityPolicy.BEST_EFFORT,
        durability=qos_module.DurabilityPolicy.VOLATILE,
        history=qos_module.HistoryPolicy.KEEP_LAST,
        depth=1,
    )


def _qos_profile_for_source(
    source: str,
    qos_by_source: Mapping[str, Ros2QosConfig] | None,
    qos_module: Any,
) -> Any:
    """Return explicit source QoS or the compatible sensor default."""

    if qos_by_source is None:
        return _default_sensor_qos_profile(qos_module)
    return _qos_profile(qos_by_source[source], qos_module)


def _message_type_for_source(
    source: str,
    image_transports: Mapping[str, Ros2ImageTransport],
    image_type: Any,
    compressed_image_type: Any,
) -> Any:
    """Return the ROS message class for an explicitly configured image source."""

    if source not in {"head_color", "left_wrist_color", "right_wrist_color"}:
        raise ValueError(f"{source} is not an image source")
    return (
        compressed_image_type
        if image_transports[source] is Ros2ImageTransport.COMPRESSED
        else image_type
    )


def create_read_only_runtime(
    *,
    config: Ros2ControllerConfig,
    cache: ObservationCache,
    receipt_clock: Any,
    on_source: Any,
    on_fault: Any,
) -> ReadOnlyRos2Runtime:
    """Create six subscriptions in a dedicated context via delayed imports."""

    try:
        import rclpy
        import rclpy.qos as qos
        from cv_bridge import CvBridge
        from rclpy.context import Context
        from rclpy.executors import SingleThreadedExecutor
        from sensor_msgs.msg import CompressedImage, Image, JointState
    except ImportError as error:
        raise BackendUnavailableError(
            "ROS 2 read-only backend requires rclpy, cv_bridge, and sensor_msgs"
        ) from error

    context = Context()
    node = None
    executor = None
    try:
        rclpy.init(args=None, context=context)
        node = rclpy.create_node(
            config.node_name,
            context=context,
            enable_rosout=False,
            start_parameter_services=False,
        )
        strip_implicit_writers(node)
        executor = SingleThreadedExecutor(context=context)
        callbacks = ReadOnlySubscriberCallbacks(
            cache,
            config=config,
            bridge=CvBridge(),
            receipt_clock=receipt_clock,
            on_source=on_source,
            on_fault=on_fault,
        )
        message_and_callback = {
            "head_color": (
                _message_type_for_source(
                    "head_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.head_color,
            ),
            "left_wrist_color": (
                _message_type_for_source(
                    "left_wrist_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.left_wrist_color,
            ),
            "right_wrist_color": (
                _message_type_for_source(
                    "right_wrist_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.right_wrist_color,
            ),
            "joint_state": (JointState, callbacks.joint_state),
            "left_gripper_position": (
                JointState,
                callbacks.left_gripper_state,
            ),
            "right_gripper_position": (
                JointState,
                callbacks.right_gripper_state,
            ),
        }
        subscriptions = tuple(
            node.create_subscription(
                message_and_callback[source][0],
                config.sensor_topics[source],
                message_and_callback[source][1],
                _qos_profile_for_source(source, config.qos_by_source, qos),
            )
            for source in config.sensor_topics
        )
        executor.add_node(node)
        return ReadOnlyRos2Runtime(
            context=context,
            executor=executor,
            node=node,
            subscriptions=subscriptions,
        )
    except Exception:
        if executor is not None:
            executor.shutdown(timeout_sec=0.5)
        if node is not None:
            node.destroy_node()
        if context.ok():
            context.shutdown()
        raise


def create_read_write_runtime(
    *,
    config: Ros2ControllerConfig,
    controller_config: Any,
    cache: ObservationCache,
    receipt_clock: Any,
    on_source: Any,
    on_fault: Any,
) -> ReadOnlyRos2Runtime:
    """Create sensor subscriptions plus TCP/gripper command publishers."""

    try:
        import rclpy
        import rclpy.qos as qos
        from control_msgs.msg import GripperCommand
        from cv_bridge import CvBridge
        from rclpy.context import Context
        from rclpy.executors import SingleThreadedExecutor
        from sensor_msgs.msg import CompressedImage, Image, JointState
    except ImportError as error:
        raise BackendUnavailableError(
            "ROS 2 command backend requires rclpy, cv_bridge, sensor_msgs, "
            "and control_msgs"
        ) from error

    context = Context()
    node = None
    executor = None
    try:
        rclpy.init(args=None, context=context)
        node = rclpy.create_node(
            config.node_name,
            context=context,
            enable_rosout=False,
            start_parameter_services=False,
        )
        strip_implicit_writers(node)
        executor = SingleThreadedExecutor(context=context)
        callbacks = ReadOnlySubscriberCallbacks(
            cache,
            config=config,
            bridge=CvBridge(),
            receipt_clock=receipt_clock,
            on_source=on_source,
            on_fault=on_fault,
        )
        message_and_callback = {
            "head_color": (
                _message_type_for_source(
                    "head_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.head_color,
            ),
            "left_wrist_color": (
                _message_type_for_source(
                    "left_wrist_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.left_wrist_color,
            ),
            "right_wrist_color": (
                _message_type_for_source(
                    "right_wrist_color",
                    config.image_transports,
                    Image,
                    CompressedImage,
                ),
                callbacks.right_wrist_color,
            ),
            "joint_state": (JointState, callbacks.joint_state),
            "left_gripper_position": (
                JointState,
                callbacks.left_gripper_state,
            ),
            "right_gripper_position": (
                JointState,
                callbacks.right_gripper_state,
            ),
        }
        subscriptions = [
            node.create_subscription(
                message_and_callback[source][0],
                config.sensor_topics[source],
                message_and_callback[source][1],
                _qos_profile_for_source(source, config.qos_by_source, qos),
            )
            for source in config.sensor_topics
        ]
        command_publishers = Ros2CommandPublishers(
            publishers={
                "left_tcp": node.create_publisher(
                    JointState,
                    config.command_topics["left_tcp"],
                    command_qos_profile(config.command_qos, qos),
                ),
                "right_tcp": node.create_publisher(
                    JointState,
                    config.command_topics["right_tcp"],
                    command_qos_profile(config.command_qos, qos),
                ),
                "left_gripper": node.create_publisher(
                    GripperCommand,
                    config.command_topics["left_gripper"],
                    command_qos_profile(config.command_qos, qos),
                ),
                "right_gripper": node.create_publisher(
                    GripperCommand,
                    config.command_topics["right_gripper"],
                    command_qos_profile(config.command_qos, qos),
                ),
            },
            config=controller_config,
            joint_state_type=JointState,
            gripper_command_type=GripperCommand,
            clock=receipt_clock,
        )

        def state_callback(source: str):
            def callback(message: object) -> None:
                try:
                    command_publishers.update_state(source, message)
                    if source == "left_tcp":
                        callbacks.left_tcp_state(message)
                    elif source == "right_tcp":
                        callbacks.right_tcp_state(message)
                except Exception as error:
                    on_fault(f"{source}: {error}")
                    return
                on_source(source)

            return callback

        subscriptions.extend(
            node.create_subscription(
                JointState,
                config.command_state_topics[source],
                state_callback(source),
                _qos_profile(config.command_qos, qos),
            )
            for source in ("left_tcp", "right_tcp", "left_gripper", "right_gripper")
        )
        executor.add_node(node)
        return ReadOnlyRos2Runtime(
            context=context,
            executor=executor,
            node=node,
            subscriptions=tuple(subscriptions),
            command_publishers=command_publishers,
        )
    except Exception:
        if executor is not None:
            executor.shutdown(timeout_sec=0.5)
        if node is not None:
            node.destroy_node()
        if context.ok():
            context.shutdown()
        raise
