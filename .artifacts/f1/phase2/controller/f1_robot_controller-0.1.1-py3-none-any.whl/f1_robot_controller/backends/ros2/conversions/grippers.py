"""Gripper JointState conversion without importing ROS modules."""

from math import isfinite
from numbers import Real

from f1_robot_controller.errors import ObservationUnavailableError

from .joints import source_timestamp_seconds


def gripper_position_from_joint_state(
    message: object,
    *,
    raw_open: float,
    raw_closed: float,
) -> tuple[float, float]:
    """Convert one raw gripper position to percent-closed ``[0, 100]``."""

    try:
        positions = tuple(message.position)
    except (AttributeError, TypeError) as error:
        raise ObservationUnavailableError(
            "gripper state must contain one position"
        ) from error
    if len(positions) != 1:
        raise ObservationUnavailableError("gripper state must contain one position")
    raw_position = positions[0]
    if isinstance(raw_position, bool) or not isinstance(raw_position, Real):
        raise ObservationUnavailableError("gripper position must be finite")
    percent_closed = 100.0 * (float(raw_position) - raw_open) / (raw_closed - raw_open)
    if not isfinite(percent_closed) or not 0.0 <= percent_closed <= 100.0:
        raise ObservationUnavailableError(
            "gripper position is outside configured raw endpoints"
        )
    return percent_closed, source_timestamp_seconds(message)
