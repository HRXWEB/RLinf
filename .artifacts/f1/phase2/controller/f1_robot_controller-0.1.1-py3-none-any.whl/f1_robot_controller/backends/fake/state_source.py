"""Deterministic canonical state for the Fake controller backend."""

from collections import deque
from collections.abc import Callable
from threading import RLock
from time import monotonic

import numpy as np

from f1_robot_controller.config import FakeControllerConfig
from f1_robot_controller.errors import CommandRejectedError
from f1_robot_controller.runtime.command_slot import Command
from f1_robot_controller.runtime.observation_cache import ObservationCache
from f1_robot_controller.types import (
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
)
from f1_robot_controller.validation import REQUIRED_SENSOR_KEYS

from .fault_injection import FakeFaultInjector

_STALE_OFFSET_S = 1_000_000_000.0


class FakeStateSource:
    """Own deterministic robot state and publish it into an observation cache."""

    def __init__(
        self,
        cache: ObservationCache,
        *,
        config: FakeControllerConfig | None = None,
        fault_injector: FakeFaultInjector | None = None,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        """Create zeroed arms and seed-stable, independent RGB camera frames."""

        self._cache = cache
        self._config = FakeControllerConfig() if config is None else config
        self._fault_injector = (
            FakeFaultInjector() if fault_injector is None else fault_injector
        )
        self._clock = clock
        self._lock = RLock()
        self._left_joint_position_rad = np.zeros(7, dtype=np.float64)
        self._left_gripper_position = 0.0
        self._left_tcp_pose_m_deg = np.zeros(6, dtype=np.float64)
        self._right_joint_position_rad = np.zeros(7, dtype=np.float64)
        self._right_gripper_position = 0.0
        self._right_tcp_pose_m_deg = np.zeros(6, dtype=np.float64)
        generator = np.random.default_rng(self._config.seed)
        image_shape = (
            self._config.image_height,
            self._config.image_width,
            3,
        )
        self._images = {
            "head_color": generator.integers(0, 256, size=image_shape, dtype=np.uint8),
            "left_wrist_color": generator.integers(
                0, 256, size=image_shape, dtype=np.uint8
            ),
            "right_wrist_color": generator.integers(
                0, 256, size=image_shape, dtype=np.uint8
            ),
        }
        self._command_history: deque[Command] = deque(
            maxlen=self._config.command_history_limit
        )

    @property
    def fault_injector(self) -> FakeFaultInjector:
        """Return the fault injector associated with this state source."""

        return self._fault_injector

    @property
    def command_history(self) -> tuple[Command, ...]:
        """Return commands applied to canonical state in dispatch order."""

        with self._lock:
            return tuple(self._command_history)

    def publish(self) -> None:
        """Push all non-missing canonical sensors into the shared cache."""

        with self._lock:
            self._publish_locked()

    def apply(self, command: Command) -> None:
        """Atomically set both arm and gripper targets, then publish them."""

        with self._lock:
            if isinstance(command, (DualArmCommand, DualArmResetCommand)):
                self._left_joint_position_rad = np.array(
                    command.left_joint_target_rad, dtype=np.float64, copy=True
                )
                self._left_gripper_position = float(command.left_gripper_target)
                self._right_joint_position_rad = np.array(
                    command.right_joint_target_rad, dtype=np.float64, copy=True
                )
                self._right_gripper_position = float(command.right_gripper_target)
            elif isinstance(command, (DualArmTcpCommand, DualArmTcpResetCommand)):
                self._left_tcp_pose_m_deg = np.array(
                    command.left_tcp_target_m_deg, dtype=np.float64, copy=True
                )
                self._left_gripper_position = float(command.left_gripper_target)
                self._right_tcp_pose_m_deg = np.array(
                    command.right_tcp_target_m_deg, dtype=np.float64, copy=True
                )
                self._right_gripper_position = float(command.right_gripper_target)
            else:
                raise CommandRejectedError("unsupported Fake command")
            self._command_history.append(command)
            self._publish_locked()

    def _publish_locked(self) -> None:
        """Publish one coherent canonical-state version while holding its lock."""

        timestamp_s = float(self._clock())
        stale_sensors, missing_sensors = self._fault_injector._sensor_faults()
        values: dict[str, np.ndarray | float] = {
            "left_joint_position": self._left_joint_position_rad,
            "left_gripper_position": self._left_gripper_position,
            "left_tcp_pose": self._left_tcp_pose_m_deg,
            "right_joint_position": self._right_joint_position_rad,
            "right_gripper_position": self._right_gripper_position,
            "right_tcp_pose": self._right_tcp_pose_m_deg,
            **self._images,
        }
        samples: dict[str, tuple[np.ndarray | float, float, float]] = {}
        for sensor_name in (*REQUIRED_SENSOR_KEYS, "left_tcp_pose", "right_tcp_pose"):
            if sensor_name in missing_sensors:
                continue
            received_at_monotonic_s = timestamp_s
            if sensor_name in stale_sensors:
                received_at_monotonic_s -= _STALE_OFFSET_S
            samples[sensor_name] = (
                values[sensor_name],
                timestamp_s,
                received_at_monotonic_s,
            )
        self._cache.update_batch(
            samples,
            invalidate=missing_sensors | stale_sensors,
        )
