"""Public controller composed from deterministic Fake backend primitives."""

from collections.abc import Callable
from math import isfinite
from threading import Event, RLock
from time import monotonic

from f1_robot_controller.config import ControllerConfig
from f1_robot_controller.controller import F1RobotController
from f1_robot_controller.errors import (
    ControllerNotReadyError,
    ObservationUnavailableError,
)
from f1_robot_controller.executors.fake import FakeActionExecutor
from f1_robot_controller.runtime.health_monitor import HealthMonitor
from f1_robot_controller.runtime.observation_cache import ObservationCache
from f1_robot_controller.runtime.timestamps import MonotonicStampAllocator
from f1_robot_controller.types import (
    CommandReceipt,
    CommandStatus,
    ControllerHealth,
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
    RobotObservation,
)
from f1_robot_controller.validation import (
    validate_command,
    validate_reset_command,
    validate_tcp_command,
    validate_tcp_reset_command,
)

from .fault_injection import FakeFaultInjector
from .state_source import FakeStateSource


class FakeRobotController(F1RobotController):
    """Deterministic in-process implementation of the controller contract."""

    def __init__(
        self,
        config: ControllerConfig,
        *,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        """Compose one isolated set of Fake runtime components.

        Args:
            config: Controller validation and Fake data configuration.
            clock: Monotonic clock shared by all owned components.
        """

        self._config = config
        self._stamp_allocator = MonotonicStampAllocator(clock)
        self._clock = self._stamp_allocator.next
        self._lifecycle_lock = RLock()
        self._opened = False
        self._closed = False
        self._ready_event = Event()

        self._observation_cache = ObservationCache(config)
        self._health_monitor = HealthMonitor(clock=self._clock)
        self._fault_injector = FakeFaultInjector()
        self._state_source = FakeStateSource(
            self._observation_cache,
            config=config.fake,
            fault_injector=self._fault_injector,
            clock=self._clock,
        )
        self._executor = FakeActionExecutor(
            self._state_source,
            fault_injector=self._fault_injector,
            health_monitor=self._health_monitor,
            clock=self._clock,
            command_latency_s=config.fake.command_latency_s,
        )

    @property
    def fault_injector(self) -> FakeFaultInjector:
        """Return this Fake controller's explicit fault controls."""

        return self._fault_injector

    def open(self) -> None:
        """Publish initial state and start the single owned executor once."""

        with self._lifecycle_lock:
            if self._closed:
                raise ControllerNotReadyError("controller is closed")
            if self._opened:
                return
            self._state_source.publish()
            self._executor.start()
            self._opened = True
            self._ready_event.set()

    def wait_ready(self, timeout_s: float) -> None:
        """Wait a bounded interval for an open lifecycle to report ready."""

        if isinstance(timeout_s, str):
            raise ControllerNotReadyError("timeout_s must be finite and non-negative")
        try:
            timeout_s = float(timeout_s)
        except (TypeError, ValueError, OverflowError) as error:
            raise ControllerNotReadyError(
                "timeout_s must be finite and non-negative"
            ) from error
        if not isfinite(timeout_s) or timeout_s < 0.0:
            raise ControllerNotReadyError("timeout_s must be finite and non-negative")
        self._require_open()
        if not self._ready_event.wait(timeout=timeout_s):
            raise ControllerNotReadyError("controller did not become ready in time")
        if not self._health_monitor.snapshot().ready:
            raise ControllerNotReadyError("controller is not ready")

    def read_observation(
        self,
        *,
        max_age_s: float,
        max_skew_s: float,
        newer_than: float | None = None,
    ) -> RobotObservation:
        """Return the latest coherent Fake observation within caller bounds."""

        with self._lifecycle_lock:
            self._require_open_locked()
            try:
                return self._observation_cache.snapshot_with_clock(
                    clock=self._clock,
                    max_age_s=max_age_s,
                    max_skew_s=max_skew_s,
                    newer_than_s=newer_than,
                )
            except ObservationUnavailableError:
                if newer_than is not None:
                    raise
                self._state_source.publish()
                return self._observation_cache.snapshot_with_clock(
                    clock=self._clock,
                    max_age_s=max_age_s,
                    max_skew_s=max_skew_s,
                )

    def submit_command(
        self, command: DualArmCommand | DualArmTcpCommand
    ) -> CommandReceipt:
        """Validate and submit one policy command to the Fake executor."""

        with self._lifecycle_lock:
            self._require_open_locked()
            if isinstance(command, DualArmTcpCommand):
                validate_tcp_command(command, self._config)
            else:
                validate_command(command, self._config)
            return self._executor.submit(command)

    def submit_reset_command(
        self, command: DualArmResetCommand | DualArmTcpResetCommand
    ) -> CommandReceipt:
        """Validate and submit one reset command to the Fake executor."""

        with self._lifecycle_lock:
            self._require_open_locked()
            if isinstance(command, DualArmTcpResetCommand):
                validate_tcp_reset_command(command, self._config)
            else:
                validate_reset_command(command, self._config)
            return self._executor.submit(command)

    def get_command_status(self, command_id: int) -> CommandStatus:
        """Return the Fake executor's retained status for one command."""

        with self._lifecycle_lock:
            self._require_open_locked()
            return self._executor.get_status(command_id)

    def health(self) -> ControllerHealth:
        """Return the shared Fake executor health snapshot."""

        with self._lifecycle_lock:
            self._require_open_locked()
            return self._health_monitor.snapshot()

    def stop_experiment_motion(self, reason: str) -> None:
        """Stop Fake motion without closing the controller-owned worker."""

        with self._lifecycle_lock:
            self._require_open_locked()
            self._executor.stop(reason)
            self._opened = False
            self._ready_event.clear()

    def close(self) -> None:
        """Close the Fake executor once and make the lifecycle terminal."""

        with self._lifecycle_lock:
            if self._closed:
                return
            self._executor.close()
            self._opened = False
            self._closed = True
            self._ready_event.clear()

    def _require_open(self) -> None:
        """Reject operations outside the open controller lifecycle."""

        with self._lifecycle_lock:
            self._require_open_locked()

    def _require_open_locked(self) -> None:
        """Reject operations unless the caller holds an open lifecycle."""

        if not self._opened or self._closed:
            raise ControllerNotReadyError("controller is not open")
