"""Explicit, thread-safe fault controls for the deterministic Fake backend."""

from threading import RLock

from f1_robot_controller.validation import REQUIRED_SENSOR_KEYS


class FakeFaultInjector:
    """Store requested sensor and one-shot command faults for Fake components."""

    def __init__(self) -> None:
        """Create an injector with no active faults."""

        self._lock = RLock()
        self._stale_sensors: set[str] = set()
        self._missing_sensors: set[str] = set()
        self._command_rejection: str | None = None
        self._executor_failure: str | None = None

    def inject_stale_sensor(self, sensor_name: str) -> None:
        """Make future publications for one sensor observably stale."""

        self._validate_sensor_name(sensor_name)
        with self._lock:
            self._stale_sensors.add(sensor_name)

    def inject_missing_sensor(self, sensor_name: str) -> None:
        """Omit one sensor from future state publications."""

        self._validate_sensor_name(sensor_name)
        with self._lock:
            self._missing_sensors.add(sensor_name)

    def reject_next_command(self, reason: str) -> None:
        """Reject the next Fake executor submission with ``reason``."""

        self._validate_reason(reason)
        with self._lock:
            self._command_rejection = reason

    def fail_executor_once(self, reason: str) -> None:
        """Raise from the next Fake sink dispatch with ``reason``."""

        self._validate_reason(reason)
        with self._lock:
            self._executor_failure = reason

    def clear(self) -> None:
        """Remove every active and pending injected fault."""

        with self._lock:
            self._stale_sensors.clear()
            self._missing_sensors.clear()
            self._command_rejection = None
            self._executor_failure = None

    def _sensor_faults(self) -> tuple[frozenset[str], frozenset[str]]:
        """Return stable copies of active stale and missing sensor controls."""

        with self._lock:
            return frozenset(self._stale_sensors), frozenset(self._missing_sensors)

    def _consume_command_rejection(self) -> str | None:
        """Consume the pending one-shot submission rejection."""

        with self._lock:
            reason = self._command_rejection
            self._command_rejection = None
            return reason

    def _consume_executor_failure(self) -> str | None:
        """Consume the pending one-shot sink failure."""

        with self._lock:
            reason = self._executor_failure
            self._executor_failure = None
            return reason

    @staticmethod
    def _validate_sensor_name(sensor_name: str) -> None:
        if sensor_name not in REQUIRED_SENSOR_KEYS:
            raise ValueError(f"unknown sensor: {sensor_name}")

    @staticmethod
    def _validate_reason(reason: str) -> None:
        if not isinstance(reason, str) or not reason:
            raise ValueError("fault reason must be a non-empty string")
