class ControllerError(RuntimeError):
    """Base error for controller failures."""


class ControllerNotReadyError(ControllerError):
    """Raised when an operation requires a ready controller."""


class ControllerLifecycleError(ControllerError):
    """Raised when owned controller resources cannot close cleanly."""


class CommandRejectedError(ControllerError):
    """Raised when a command violates the controller contract."""


class ObservationUnavailableError(ControllerError):
    """Raised when a coherent fresh observation cannot be built."""


class BackendUnavailableError(ControllerError):
    """Raised when the requested backend is not installed."""
