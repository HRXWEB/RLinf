"""Backend-neutral public controller contract."""

from abc import ABC, abstractmethod

from f1_robot_controller.types import (
    CommandReceipt,
    CommandStatus,
    ControllerHealth,
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
    RobotObservation,
)


class F1RobotController(ABC):
    """Control and observe one F1 dual-arm robot backend."""

    @abstractmethod
    def open(self) -> None:
        """Open the controller lifecycle."""

    @abstractmethod
    def wait_ready(self, timeout_s: float) -> None:
        """Wait up to ``timeout_s`` for the open controller to become ready."""

    @abstractmethod
    def read_observation(
        self,
        *,
        max_age_s: float,
        max_skew_s: float,
        newer_than: float | None = None,
    ) -> RobotObservation:
        """Return one coherent observation satisfying the supplied bounds."""

    @abstractmethod
    def submit_command(
        self, command: DualArmCommand | DualArmTcpCommand
    ) -> CommandReceipt:
        """Validate and asynchronously submit one policy command."""

    @abstractmethod
    def submit_reset_command(
        self, command: DualArmResetCommand | DualArmTcpResetCommand
    ) -> CommandReceipt:
        """Validate and asynchronously submit one reset command."""

    @abstractmethod
    def get_command_status(self, command_id: int) -> CommandStatus:
        """Return the latest retained status for ``command_id``."""

    @abstractmethod
    def health(self) -> ControllerHealth:
        """Return the current controller health snapshot."""

    @abstractmethod
    def stop_experiment_motion(self, reason: str) -> None:
        """Stop accepting motion and clear pending experiment work."""

    @abstractmethod
    def close(self) -> None:
        """Close owned resources or raise if bounded shutdown cannot finish."""
