from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]
UInt8Image = NDArray[np.uint8]


class CommandStatus(str, Enum):  # noqa: UP042
    """Lifecycle status for a dual-arm command."""

    CREATED = "created"
    ACCEPTED = "accepted"
    DISPATCHED = "dispatched"
    ACTIVE = "active"
    FINISHED_DISPATCH = "finished_dispatch"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    FAULT = "fault"


def _copy_vector(value: FloatArray, size: int, name: str) -> FloatArray:
    result = np.array(value, dtype=np.float64, copy=True)
    if result.shape != (size,):
        raise ValueError(f"{name} must have shape ({size},), got {result.shape}")
    result.setflags(write=False)
    return result


@dataclass(frozen=True)
class DualArmCommand:
    """Immutable target command for both robot arms.

    Args:
        command_id: Identifier assigned to the command.
        left_joint_target_rad: Seven left-arm joint targets in radians.
        left_gripper_target: Target position for the left gripper.
        right_joint_target_rad: Seven right-arm joint targets in radians.
        right_gripper_target: Target position for the right gripper.
        duration_s: Requested command duration in seconds.
        created_at_monotonic_s: Monotonic timestamp when the command was created.
    """

    command_id: int
    left_joint_target_rad: FloatArray
    left_gripper_target: float
    right_joint_target_rad: FloatArray
    right_gripper_target: float
    duration_s: float
    created_at_monotonic_s: float
    status: CommandStatus = field(default=CommandStatus.CREATED, init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "left_joint_target_rad",
            _copy_vector(self.left_joint_target_rad, 7, "left_joint_target_rad"),
        )
        object.__setattr__(
            self,
            "right_joint_target_rad",
            _copy_vector(self.right_joint_target_rad, 7, "right_joint_target_rad"),
        )


@dataclass(frozen=True)
class DualArmResetCommand:
    """Immutable command for returning both arms to reset targets.

    Args:
        command_id: Identifier assigned to the command.
        left_joint_target_rad: Seven left-arm joint targets in radians.
        left_gripper_target: Target position for the left gripper.
        right_joint_target_rad: Seven right-arm joint targets in radians.
        right_gripper_target: Target position for the right gripper.
        duration_s: Requested reset duration in seconds.
        tolerance_rad: Allowed joint-position error in radians.
        timeout_s: Maximum time allowed for the reset in seconds.
        created_at_monotonic_s: Monotonic timestamp when the command was created.
    """

    command_id: int
    left_joint_target_rad: FloatArray
    left_gripper_target: float
    right_joint_target_rad: FloatArray
    right_gripper_target: float
    duration_s: float
    tolerance_rad: float
    timeout_s: float
    created_at_monotonic_s: float

    def __post_init__(self) -> None:
        if self.timeout_s <= 0:
            raise ValueError("timeout_s must be positive")
        if self.duration_s <= 0:
            raise ValueError("duration_s must be positive")
        object.__setattr__(
            self,
            "left_joint_target_rad",
            _copy_vector(self.left_joint_target_rad, 7, "left_joint_target_rad"),
        )
        object.__setattr__(
            self,
            "right_joint_target_rad",
            _copy_vector(self.right_joint_target_rad, 7, "right_joint_target_rad"),
        )

    @classmethod
    def zeros(cls, *, duration_s: float, timeout_s: float) -> "DualArmResetCommand":
        """Build a reset command targeting zero joint and gripper positions.

        Args:
            duration_s: Requested reset duration in seconds.
            timeout_s: Maximum time allowed for the reset in seconds.

        Returns:
            A reset command with zero targets and the default joint tolerance.

        Raises:
            ValueError: If ``duration_s`` or ``timeout_s`` is not positive.
        """

        return cls(
            command_id=0,
            left_joint_target_rad=np.zeros(7),
            left_gripper_target=0.0,
            right_joint_target_rad=np.zeros(7),
            right_gripper_target=0.0,
            duration_s=duration_s,
            tolerance_rad=0.01,
            timeout_s=timeout_s,
            created_at_monotonic_s=0.0,
        )


@dataclass(frozen=True)
class DualArmTcpCommand:
    """Immutable TCP-space target command for both robot arms.

    TCP targets are controller-internal values: ``x,y,z`` in metres and
    ``rx,ry,rz`` in degrees. Gripper targets use percent-closed convention
    where ``0`` is fully open and ``100`` is fully closed.
    """

    command_id: int
    left_tcp_target_m_deg: FloatArray
    left_gripper_target: float
    right_tcp_target_m_deg: FloatArray
    right_gripper_target: float
    duration_s: float
    created_at_monotonic_s: float
    status: CommandStatus = field(default=CommandStatus.CREATED, init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "left_tcp_target_m_deg",
            _copy_vector(self.left_tcp_target_m_deg, 6, "left_tcp_target_m_deg"),
        )
        object.__setattr__(
            self,
            "right_tcp_target_m_deg",
            _copy_vector(self.right_tcp_target_m_deg, 6, "right_tcp_target_m_deg"),
        )


@dataclass(frozen=True)
class DualArmTcpResetCommand:
    """Immutable reset command for returning both arms to TCP reset targets."""

    command_id: int
    left_tcp_target_m_deg: FloatArray
    left_gripper_target: float
    right_tcp_target_m_deg: FloatArray
    right_gripper_target: float
    duration_s: float
    tcp_tolerance_m_deg: FloatArray
    gripper_tolerance: float
    timeout_s: float
    created_at_monotonic_s: float

    def __post_init__(self) -> None:
        if self.timeout_s <= 0:
            raise ValueError("timeout_s must be positive")
        if self.duration_s <= 0:
            raise ValueError("duration_s must be positive")
        object.__setattr__(
            self,
            "left_tcp_target_m_deg",
            _copy_vector(self.left_tcp_target_m_deg, 6, "left_tcp_target_m_deg"),
        )
        object.__setattr__(
            self,
            "right_tcp_target_m_deg",
            _copy_vector(self.right_tcp_target_m_deg, 6, "right_tcp_target_m_deg"),
        )
        object.__setattr__(
            self,
            "tcp_tolerance_m_deg",
            _copy_vector(self.tcp_tolerance_m_deg, 6, "tcp_tolerance_m_deg"),
        )


@dataclass(frozen=True)
class SensorTimestamps:
    """Source and receipt timestamps for robot sensor streams.

    Args:
        source_timestamp_s: Per-stream timestamps from the sensor sources.
        received_at_monotonic_s: Per-stream local receipt timestamps.
    """

    source_timestamp_s: Mapping[str, float]
    received_at_monotonic_s: Mapping[str, float]

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "source_timestamp_s", MappingProxyType(dict(self.source_timestamp_s))
        )
        object.__setattr__(
            self,
            "received_at_monotonic_s",
            MappingProxyType(dict(self.received_at_monotonic_s)),
        )


@dataclass(frozen=True)
class RobotObservation:
    """Coherent robot state and camera observation.

    Args:
        left_joint_position_rad: Seven measured left-arm joint positions.
        left_gripper_position: Measured left-gripper position.
        right_joint_position_rad: Seven measured right-arm joint positions.
        right_gripper_position: Measured right-gripper position.
        head_color_rgb: Head camera image in uint8 RGB format.
        left_wrist_color_rgb: Left-wrist camera image in uint8 RGB format.
        right_wrist_color_rgb: Right-wrist camera image in uint8 RGB format.
        timestamps: Source and receipt timestamps for the observation.
        left_tcp_pose_m_deg: Optional left TCP pose in canonical
            ``x,y,z,rx,ry,rz`` order, with translation in metres and rotation
            in degrees.
        right_tcp_pose_m_deg: Optional right TCP pose in canonical
            ``x,y,z,rx,ry,rz`` order, with translation in metres and rotation
            in degrees.
    """

    left_joint_position_rad: FloatArray
    left_gripper_position: float
    right_joint_position_rad: FloatArray
    right_gripper_position: float
    head_color_rgb: UInt8Image
    left_wrist_color_rgb: UInt8Image
    right_wrist_color_rgb: UInt8Image
    timestamps: SensorTimestamps
    left_tcp_pose_m_deg: FloatArray | None = None
    right_tcp_pose_m_deg: FloatArray | None = None

    def __post_init__(self) -> None:
        if self.left_tcp_pose_m_deg is not None:
            object.__setattr__(
                self,
                "left_tcp_pose_m_deg",
                _copy_vector(self.left_tcp_pose_m_deg, 6, "left_tcp_pose_m_deg"),
            )
        if self.right_tcp_pose_m_deg is not None:
            object.__setattr__(
                self,
                "right_tcp_pose_m_deg",
                _copy_vector(self.right_tcp_pose_m_deg, 6, "right_tcp_pose_m_deg"),
            )


@dataclass(frozen=True)
class CommandReceipt:
    """Receipt returned after accepting a command.

    Args:
        command_id: Identifier of the accepted command.
        accepted_at_monotonic_s: Monotonic timestamp when it was accepted.
        expires_at_monotonic_s: Monotonic timestamp when the receipt expires.
    """

    command_id: int
    accepted_at_monotonic_s: float
    expires_at_monotonic_s: float


@dataclass(frozen=True)
class ControllerHealth:
    """Snapshot of controller readiness and fault state.

    Args:
        ready: Whether the controller can accept operations.
        faulted: Whether the controller currently reports a fault.
        reason: Optional human-readable readiness or fault explanation.
        checked_at_monotonic_s: Monotonic timestamp when health was checked.
    """

    ready: bool
    faulted: bool
    reason: str | None
    checked_at_monotonic_s: float
