"""Single-threaded asynchronous command dispatch."""

from collections import OrderedDict
from collections.abc import Callable
from math import isfinite
from numbers import Integral, Real
from threading import Event, RLock, Thread, current_thread
from time import monotonic

from f1_robot_controller.errors import (
    CommandRejectedError,
    ControllerError,
    ControllerLifecycleError,
    ControllerNotReadyError,
)
from f1_robot_controller.executors.base import ActionExecutor
from f1_robot_controller.runtime.command_slot import Command, CommandSlot
from f1_robot_controller.runtime.health_monitor import HealthMonitor
from f1_robot_controller.types import CommandReceipt, CommandStatus

# A CommandSink must return within the executor close bound or cooperate with
# lifecycle cancellation. Python cannot forcibly terminate an arbitrary blocked
# sink thread, so an unbounded implementation makes close fail explicitly.
CommandSink = Callable[[Command], None]
_WORKER_CLOSE_TIMEOUT_S = 1.0


class DirectActionExecutor(ActionExecutor):
    """Dispatch the latest pending command through one daemon worker thread."""

    def __init__(
        self,
        sink: CommandSink,
        *,
        command_slot: CommandSlot | None = None,
        health_monitor: HealthMonitor | None = None,
        clock: Callable[[], float] = monotonic,
        status_history_limit: int = 1_024,
    ) -> None:
        """Create a stopped executor around a synchronous command sink.

        Args:
            sink: Callable that sends one command to the underlying action target.
                It must be bounded or cooperatively cancellable on lifecycle stop.
            command_slot: Optional capacity-one handoff shared with the worker.
            health_monitor: Optional lifecycle health monitor.
            clock: Monotonic clock used for command receipts.
            status_history_limit: Maximum number of command statuses to retain.

        Raises:
            ControllerError: If ``status_history_limit`` is not positive.
        """

        if not isinstance(status_history_limit, int) or status_history_limit <= 0:
            raise ControllerError("status_history_limit must be a positive integer")
        self._sink = sink
        self._slot = CommandSlot() if command_slot is None else command_slot
        self._health = HealthMonitor() if health_monitor is None else health_monitor
        self._clock = clock
        self._status_history_limit = status_history_limit
        self._statuses: OrderedDict[int, CommandStatus] = OrderedDict()
        self._status_lock = RLock()
        self._lifecycle_lock = RLock()
        self._closing = Event()
        self._accepting = False
        self._accepting_generation = 0
        self._command_generations: dict[int, int] = {}
        self._worker_thread: Thread | None = None

    def start(self) -> None:
        """Start one daemon worker and accept command submissions."""

        with self._lifecycle_lock:
            if self._closing.is_set():
                raise ControllerNotReadyError("executor is closed")
            if self._accepting:
                return
            self._slot.open()
            self._health.open()
            self._accepting_generation += 1
            self._accepting = True
            if self._worker_thread is None or not self._worker_thread.is_alive():
                self._worker_thread = Thread(
                    target=self._run,
                    name="f1-direct-action-executor",
                    daemon=True,
                )
                self._worker_thread.start()
            self._health.set_ready()

    def submit(self, command: Command) -> CommandReceipt:
        """Accept a command without waiting for its sink call to finish."""

        with self._lifecycle_lock:
            if not self._accepting or self._closing.is_set():
                raise ControllerNotReadyError("executor is not accepting commands")
            command_id, duration_s = self._validate_submission_fields(command)
            self._ensure_command_id_available(command_id)
            accepted_at_monotonic_s = self._read_clock()
            expires_at_monotonic_s = accepted_at_monotonic_s + duration_s
            if not isfinite(expires_at_monotonic_s):
                raise ControllerError("command receipt expiry must be finite")
            receipt = CommandReceipt(
                command_id=command_id,
                accepted_at_monotonic_s=accepted_at_monotonic_s,
                expires_at_monotonic_s=expires_at_monotonic_s,
            )

            replaced = self._slot.replace(command)
            if replaced is not None:
                self._set_status(replaced.command_id, CommandStatus.CANCELLED)
                self._command_generations.pop(replaced.command_id, None)
            self._command_generations[command_id] = self._accepting_generation
            self._set_status(command_id, CommandStatus.ACCEPTED)

        return receipt

    def get_status(self, command_id: int) -> CommandStatus:
        """Return a retained status or reject an unknown command identifier."""

        with self._status_lock:
            try:
                return self._statuses[command_id]
            except KeyError as error:
                raise CommandRejectedError(
                    f"unknown command id: {command_id}"
                ) from error

    def stop(self, reason: str) -> None:
        """Stop submissions and cancel the currently pending command."""

        del reason
        with self._lifecycle_lock:
            self._cancel_inflight_locked()
            self._accepting = False
            self._accepting_generation += 1
            pending = self._slot.clear()
            self._health.close()
            if pending is not None:
                self._set_status(pending.command_id, CommandStatus.CANCELLED)
                self._command_generations.pop(pending.command_id, None)

    def close(self) -> None:
        """Close the handoff and wait a bounded interval for the daemon worker."""

        pending: Command | None = None
        with self._lifecycle_lock:
            if not self._closing.is_set():
                self._cancel_inflight_locked()
                self._accepting = False
                self._accepting_generation += 1
                pending = self._slot.clear()
                if pending is not None:
                    self._command_generations.pop(pending.command_id, None)
                self._closing.set()
                self._slot.close()
                self._health.close()
            worker_thread = self._worker_thread
        if pending is not None:
            self._set_status(pending.command_id, CommandStatus.CANCELLED)
        if worker_thread is not None and worker_thread is not current_thread():
            worker_thread.join(timeout=_WORKER_CLOSE_TIMEOUT_S)
            if worker_thread.is_alive():
                reason = "command sink remained blocked during close"
                self._health.set_fault(reason)
                raise ControllerLifecycleError(reason)

    def _cancel_inflight_locked(self) -> None:
        """Notify a bounded sink that the active lifecycle is stopping."""

    def _run(self) -> None:
        """Consume the capacity-one slot until the executor closes."""

        while not self._closing.is_set():
            command = self._slot.take(timeout_s=0.05)
            if command is None:
                continue
            with self._lifecycle_lock:
                generation = self._command_generations.get(command.command_id)
                can_dispatch = (
                    self._accepting
                    and not self._closing.is_set()
                    and generation is not None
                    and generation == self._accepting_generation
                )
                if can_dispatch:
                    self._set_status(command.command_id, CommandStatus.DISPATCHED)
                else:
                    self._command_generations.pop(command.command_id, None)
                    self._set_status(command.command_id, CommandStatus.CANCELLED)
            if not can_dispatch:
                continue
            try:
                self._sink(command)
            except Exception as error:
                self._complete_dispatch(
                    command.command_id,
                    generation,
                    error=error,
                )
            else:
                self._complete_dispatch(command.command_id, generation)

    def _complete_dispatch(
        self,
        command_id: int,
        generation: int,
        *,
        error: Exception | None = None,
    ) -> None:
        """Publish one terminal result only into its originating lifecycle."""

        with self._lifecycle_lock:
            if self._command_generations.get(command_id) != generation:
                return
            generation_is_current = (
                self._accepting
                and not self._closing.is_set()
                and generation == self._accepting_generation
            )
            if not generation_is_current:
                self._command_generations.pop(command_id)
                self._set_status(command_id, CommandStatus.CANCELLED)
            elif error is not None:
                self._health.set_fault(f"command {command_id} sink failed: {error}")
                self._accepting = False
                self._accepting_generation += 1
                pending = self._slot.clear()
                if pending is not None:
                    self._set_status(pending.command_id, CommandStatus.CANCELLED)
                    self._command_generations.pop(pending.command_id, None)
                self._command_generations.pop(command_id)
                self._health.close()
                self._set_status(command_id, CommandStatus.FAULT)
            else:
                self._command_generations.pop(command_id)
                self._set_status(command_id, CommandStatus.FINISHED_DISPATCH)

    def _set_status(self, command_id: int, status: CommandStatus) -> None:
        """Record a status while keeping history bounded by acceptance order."""

        with self._status_lock:
            self._statuses[command_id] = status
            while len(self._statuses) > self._status_history_limit:
                self._statuses.popitem(last=False)

    def _ensure_command_id_available(self, command_id: int) -> None:
        """Reject a retained status or live dispatch token with the same ID."""

        with self._status_lock:
            duplicate_id = command_id in self._statuses
        if duplicate_id or command_id in self._command_generations:
            raise CommandRejectedError(f"duplicate command_id: {command_id}")

    def _read_clock(self) -> float:
        """Read the injected clock with a controller-specific failure."""

        try:
            value = self._clock()
        except (TypeError, ValueError, OverflowError) as error:
            raise ControllerError(
                "executor clock must return a finite timestamp"
            ) from error
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ControllerError("executor clock must return a finite timestamp")
        try:
            timestamp_s = float(value)
        except (TypeError, ValueError, OverflowError) as error:
            raise ControllerError(
                "executor clock must return a finite timestamp"
            ) from error
        if not isfinite(timestamp_s):
            raise ControllerError("executor clock must return a finite timestamp")
        return timestamp_s

    @staticmethod
    def _validate_submission_fields(command: Command) -> tuple[int, float]:
        """Return canonical ID and duration without mutating executor state."""

        command_id = command.command_id
        if (
            isinstance(command_id, bool)
            or not isinstance(command_id, Integral)
            or command_id < 0
        ):
            raise CommandRejectedError("command_id must be a non-negative integer")
        duration_s = command.duration_s
        if isinstance(duration_s, bool) or not isinstance(duration_s, Real):
            raise CommandRejectedError(
                "duration_s must be a positive finite real number"
            )
        try:
            normalized_duration_s = float(duration_s)
        except (TypeError, ValueError, OverflowError) as error:
            raise CommandRejectedError(
                "duration_s must be a positive finite real number"
            ) from error
        if not isfinite(normalized_duration_s) or normalized_duration_s <= 0.0:
            raise CommandRejectedError(
                "duration_s must be a positive finite real number"
            )
        return int(command_id), normalized_duration_s
