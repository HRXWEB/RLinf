"""Backend-neutral action-executor interface."""

from abc import ABC, abstractmethod

from f1_robot_controller.types import (
    CommandReceipt,
    CommandStatus,
    DualArmCommand,
    DualArmResetCommand,
    DualArmTcpCommand,
    DualArmTcpResetCommand,
)


class ActionExecutor(ABC):
    """Dispatch dual-arm commands outside the controller caller thread."""

    @abstractmethod
    def start(self) -> None:
        """Start accepting and dispatching commands."""

    @abstractmethod
    def submit(
        self,
        command: (
            DualArmCommand
            | DualArmResetCommand
            | DualArmTcpCommand
            | DualArmTcpResetCommand
        ),
    ) -> CommandReceipt:
        """Accept a command for asynchronous dispatch."""

    @abstractmethod
    def get_status(self, command_id: int) -> CommandStatus:
        """Return the latest retained status for a command."""

    @abstractmethod
    def stop(self, reason: str) -> None:
        """Stop accepting commands and cancel pending work."""

    @abstractmethod
    def close(self) -> None:
        """Close owned resources or raise if a sink prevents bounded shutdown."""
