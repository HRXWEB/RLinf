"""Action executor wired to the deterministic Fake backend."""

from collections.abc import Callable
from threading import Event, RLock
from time import monotonic

from f1_robot_controller.backends.fake.fault_injection import FakeFaultInjector
from f1_robot_controller.backends.fake.state_source import FakeStateSource
from f1_robot_controller.errors import CommandRejectedError
from f1_robot_controller.executors.direct import DirectActionExecutor
from f1_robot_controller.runtime.command_slot import Command, CommandSlot
from f1_robot_controller.runtime.health_monitor import HealthMonitor
from f1_robot_controller.types import CommandReceipt


class FakeActionExecutor(DirectActionExecutor):
    """Dispatch commands into deterministic Fake state and fault controls."""

    def __init__(
        self,
        state_source: FakeStateSource,
        *,
        fault_injector: FakeFaultInjector | None = None,
        command_slot: CommandSlot | None = None,
        health_monitor: HealthMonitor | None = None,
        clock: Callable[[], float] = monotonic,
        status_history_limit: int = 1_024,
        command_latency_s: float = 0.0,
    ) -> None:
        """Create an executor using ``state_source`` as its command sink."""

        self._state_source = state_source
        self._command_latency_s = command_latency_s
        self._latency_lock = RLock()
        self._latency_cancel_event = Event()
        self._fault_injector = (
            state_source.fault_injector if fault_injector is None else fault_injector
        )
        super().__init__(
            self._dispatch_fake,
            command_slot=command_slot,
            health_monitor=health_monitor,
            clock=clock,
            status_history_limit=status_history_limit,
        )

    def start(self) -> None:
        """Start a Fake lifecycle with an isolated latency cancellation token."""

        with self._lifecycle_lock:
            if not self._accepting and not self._closing.is_set():
                with self._latency_lock:
                    self._latency_cancel_event = Event()
            super().start()

    def submit(self, command: Command) -> CommandReceipt:
        """Apply an injected one-shot rejection before accepting a command."""

        with self._lifecycle_lock:
            if not self._accepting or self._closing.is_set():
                return super().submit(command)
            command_id, _ = self._validate_submission_fields(command)
            self._ensure_command_id_available(command_id)
            rejection_reason = self._fault_injector._consume_command_rejection()
            if rejection_reason is not None:
                raise CommandRejectedError(rejection_reason)
            return super().submit(command)

    def _dispatch_fake(self, command: Command) -> None:
        """Apply one command or raise an injected one-shot executor failure."""

        with self._latency_lock:
            cancel_event = self._latency_cancel_event
        if self._command_latency_s > 0.0 and cancel_event.wait(
            timeout=self._command_latency_s
        ):
            return
        with self._latency_lock:
            if cancel_event.is_set() or cancel_event is not self._latency_cancel_event:
                return
            failure_reason = self._fault_injector._consume_executor_failure()
            if failure_reason is not None:
                raise RuntimeError(failure_reason)
            self._state_source.apply(command)

    def _cancel_inflight_locked(self) -> None:
        """Interrupt the current lifecycle's simulated command latency."""

        with self._latency_lock:
            self._latency_cancel_event.set()
