"""Backend-neutral action executors."""

from .base import ActionExecutor
from .direct import CommandSink, DirectActionExecutor

__all__ = [
    "ActionExecutor",
    "CommandSink",
    "DirectActionExecutor",
]
