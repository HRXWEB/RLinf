from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from math import isfinite
from numbers import Integral, Real
from sys import maxsize
from threading import TIMEOUT_MAX
from types import MappingProxyType

_ROS2_SENSOR_SOURCES = (
    "head_color",
    "left_wrist_color",
    "right_wrist_color",
    "joint_state",
    "left_gripper_position",
    "right_gripper_position",
)
_ROS2_IMAGE_SOURCES = (
    "head_color",
    "left_wrist_color",
    "right_wrist_color",
)
_ROS2_COMMAND_SOURCES = ("left_tcp", "right_tcp", "left_gripper", "right_gripper")


def _finite_real(value: object, *, field_name: str) -> float:
    """Return a finite Python float without accepting coercible objects."""

    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{field_name} must be a finite real number")
    try:
        converted = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"{field_name} must be a finite real number") from error
    if not isfinite(converted):
        raise ValueError(f"{field_name} must be a finite real number")
    return converted


def _positive_real(value: object, *, field_name: str) -> float:
    converted = _finite_real(value, field_name=field_name)
    if converted <= 0.0:
        raise ValueError(f"{field_name} must be positive and finite")
    return converted


def _non_negative_real(value: object, *, field_name: str) -> float:
    converted = _finite_real(value, field_name=field_name)
    if converted < 0.0:
        raise ValueError(f"{field_name} must be finite and non-negative")
    return converted


def _positive_integer(value: object, *, field_name: str) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, Integral)
        or value <= 0
        or value > maxsize
    ):
        raise ValueError(f"{field_name} must be a positive integer")
    return int(value)


def _non_negative_integer(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative integer")
    return int(value)


@dataclass(frozen=True)
class FakeControllerConfig:
    """Configuration for the deterministic fake controller backend.

    Args:
        seed: Random seed used by the fake backend.
        image_height: Height of generated camera images in pixels.
        image_width: Width of generated camera images in pixels.
        command_latency_s: Simulated command latency in seconds.
        command_history_limit: Maximum number of applied commands to retain.
    """

    seed: int = 0
    image_height: int = 128
    image_width: int = 128
    command_latency_s: float = 0.0
    command_history_limit: int = 1_024

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "seed",
            _non_negative_integer(self.seed, field_name="seed"),
        )
        object.__setattr__(
            self,
            "image_height",
            _positive_integer(self.image_height, field_name="image_height"),
        )
        object.__setattr__(
            self,
            "image_width",
            _positive_integer(self.image_width, field_name="image_width"),
        )
        if self.image_height * self.image_width > maxsize // 3:
            raise ValueError("image dimensions exceed the platform size limit")
        command_latency_s = _non_negative_real(
            self.command_latency_s,
            field_name="command_latency_s",
        )
        if command_latency_s > TIMEOUT_MAX:
            raise ValueError("command_latency_s exceeds the thread timeout limit")
        object.__setattr__(
            self,
            "command_latency_s",
            command_latency_s,
        )
        object.__setattr__(
            self,
            "command_history_limit",
            _positive_integer(
                self.command_history_limit, field_name="command_history_limit"
            ),
        )


@dataclass(frozen=True)
class Ros2QosConfig:
    """ROS 2 subscription QoS settings for one physical sensor source."""

    reliability: str = "reliable"
    durability: str = "volatile"
    history: str = "keep_last"
    depth: int = 1

    def __post_init__(self) -> None:
        if self.reliability not in {"reliable", "best_effort"}:
            raise ValueError("reliability must be reliable or best_effort")
        if self.durability not in {"volatile", "transient_local"}:
            raise ValueError("durability must be volatile or transient_local")
        if self.history != "keep_last":
            raise ValueError("history must be keep_last")
        object.__setattr__(
            self,
            "depth",
            _positive_integer(self.depth, field_name="depth"),
        )


class Ros2ImageTransport(StrEnum):
    """Supported ROS image topic transports."""

    RAW = "raw"
    COMPRESSED = "compressed"


class Ros2PublishMode(StrEnum):
    """Supported ROS 2 motion command publication modes."""

    DISABLED = "disabled"
    VENDOR_ATOMIC = "vendor_atomic"
    SEQUENTIAL = "sequential"


@dataclass(frozen=True)
class Ros2ControllerConfig:
    """Strictly read-only ROS 2 sensor interface configuration.

    Six physical topics populate seven logical sensor sources because the one
    joint-state message is split by name into left and right arm vectors.
    Motion endpoints are represented only to reject unsafe configuration.
    """

    read_only: bool = True
    motion_enabled: bool = False
    publish_mode: Ros2PublishMode | str = Ros2PublishMode.DISABLED
    node_name: str = "f1_robot_controller_readonly"
    sensor_topics: Mapping[str, str] | None = None
    qos_by_source: Mapping[str, Ros2QosConfig] | None = None
    image_transports: Mapping[str, Ros2ImageTransport | str] | None = None
    image_shapes: Mapping[str, tuple[int, int, int]] | None = None
    left_joint_names: tuple[str, ...] | None = None
    right_joint_names: tuple[str, ...] | None = None
    joint_position_scale_to_rad: float | None = None
    left_gripper_raw_open: float | None = None
    left_gripper_raw_closed: float | None = None
    right_gripper_raw_open: float | None = None
    right_gripper_raw_closed: float | None = None
    command_topics: Mapping[str, str] | None = None
    command_state_topics: Mapping[str, str] | None = None
    command_qos: Ros2QosConfig = field(default_factory=lambda: Ros2QosConfig(depth=500))
    motion_envelope_id: str | None = None
    site_approval_id: str | None = None
    command_topics_provenance: str | None = None
    command_state_topics_provenance: str | None = None
    command_qos_provenance: str | None = None
    vendor_atomic_latch_evidence: str | None = None
    tcp_limit_low_m_deg: tuple[float, ...] = (
        -2.0,
        -2.0,
        -2.0,
        -360.0,
        -360.0,
        -360.0,
        -2.0,
        -2.0,
        -2.0,
        -360.0,
        -360.0,
        -360.0,
    )
    tcp_limit_high_m_deg: tuple[float, ...] = (
        2.0,
        2.0,
        2.0,
        360.0,
        360.0,
        360.0,
        2.0,
        2.0,
        2.0,
        360.0,
        360.0,
        360.0,
    )
    motion_service_names: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.motion_enabled, bool):
            raise ValueError("motion_enabled must be a boolean")
        try:
            publish_mode = Ros2PublishMode(self.publish_mode)
        except ValueError as error:
            raise ValueError(
                "publish_mode must be disabled, vendor_atomic, or sequential"
            ) from error
        object.__setattr__(self, "publish_mode", publish_mode)
        if self.read_only is not True and not self.motion_enabled:
            raise ValueError("ROS 2 backend must be read-only unless motion is enabled")
        if self.read_only is True and self.motion_enabled:
            raise ValueError("motion_enabled requires read_only=False")
        if self.motion_enabled and publish_mode is Ros2PublishMode.DISABLED:
            raise ValueError("motion_enabled requires a non-disabled publish_mode")
        if not self.motion_enabled and publish_mode is not Ros2PublishMode.DISABLED:
            raise ValueError("publish_mode requires motion_enabled=True")
        if self.motion_service_names:
            raise ValueError(
                "read-only ROS 2 backend cannot configure motion service clients"
            )
        if not isinstance(self.node_name, str) or not self.node_name:
            raise ValueError("node_name must be a non-empty string")

        topics = None
        if self.sensor_topics is not None:
            topics = dict(self.sensor_topics)
            if set(topics) != set(_ROS2_SENSOR_SOURCES):
                raise ValueError("sensor_topics must define exactly six sources")
            if any(
                not isinstance(topic, str) or not topic for topic in topics.values()
            ):
                raise ValueError("sensor_topics values must be non-empty strings")
            if len(set(topics.values())) != 6:
                raise ValueError("sensor_topics must contain six unique topic names")

        qos_by_source = None
        if self.qos_by_source is not None:
            qos_by_source = dict(self.qos_by_source)
            if set(qos_by_source) != set(_ROS2_SENSOR_SOURCES) or any(
                not isinstance(qos, Ros2QosConfig) for qos in qos_by_source.values()
            ):
                raise ValueError("qos_by_source must define one config per source")
        if not isinstance(self.command_qos, Ros2QosConfig):
            raise ValueError("command_qos must be a Ros2QosConfig")

        command_topics = None
        command_state_topics = None
        has_command_topics = (
            self.command_topics is not None or self.command_state_topics is not None
        )
        if self.motion_enabled or has_command_topics:
            if self.command_topics is None:
                raise ValueError("command topics require command_topics")
            if self.command_state_topics is None:
                raise ValueError("command topics require command_state_topics")
            command_topics = self._command_topic_map(
                self.command_topics,
                field_name="command_topics",
            )
            command_state_topics = self._command_topic_map(
                self.command_state_topics,
                field_name="command_state_topics",
            )
        for field_name in (
            "motion_envelope_id",
            "site_approval_id",
            "command_topics_provenance",
            "command_state_topics_provenance",
            "command_qos_provenance",
            "vendor_atomic_latch_evidence",
        ):
            value = getattr(self, field_name)
            if value is not None and (not isinstance(value, str) or not value):
                raise ValueError(f"{field_name} must be a non-empty string")

        if self.motion_enabled and not self.has_technical_motion_capability():
            raise ValueError(
                "motion_enabled requires motion envelope and command provenance"
            )
        if (
            self.motion_enabled
            and publish_mode is Ros2PublishMode.VENDOR_ATOMIC
            and not self.has_vendor_atomic_command_capability()
        ):
            raise ValueError(
                "vendor atomic publish_mode requires vendor atomic-latch evidence"
            )

        normalized_transports = None
        if self.image_transports is not None:
            transports = dict(self.image_transports)
            if set(transports) != set(_ROS2_IMAGE_SOURCES):
                raise ValueError("image_transports must define the three color sources")
            normalized_transports = {}
            for source, transport in transports.items():
                try:
                    normalized_transports[source] = Ros2ImageTransport(transport)
                except ValueError as error:
                    raise ValueError(
                        "image_transports values must be raw or compressed"
                    ) from error

        normalized_shapes = None
        if self.image_shapes is not None:
            image_shapes = dict(self.image_shapes)
            if set(image_shapes) != set(_ROS2_IMAGE_SOURCES):
                raise ValueError("image_shapes must define the three color sources")
            normalized_shapes = {}
            for source, shape in image_shapes.items():
                try:
                    normalized = tuple(shape)
                except TypeError as error:
                    raise ValueError(f"image_shapes[{source}] must be HxWx3") from error
                if (
                    len(normalized) != 3
                    or normalized[2] != 3
                    or any(
                        isinstance(dimension, bool)
                        or not isinstance(dimension, Integral)
                        or dimension <= 0
                        for dimension in normalized
                    )
                ):
                    raise ValueError(f"image_shapes[{source}] must be positive HxWx3")
                normalized_shapes[source] = tuple(int(value) for value in normalized)

        left_names = (
            None
            if self.left_joint_names is None
            else self._joint_names(self.left_joint_names, side="left")
        )
        right_names = (
            None
            if self.right_joint_names is None
            else self._joint_names(self.right_joint_names, side="right")
        )
        if (
            left_names is not None
            and right_names is not None
            and set(left_names) & set(right_names)
        ):
            raise ValueError("left and right joint names must not overlap")
        joint_scale = self.joint_position_scale_to_rad
        if joint_scale is not None:
            joint_scale = _finite_real(
                joint_scale,
                field_name="joint_position_scale_to_rad",
            )
            if joint_scale == 0.0:
                raise ValueError("joint_position_scale_to_rad must be non-zero")

        gripper_endpoints: dict[str, float] = {}
        for field_name in (
            "left_gripper_raw_open",
            "left_gripper_raw_closed",
            "right_gripper_raw_open",
            "right_gripper_raw_closed",
        ):
            value = getattr(self, field_name)
            if value is not None:
                gripper_endpoints[field_name] = _finite_real(
                    value, field_name=field_name
                )
        if (
            "left_gripper_raw_open" in gripper_endpoints
            and "left_gripper_raw_closed" in gripper_endpoints
            and gripper_endpoints["left_gripper_raw_open"]
            == gripper_endpoints["left_gripper_raw_closed"]
        ):
            raise ValueError("left gripper raw endpoints must differ")
        if (
            "right_gripper_raw_open" in gripper_endpoints
            and "right_gripper_raw_closed" in gripper_endpoints
            and gripper_endpoints["right_gripper_raw_open"]
            == gripper_endpoints["right_gripper_raw_closed"]
        ):
            raise ValueError("right gripper raw endpoints must differ")

        tcp_lower, tcp_upper = self._tcp_limits(
            self.tcp_limit_low_m_deg,
            self.tcp_limit_high_m_deg,
        )

        if topics is not None:
            object.__setattr__(self, "sensor_topics", MappingProxyType(topics))
        if qos_by_source is not None:
            object.__setattr__(self, "qos_by_source", MappingProxyType(qos_by_source))
        if normalized_transports is not None:
            object.__setattr__(
                self,
                "image_transports",
                MappingProxyType(normalized_transports),
            )
        if normalized_shapes is not None:
            object.__setattr__(
                self, "image_shapes", MappingProxyType(normalized_shapes)
            )
        object.__setattr__(self, "left_joint_names", left_names)
        object.__setattr__(self, "right_joint_names", right_names)
        object.__setattr__(self, "joint_position_scale_to_rad", joint_scale)
        for field_name, value in gripper_endpoints.items():
            object.__setattr__(self, field_name, value)
        if command_topics is not None:
            object.__setattr__(self, "command_topics", MappingProxyType(command_topics))
        if command_state_topics is not None:
            object.__setattr__(
                self,
                "command_state_topics",
                MappingProxyType(command_state_topics),
            )
        object.__setattr__(self, "tcp_limit_low_m_deg", tcp_lower)
        object.__setattr__(self, "tcp_limit_high_m_deg", tcp_upper)
        object.__setattr__(
            self, "motion_service_names", tuple(self.motion_service_names)
        )

    def missing_manifest_fields(self) -> tuple[str, ...]:
        """Return every manifest-derived field that remains unconfigured."""

        fields = (
            "sensor_topics",
            "image_transports",
            "image_shapes",
            "left_joint_names",
            "right_joint_names",
            "joint_position_scale_to_rad",
            "left_gripper_raw_open",
            "left_gripper_raw_closed",
            "right_gripper_raw_open",
            "right_gripper_raw_closed",
        )
        return tuple(field for field in fields if getattr(self, field) is None)

    def has_technical_motion_capability(self) -> bool:
        """Return whether technical motion publishing metadata is configured."""

        return all(
            isinstance(getattr(self, field_name), str)
            and bool(getattr(self, field_name))
            for field_name in (
                "motion_envelope_id",
                "command_topics_provenance",
                "command_state_topics_provenance",
                "command_qos_provenance",
            )
        )

    def has_vendor_atomic_command_capability(self) -> bool:
        """Return whether vendor-backed atomic command publishing is configured."""

        return (
            self.has_technical_motion_capability()
            and isinstance(self.vendor_atomic_latch_evidence, str)
            and bool(self.vendor_atomic_latch_evidence)
        )

    @staticmethod
    def _joint_names(value: object, *, side: str) -> tuple[str, ...]:
        try:
            names = tuple(value)
        except TypeError as error:
            raise ValueError(f"{side}_joint_names must contain seven names") from error
        if (
            len(names) != 7
            or len(set(names)) != 7
            or any(not isinstance(name, str) or not name for name in names)
        ):
            raise ValueError(f"{side}_joint_names must contain seven unique names")
        return names

    @staticmethod
    def _command_topic_map(value: object, *, field_name: str) -> dict[str, str]:
        try:
            topics = dict(value)
        except (TypeError, ValueError) as error:
            raise ValueError(
                f"{field_name} must define four command sources"
            ) from error
        if set(topics) != set(_ROS2_COMMAND_SOURCES):
            raise ValueError(f"{field_name} must define four command sources")
        if any(not isinstance(topic, str) or not topic for topic in topics.values()):
            raise ValueError(f"{field_name} values must be non-empty strings")
        if len(set(topics.values())) != 4:
            raise ValueError(f"{field_name} must contain four unique topic names")
        return topics

    @staticmethod
    def _tcp_limits(
        lower_value: object,
        upper_value: object,
    ) -> tuple[tuple[float, ...], tuple[float, ...]]:
        try:
            lower_limits = tuple(lower_value)
            upper_limits = tuple(upper_value)
        except TypeError as error:
            raise ValueError(
                "tcp_limit_low_m_deg and tcp_limit_high_m_deg must contain 12 values"
            ) from error
        if len(lower_limits) != 12 or len(upper_limits) != 12:
            raise ValueError(
                "tcp_limit_low_m_deg and tcp_limit_high_m_deg must contain 12 values"
            )
        lower_result: list[float] = []
        upper_result: list[float] = []
        for index, (lower_limit, upper_limit) in enumerate(
            zip(lower_limits, upper_limits, strict=True)
        ):
            lower = _finite_real(
                lower_limit,
                field_name=f"tcp_limit_low_m_deg[{index}]",
            )
            upper = _finite_real(
                upper_limit, field_name=f"tcp_limit_high_m_deg[{index}]"
            )
            if lower > upper:
                raise ValueError(f"TCP limit {index} requires low <= high")
            lower_result.append(lower)
            upper_result.append(upper)
        return tuple(lower_result), tuple(upper_result)


@dataclass(frozen=True)
class ControllerConfig:
    """Runtime limits and timing configuration for the controller.

    Args:
        control_period_s: Controller loop period in seconds.
        max_observation_age_s: Maximum permitted observation age in seconds.
        max_observation_skew_s: Maximum permitted sensor timestamp skew in seconds.
        joint_limit_low_rad: Lower limits for the 14 arm joints in radians.
        joint_limit_high_rad: Upper limits for the 14 arm joints in radians.
        fake: Configuration for the fake controller backend.
        ros2: Structurally explicit read-only ROS 2 configuration.

    Raises:
        ValueError: If a timing, Fake configuration, or joint-limit field is
            malformed, non-finite, outside its permitted sign, or inconsistent.
    """

    control_period_s: float = 0.1
    max_observation_age_s: float = 0.25
    max_observation_skew_s: float = 0.05
    joint_limit_low_rad: tuple[float, ...] = field(
        default_factory=lambda: (-3.141592653589793,) * 14
    )
    joint_limit_high_rad: tuple[float, ...] = field(
        default_factory=lambda: (3.141592653589793,) * 14
    )
    fake: FakeControllerConfig = field(default_factory=FakeControllerConfig)
    ros2: Ros2ControllerConfig = field(default_factory=Ros2ControllerConfig)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "control_period_s",
            _positive_real(self.control_period_s, field_name="control_period_s"),
        )
        object.__setattr__(
            self,
            "max_observation_age_s",
            _positive_real(
                self.max_observation_age_s,
                field_name="max_observation_age_s",
            ),
        )
        object.__setattr__(
            self,
            "max_observation_skew_s",
            _non_negative_real(
                self.max_observation_skew_s,
                field_name="max_observation_skew_s",
            ),
        )
        if not isinstance(self.fake, FakeControllerConfig):
            raise ValueError("fake must be a FakeControllerConfig")
        if not isinstance(self.ros2, Ros2ControllerConfig):
            raise ValueError("ros2 must be a Ros2ControllerConfig")
        try:
            lower_limits = tuple(self.joint_limit_low_rad)
            upper_limits = tuple(self.joint_limit_high_rad)
        except TypeError as error:
            raise ValueError(
                "joint_limit_low_rad and joint_limit_high_rad must contain 14 values"
            ) from error
        if len(lower_limits) != 14 or len(upper_limits) != 14:
            raise ValueError(
                "joint_limit_low_rad and joint_limit_high_rad must contain 14 values"
            )

        normalized_lower: list[float] = []
        normalized_upper: list[float] = []
        for index, (lower_limit, upper_limit) in enumerate(
            zip(lower_limits, upper_limits, strict=True)
        ):
            lower = _finite_real(
                lower_limit,
                field_name=f"joint_limit_low_rad[{index}]",
            )
            upper = _finite_real(
                upper_limit,
                field_name=f"joint_limit_high_rad[{index}]",
            )
            if lower > upper:
                raise ValueError(
                    f"joint limit {index} requires low <= high, got {lower} > {upper}"
                )
            normalized_lower.append(lower)
            normalized_upper.append(upper)

        object.__setattr__(self, "joint_limit_low_rad", tuple(normalized_lower))
        object.__setattr__(self, "joint_limit_high_rad", tuple(normalized_upper))
