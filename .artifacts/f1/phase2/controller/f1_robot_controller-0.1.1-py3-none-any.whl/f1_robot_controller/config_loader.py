"""Closed JSON loading for read-only controller runtime configuration."""

import json
from collections.abc import Mapping
from pathlib import Path

from f1_robot_controller.config import (
    ControllerConfig,
    Ros2ControllerConfig,
    Ros2QosConfig,
)
from f1_robot_controller.controller import F1RobotController
from f1_robot_controller.factory import create_controller

_TOP_LEVEL_FIELDS = frozenset(
    {"control_period_s", "max_observation_age_s", "max_observation_skew_s", "ros2"}
)
_ROS2_FIELDS = frozenset(
    {
        "command_qos",
        "command_qos_provenance",
        "command_state_topics",
        "command_state_topics_provenance",
        "command_topics",
        "command_topics_provenance",
        "image_shapes",
        "image_transports",
        "joint_position_scale_to_rad",
        "left_gripper_raw_closed",
        "left_gripper_raw_open",
        "left_joint_names",
        "motion_enabled",
        "motion_envelope_id",
        "motion_service_names",
        "node_name",
        "publish_mode",
        "qos_by_source",
        "read_only",
        "right_gripper_raw_closed",
        "right_gripper_raw_open",
        "right_joint_names",
        "sensor_topics",
        "site_approval_id",
        "tcp_limit_high_m_deg",
        "tcp_limit_low_m_deg",
        "vendor_atomic_latch_evidence",
    }
)
_ROS2_REQUIRED_FIELDS = frozenset(
    {
        "image_shapes",
        "image_transports",
        "joint_position_scale_to_rad",
        "left_gripper_raw_closed",
        "left_gripper_raw_open",
        "left_joint_names",
        "node_name",
        "qos_by_source",
        "read_only",
        "right_gripper_raw_closed",
        "right_gripper_raw_open",
        "right_joint_names",
        "sensor_topics",
    }
)


def _require_mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object")
    return value


def _reject_unknown_fields(
    payload: Mapping[str, object],
    allowed: frozenset[str],
    *,
    label: str,
    required: frozenset[str] | None = None,
) -> None:
    extra = frozenset(payload) - allowed
    if extra:
        raise ValueError(f"{label} contains unrecognized field {sorted(extra)[0]}")
    required_fields = allowed if required is None else required
    missing = required_fields - frozenset(payload)
    if missing:
        raise ValueError(f"{label} is missing field {sorted(missing)[0]}")


def load_controller_config(path: str | Path) -> ControllerConfig:
    """Load a closed read-only JSON config into a ControllerConfig."""

    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    config_payload = _require_mapping(payload, "controller config")
    _reject_unknown_fields(
        config_payload,
        _TOP_LEVEL_FIELDS,
        label="controller config",
    )
    ros2_payload = dict(_require_mapping(config_payload["ros2"], "ros2 config"))
    if (
        "command_topics" in ros2_payload
        and ros2_payload.get("motion_enabled") is not True
    ):
        raise ValueError("ros2 config contains unsafe field command_topics")
    _reject_unknown_fields(
        ros2_payload,
        _ROS2_FIELDS,
        label="ros2 config",
        required=_ROS2_REQUIRED_FIELDS,
    )
    qos_by_source = _require_mapping(ros2_payload["qos_by_source"], "qos_by_source")
    ros2_payload["qos_by_source"] = {
        source: Ros2QosConfig(**_require_mapping(qos, f"qos_by_source[{source}]"))
        for source, qos in qos_by_source.items()
    }
    if "command_qos" in ros2_payload:
        ros2_payload["command_qos"] = Ros2QosConfig(
            **_require_mapping(ros2_payload["command_qos"], "command_qos")
        )
    return ControllerConfig(
        control_period_s=config_payload["control_period_s"],
        max_observation_age_s=config_payload["max_observation_age_s"],
        max_observation_skew_s=config_payload["max_observation_skew_s"],
        ros2=Ros2ControllerConfig(**ros2_payload),
    )


def create_controller_from_config(
    *,
    is_dummy: bool,
    path: str | Path,
) -> F1RobotController:
    """Load config JSON and create the requested controller backend."""

    return create_controller(is_dummy=is_dummy, config=load_controller_config(path))
